"""
Tests for scenario_engine — what-if comparison tool.

Coverage
--------
ScenarioMutation.validate()
    - all mutation types: required fields, range checks, ordering checks

Scenario.validate()
    - delegates to mutations, prefixes correctly

_apply_mutation() — via apply_scenario()
    remove_employee, add_shift, remove_shift, change_hours,
    replace_employee, adjust_covers_ratio, change_demand, trim_shift_end

apply_scenario()
    - deep-copy isolation (base roster never mutated)
    - cost / compliance / coverage populated
    - skipped mutations tracked
    - multi-mutation ordering

compare_scenarios()
    - delta_cost / delta_hours / delta_shifts computed
    - ranked list sorted correctly
    - base always present
    - recommendation string non-empty

run_sensitivity()
    - covers_ratio sweep returns correct point count
    - demand_multiplier sweep works
    - optimal_value in values list
    - unknown parameter raises ValueError
    - empty values raises ValueError

Convenience builders
    build_remove_casuals_scenario, build_week_demand_scenario
"""

import pytest
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from rosteriq.models import (
    AwardLevel, DemandForecast, Employee, EmploymentType,
    Roster, Shift, ShiftStatus, SignalType, State, VenueConfig,
)
from rosteriq.scenario_engine import (
    MutationType,
    Scenario,
    ScenarioMutation,
    SensitivityResult,
    apply_scenario,
    build_remove_casuals_scenario,
    build_week_demand_scenario,
    compare_scenarios,
    run_sensitivity,
    _apply_mutation,
    _build_compliance_summary,
    _build_cost_summary,
    _build_coverage,
    _deep_copy_roster,
    _make_shift,
    DEFAULT_COVERS_PER_STAFF,
)


# ============================================================================
# Shared fixtures
# ============================================================================

WEEK_START = date(2026, 4, 6)   # Monday
WEEK_END   = date(2026, 4, 12)  # Sunday


def make_venue() -> VenueConfig:
    return VenueConfig(
        id="venue-1", name="The Test Pub",
        tanda_org_id="org-1", state=State.vic,
        max_labour_pct=32.0, created_at=datetime(2025, 1, 1),
    )


def make_employee(
    emp_id: str = "emp-1",
    name: str = "Alice",
    emp_type: EmploymentType = EmploymentType.full_time,
    rate: float = 28.0,
    max_hours: float = 38.0,
) -> Employee:
    return Employee(
        id=emp_id, name=name, employment_type=emp_type,
        award_level=AwardLevel.level_3,
        state=State.vic,
        hourly_base_rate=Decimal(str(rate)),
        max_hours_per_week=max_hours,
        consecutive_days_limit=6,
        created_at=datetime(2025, 1, 1),
        updated_at=datetime(2025, 1, 1),
    )


def make_shift(
    shift_id: str = "s-1",
    employee_id: str = "emp-1",
    shift_date: date = None,
    start_hour: int = 10,
    end_hour: int = 18,
    role: str = "general",
) -> Shift:
    shift_date = shift_date or WEEK_START
    break_mins = 30 if (end_hour - start_hour) > 5 else 0
    return Shift(
        id=shift_id,
        employee_id=employee_id,
        date=shift_date,
        start_time=time(start_hour, 0),
        end_time=time(end_hour % 24, 0),
        break_minutes=break_mins,
        status=ShiftStatus.scheduled,
        role=role,
    )


def make_roster(shifts: list[Shift] = None) -> Roster:
    return Roster(
        id="r-1", venue_id="venue-1",
        week_start=WEEK_START, week_end=WEEK_END,
        total_cost=Decimal("1500.00"),
        created_at=datetime(2025, 1, 1),
        shifts=shifts or [],
    )


def make_forecast(
    fc_date: date = None, hour: int = 12, covers: float = 60.0
) -> DemandForecast:
    return DemandForecast(
        id=str(id(object())),
        venue_id="venue-1",
        date=fc_date or WEEK_START,
        hour=hour,
        predicted_covers=covers,
        confidence=0.8,
        signals_used=[SignalType.historical],
        model_version="cold_start_v1",
    )


def base_roster_and_context():
    """Return (roster, employees_dict, venue, forecasts) for standard tests."""
    emp1 = make_employee("emp-1", "Alice", EmploymentType.full_time, 28.0)
    emp2 = make_employee("emp-2", "Bob", EmploymentType.part_time, 26.0)
    emp3 = make_employee("emp-3", "Cara", EmploymentType.casual, 30.0)

    shifts = [
        make_shift("s-1", "emp-1", WEEK_START, 10, 18),
        make_shift("s-2", "emp-2", WEEK_START, 11, 17),
        make_shift("s-3", "emp-3", WEEK_START, 17, 22),
    ]
    roster = make_roster(shifts)
    employees = {"emp-1": emp1, "emp-2": emp2, "emp-3": emp3}
    venue = make_venue()
    forecasts = [
        make_forecast(WEEK_START, 10, 45),
        make_forecast(WEEK_START, 12, 90),
        make_forecast(WEEK_START, 18, 120),
        make_forecast(WEEK_START, 20, 105),
    ]
    return roster, employees, venue, forecasts


# ============================================================================
# ScenarioMutation.validate()
# ============================================================================

class TestMutationValidation:

    def test_remove_employee_requires_employee_id(self):
        m = ScenarioMutation(type=MutationType.remove_employee)
        assert any("employee_id" in e for e in m.validate())

    def test_remove_employee_valid(self):
        m = ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-1")
        assert m.validate() == []

    def test_add_shift_requires_employee_id(self):
        m = ScenarioMutation(
            type=MutationType.add_shift,
            date=WEEK_START, start_hour=10, end_hour=18,
        )
        assert any("employee_id" in e for e in m.validate())

    def test_add_shift_requires_date(self):
        m = ScenarioMutation(
            type=MutationType.add_shift,
            employee_id="emp-1", start_hour=10, end_hour=18,
        )
        assert any("date" in e for e in m.validate())

    def test_add_shift_requires_start_hour(self):
        m = ScenarioMutation(
            type=MutationType.add_shift,
            employee_id="emp-1", date=WEEK_START, end_hour=18,
        )
        assert any("start_hour" in e for e in m.validate())

    def test_add_shift_requires_end_hour(self):
        m = ScenarioMutation(
            type=MutationType.add_shift,
            employee_id="emp-1", date=WEEK_START, start_hour=10,
        )
        assert any("end_hour" in e for e in m.validate())

    def test_add_shift_end_must_be_after_start(self):
        m = ScenarioMutation(
            type=MutationType.add_shift,
            employee_id="emp-1", date=WEEK_START, start_hour=18, end_hour=10,
        )
        assert any("end_hour" in e or "greater" in e for e in m.validate())

    def test_add_shift_valid(self):
        m = ScenarioMutation(
            type=MutationType.add_shift,
            employee_id="emp-1", date=WEEK_START, start_hour=10, end_hour=18,
        )
        assert m.validate() == []

    def test_remove_shift_requires_shift_id(self):
        m = ScenarioMutation(type=MutationType.remove_shift)
        assert any("shift_id" in e for e in m.validate())

    def test_remove_shift_valid(self):
        m = ScenarioMutation(type=MutationType.remove_shift, shift_id="s-1")
        assert m.validate() == []

    def test_change_hours_requires_shift_id(self):
        m = ScenarioMutation(type=MutationType.change_hours, start_hour=10)
        assert any("shift_id" in e for e in m.validate())

    def test_change_hours_requires_at_least_one_time(self):
        m = ScenarioMutation(type=MutationType.change_hours, shift_id="s-1")
        assert any("start_hour" in e or "end_hour" in e for e in m.validate())

    def test_change_hours_valid_start_only(self):
        m = ScenarioMutation(type=MutationType.change_hours, shift_id="s-1", start_hour=8)
        assert m.validate() == []

    def test_replace_employee_requires_shift_id(self):
        m = ScenarioMutation(
            type=MutationType.replace_employee,
            replacement_employee_id="emp-2",
        )
        assert any("shift_id" in e for e in m.validate())

    def test_replace_employee_requires_replacement(self):
        m = ScenarioMutation(type=MutationType.replace_employee, shift_id="s-1")
        assert any("replacement" in e for e in m.validate())

    def test_replace_employee_valid(self):
        m = ScenarioMutation(
            type=MutationType.replace_employee,
            shift_id="s-1",
            replacement_employee_id="emp-2",
        )
        assert m.validate() == []

    def test_adjust_covers_ratio_requires_covers_ratio(self):
        m = ScenarioMutation(type=MutationType.adjust_covers_ratio)
        assert any("covers_ratio" in e for e in m.validate())

    def test_adjust_covers_ratio_must_be_positive(self):
        m = ScenarioMutation(type=MutationType.adjust_covers_ratio, covers_ratio=-5.0)
        assert any("positive" in e for e in m.validate())

    def test_adjust_covers_ratio_valid(self):
        m = ScenarioMutation(type=MutationType.adjust_covers_ratio, covers_ratio=20.0)
        assert m.validate() == []

    def test_change_demand_requires_date(self):
        m = ScenarioMutation(type=MutationType.change_demand, demand_multiplier=1.2)
        assert any("date" in e for e in m.validate())

    def test_change_demand_requires_multiplier(self):
        m = ScenarioMutation(type=MutationType.change_demand, date=WEEK_START)
        assert any("demand_multiplier" in e for e in m.validate())

    def test_change_demand_multiplier_must_be_positive(self):
        m = ScenarioMutation(
            type=MutationType.change_demand, date=WEEK_START, demand_multiplier=-0.1
        )
        assert any("positive" in e for e in m.validate())

    def test_change_demand_valid(self):
        m = ScenarioMutation(
            type=MutationType.change_demand, date=WEEK_START, demand_multiplier=1.2
        )
        assert m.validate() == []

    def test_trim_shift_end_requires_shift_id(self):
        m = ScenarioMutation(type=MutationType.trim_shift_end, end_hour=16)
        assert any("shift_id" in e for e in m.validate())

    def test_trim_shift_end_requires_end_hour(self):
        m = ScenarioMutation(type=MutationType.trim_shift_end, shift_id="s-1")
        assert any("end_hour" in e for e in m.validate())

    def test_trim_shift_end_valid(self):
        m = ScenarioMutation(type=MutationType.trim_shift_end, shift_id="s-1", end_hour=16)
        assert m.validate() == []


# ============================================================================
# Scenario.validate()
# ============================================================================

class TestScenarioValidation:

    def test_valid_scenario_empty(self):
        s = Scenario(name="empty", mutations=[])
        assert s.validate() == []

    def test_propagates_mutation_errors(self):
        m = ScenarioMutation(type=MutationType.remove_employee)   # missing employee_id
        s = Scenario(name="bad", mutations=[m])
        errors = s.validate()
        assert len(errors) > 0
        assert "mutation[0]" in errors[0]

    def test_prefixes_mutation_index(self):
        m1 = ScenarioMutation(type=MutationType.remove_employee, employee_id="e")
        m2 = ScenarioMutation(type=MutationType.remove_shift)   # missing shift_id
        s = Scenario(name="mixed", mutations=[m1, m2])
        errors = s.validate()
        assert any("mutation[1]" in e for e in errors)
        assert not any("mutation[0]" in e for e in errors)

    def test_scenario_has_unique_id(self):
        s1 = Scenario(name="a", mutations=[])
        s2 = Scenario(name="b", mutations=[])
        assert s1.id != s2.id


# ============================================================================
# _deep_copy_roster
# ============================================================================

class TestDeepCopyRoster:

    def test_shifts_not_same_objects(self):
        roster = make_roster([make_shift()])
        copy = _deep_copy_roster(roster)
        assert copy.shifts[0] is not roster.shifts[0]

    def test_mutation_to_copy_does_not_affect_original(self):
        roster = make_roster([make_shift("s-1", "emp-1")])
        copy = _deep_copy_roster(roster)
        copy.shifts[0].employee_id = "emp-99"
        assert roster.shifts[0].employee_id == "emp-1"

    def test_same_metadata(self):
        roster = make_roster()
        copy = _deep_copy_roster(roster)
        assert copy.id == roster.id
        assert copy.week_start == roster.week_start


# ============================================================================
# apply_scenario — remove_employee
# ============================================================================

class TestApplyScenarioRemoveEmployee:

    def test_removes_all_shifts_for_employee(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Remove Alice",
            mutations=[ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-1")],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        emp_ids = {s.employee_id for s in result.roster.shifts}
        assert "emp-1" not in emp_ids

    def test_other_shifts_remain(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Remove Alice",
            mutations=[ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-1")],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert any(s.employee_id == "emp-2" for s in result.roster.shifts)

    def test_base_roster_unchanged(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        original_count = len(roster.shifts)
        scenario = Scenario(
            name="Remove Alice",
            mutations=[ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-1")],
        )
        apply_scenario(roster, employees, venue, forecasts, scenario)
        assert len(roster.shifts) == original_count

    def test_date_filtered_remove(self):
        emp = make_employee("emp-1")
        s1 = make_shift("s-1", "emp-1", WEEK_START)
        s2 = make_shift("s-2", "emp-1", WEEK_START + timedelta(days=1))
        roster = make_roster([s1, s2])
        employees = {"emp-1": emp}
        venue = make_venue()
        forecasts = []
        scenario = Scenario(
            name="Remove Monday only",
            mutations=[ScenarioMutation(
                type=MutationType.remove_employee,
                employee_id="emp-1",
                date=WEEK_START,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        # Tuesday shift should remain
        assert len(result.roster.shifts) == 1
        assert result.roster.shifts[0].date == WEEK_START + timedelta(days=1)

    def test_nonexistent_employee_tracked_as_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Ghost employee",
            mutations=[ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-99")],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0
        assert len(result.skipped_mutations) == 1


# ============================================================================
# apply_scenario — add_shift
# ============================================================================

class TestApplyScenarioAddShift:

    def test_adds_shift(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        before = len(roster.shifts)
        # emp-1 has shift on WEEK_START already; use WEEK_START+1
        scenario = Scenario(
            name="Extra Tuesday",
            mutations=[ScenarioMutation(
                type=MutationType.add_shift,
                employee_id="emp-1",
                date=WEEK_START + timedelta(days=1),
                start_hour=17, end_hour=23,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert len(result.roster.shifts) == before + 1

    def test_conflict_on_same_day_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        # emp-1 already has s-1 on WEEK_START
        scenario = Scenario(
            name="Double shift conflict",
            mutations=[ScenarioMutation(
                type=MutationType.add_shift,
                employee_id="emp-1",
                date=WEEK_START,
                start_hour=9, end_hour=14,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0
        assert len(result.skipped_mutations) > 0

    def test_unknown_employee_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Ghost add",
            mutations=[ScenarioMutation(
                type=MutationType.add_shift,
                employee_id="emp-99",
                date=WEEK_START + timedelta(days=2),
                start_hour=10, end_hour=18,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0

    def test_new_shift_employee_id_correct(self):
        emp4 = make_employee("emp-4", "Dave", EmploymentType.casual)
        roster, employees, venue, forecasts = base_roster_and_context()
        employees["emp-4"] = emp4
        scenario = Scenario(
            name="Add Dave Wednesday",
            mutations=[ScenarioMutation(
                type=MutationType.add_shift,
                employee_id="emp-4",
                date=WEEK_START + timedelta(days=2),
                start_hour=12, end_hour=20,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        new_shifts = [s for s in result.roster.shifts if s.employee_id == "emp-4"]
        assert len(new_shifts) == 1


# ============================================================================
# apply_scenario — remove_shift
# ============================================================================

class TestApplyScenarioRemoveShift:

    def test_removes_specific_shift(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Remove s-2",
            mutations=[ScenarioMutation(type=MutationType.remove_shift, shift_id="s-2")],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert not any(s.id == "s-2" for s in result.roster.shifts)

    def test_other_shifts_unaffected(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Remove s-2",
            mutations=[ScenarioMutation(type=MutationType.remove_shift, shift_id="s-2")],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert any(s.id == "s-1" for s in result.roster.shifts)
        assert any(s.id == "s-3" for s in result.roster.shifts)

    def test_nonexistent_shift_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Ghost shift",
            mutations=[ScenarioMutation(type=MutationType.remove_shift, shift_id="s-999")],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0
        assert len(result.skipped_mutations) == 1


# ============================================================================
# apply_scenario — change_hours
# ============================================================================

class TestApplyScenarioChangeHours:

    def test_changes_end_hour(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="End s-1 earlier",
            mutations=[ScenarioMutation(
                type=MutationType.change_hours,
                shift_id="s-1",
                end_hour=15,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        s1 = next(s for s in result.roster.shifts if s.id == "s-1")
        assert s1.end_time.hour == 15

    def test_changes_start_hour(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Start s-1 later",
            mutations=[ScenarioMutation(
                type=MutationType.change_hours,
                shift_id="s-1",
                start_hour=12,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        s1 = next(s for s in result.roster.shifts if s.id == "s-1")
        assert s1.start_time.hour == 12

    def test_original_shift_unchanged(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        orig_end = roster.shifts[0].end_time.hour
        scenario = Scenario(
            name="End earlier",
            mutations=[ScenarioMutation(
                type=MutationType.change_hours, shift_id="s-1", end_hour=15,
            )],
        )
        apply_scenario(roster, employees, venue, forecasts, scenario)
        assert roster.shifts[0].end_time.hour == orig_end

    def test_invalid_hours_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Bad hours",
            mutations=[ScenarioMutation(
                type=MutationType.change_hours, shift_id="s-1",
                start_hour=20, end_hour=10,   # end before start
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0

    def test_break_minutes_recalculated(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        # s-1 is 10–18 (8h) → change to 10–13 (3h) → should need 0 break
        scenario = Scenario(
            name="Short shift",
            mutations=[ScenarioMutation(
                type=MutationType.change_hours, shift_id="s-1", end_hour=13,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        s1 = next(s for s in result.roster.shifts if s.id == "s-1")
        assert s1.break_minutes == 0


# ============================================================================
# apply_scenario — replace_employee
# ============================================================================

class TestApplyScenarioReplaceEmployee:

    def test_swaps_employee(self):
        emp4 = make_employee("emp-4", "Dave")
        roster, employees, venue, forecasts = base_roster_and_context()
        employees["emp-4"] = emp4
        scenario = Scenario(
            name="Swap Alice for Dave on s-1",
            mutations=[ScenarioMutation(
                type=MutationType.replace_employee,
                shift_id="s-1",
                replacement_employee_id="emp-4",
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        s1 = next(s for s in result.roster.shifts if s.id == "s-1")
        assert s1.employee_id == "emp-4"

    def test_original_not_mutated(self):
        emp4 = make_employee("emp-4", "Dave")
        roster, employees, venue, forecasts = base_roster_and_context()
        employees["emp-4"] = emp4
        orig_emp = roster.shifts[0].employee_id
        scenario = Scenario(
            name="Swap",
            mutations=[ScenarioMutation(
                type=MutationType.replace_employee,
                shift_id="s-1",
                replacement_employee_id="emp-4",
            )],
        )
        apply_scenario(roster, employees, venue, forecasts, scenario)
        assert roster.shifts[0].employee_id == orig_emp

    def test_replacement_already_scheduled_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        # emp-2 already has s-2 on WEEK_START
        scenario = Scenario(
            name="Double book emp-2",
            mutations=[ScenarioMutation(
                type=MutationType.replace_employee,
                shift_id="s-1",
                replacement_employee_id="emp-2",
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0
        assert len(result.skipped_mutations) > 0

    def test_unknown_replacement_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Ghost replacement",
            mutations=[ScenarioMutation(
                type=MutationType.replace_employee,
                shift_id="s-1",
                replacement_employee_id="emp-99",
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0


# ============================================================================
# apply_scenario — adjust_covers_ratio
# ============================================================================

class TestApplyScenarioAdjustCoversRatio:

    def test_ratio_reflected_in_result(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Higher ratio",
            mutations=[ScenarioMutation(
                type=MutationType.adjust_covers_ratio, covers_ratio=20.0
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.covers_ratio_used == pytest.approx(20.0)

    def test_default_ratio_when_no_mutation(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(name="No changes", mutations=[])
        result = apply_scenario(
            roster, employees, venue, forecasts, scenario, covers_ratio=15.0
        )
        assert result.covers_ratio_used == pytest.approx(15.0)

    def test_roster_shifts_unchanged(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        before = len(roster.shifts)
        scenario = Scenario(
            name="Higher ratio",
            mutations=[ScenarioMutation(
                type=MutationType.adjust_covers_ratio, covers_ratio=25.0
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert len(result.roster.shifts) == before


# ============================================================================
# apply_scenario — change_demand
# ============================================================================

class TestApplyScenarioChangeDemand:

    def test_demand_scaled_in_coverage(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        # With high demand multiplier, more staff required → more understaffed hours
        scenario_high = Scenario(
            name="Very busy",
            mutations=[ScenarioMutation(
                type=MutationType.change_demand,
                date=WEEK_START, demand_multiplier=5.0,
            )],
        )
        scenario_low = Scenario(
            name="Very quiet",
            mutations=[ScenarioMutation(
                type=MutationType.change_demand,
                date=WEEK_START, demand_multiplier=0.1,
            )],
        )
        result_high = apply_scenario(roster, employees, venue, forecasts, scenario_high)
        result_low = apply_scenario(roster, employees, venue, forecasts, scenario_low)
        assert result_high.understaffed_hours >= result_low.understaffed_hours

    def test_roster_shifts_unchanged(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        before = len(roster.shifts)
        scenario = Scenario(
            name="Busy day",
            mutations=[ScenarioMutation(
                type=MutationType.change_demand,
                date=WEEK_START, demand_multiplier=1.5,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert len(result.roster.shifts) == before

    def test_other_dates_unaffected(self):
        fc_tuesday = make_forecast(WEEK_START + timedelta(days=1), 12, 60.0)
        roster, employees, venue, forecasts = base_roster_and_context()
        forecasts_ext = forecasts + [fc_tuesday]
        scenario = Scenario(
            name="Monday x2",
            mutations=[ScenarioMutation(
                type=MutationType.change_demand,
                date=WEEK_START, demand_multiplier=2.0,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts_ext, scenario)
        tuesday_fc = next(
            (fc for fc in result.roster.shifts if False), None   # shifts don't hold forecasts
        )
        # Verify original forecasts object not mutated
        assert any(fc.predicted_covers == 60.0 for fc in forecasts if fc.date == WEEK_START + timedelta(days=1))


# ============================================================================
# apply_scenario — trim_shift_end
# ============================================================================

class TestApplyScenarioTrimShiftEnd:

    def test_trims_end_time(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Send s-3 home at 20",
            mutations=[ScenarioMutation(
                type=MutationType.trim_shift_end, shift_id="s-3", end_hour=20,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        s3 = next(s for s in result.roster.shifts if s.id == "s-3")
        assert s3.end_time.hour == 20

    def test_trim_before_start_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        # s-3 starts at 17; trimming to 16 is invalid
        scenario = Scenario(
            name="Bad trim",
            mutations=[ScenarioMutation(
                type=MutationType.trim_shift_end, shift_id="s-3", end_hour=16,
            )],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0

    def test_trim_reduces_cost(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        base_scenario = Scenario(name="Base", mutations=[])
        trim_scenario = Scenario(
            name="Trim s-1 to 14h",
            mutations=[ScenarioMutation(
                type=MutationType.trim_shift_end, shift_id="s-1", end_hour=14,
            )],
        )
        base_result = apply_scenario(roster, employees, venue, forecasts, base_scenario)
        trim_result = apply_scenario(roster, employees, venue, forecasts, trim_scenario)
        assert trim_result.cost.total < base_result.cost.total


# ============================================================================
# apply_scenario — general properties
# ============================================================================

class TestApplyScenarioGeneral:

    def test_cost_summary_non_negative(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = apply_scenario(roster, employees, venue, forecasts, Scenario(name="base", mutations=[]))
        assert result.cost.total >= 0
        assert result.cost.total_hours >= 0
        assert result.cost.total_shifts >= 0

    def test_coverage_list_populated_when_forecasts(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = apply_scenario(roster, employees, venue, forecasts, Scenario(name="base", mutations=[]))
        assert len(result.coverage) == len(forecasts)

    def test_coverage_empty_when_no_forecasts(self):
        roster, employees, venue, _ = base_roster_and_context()
        result = apply_scenario(roster, employees, venue, [], Scenario(name="base", mutations=[]))
        assert result.coverage == []

    def test_compliance_object_present(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = apply_scenario(roster, employees, venue, forecasts, Scenario(name="base", mutations=[]))
        assert hasattr(result.compliance, "is_clean")
        assert hasattr(result.compliance, "issue_count")

    def test_applied_mutations_count(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = Scenario(
            name="Two changes",
            mutations=[
                ScenarioMutation(type=MutationType.remove_shift, shift_id="s-3"),
                ScenarioMutation(type=MutationType.adjust_covers_ratio, covers_ratio=20.0),
            ],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 2
        assert len(result.skipped_mutations) == 0

    def test_invalid_mutation_tracked_as_skipped(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        # Missing employee_id
        scenario = Scenario(
            name="Invalid",
            mutations=[ScenarioMutation(type=MutationType.remove_employee)],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 0
        assert len(result.skipped_mutations) == 1

    def test_as_dict_serialisable(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = apply_scenario(roster, employees, venue, forecasts, Scenario(name="base", mutations=[]))
        d = result.as_dict()
        assert isinstance(d, dict)
        assert "cost" in d and "compliance" in d and "coverage" in d

    def test_coverage_score_between_0_and_1(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = apply_scenario(roster, employees, venue, forecasts, Scenario(name="base", mutations=[]))
        assert 0.0 <= result.coverage_score <= 1.0

    def test_multi_mutation_ordering(self):
        """Mutations applied in order: add then immediately trim."""
        emp4 = make_employee("emp-4", "Dave")
        roster, employees, venue, forecasts = base_roster_and_context()
        employees["emp-4"] = emp4
        new_shift_date = WEEK_START + timedelta(days=2)
        scenario = Scenario(
            name="Add then can't trim (no ID yet)",
            mutations=[
                ScenarioMutation(
                    type=MutationType.add_shift,
                    employee_id="emp-4",
                    date=new_shift_date,
                    start_hour=10, end_hour=18,
                ),
                ScenarioMutation(
                    type=MutationType.remove_employee,
                    employee_id="emp-3",
                ),
            ],
        )
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        assert result.applied_mutations == 2
        emp_ids = {s.employee_id for s in result.roster.shifts}
        assert "emp-3" not in emp_ids
        assert "emp-4" in emp_ids


# ============================================================================
# compare_scenarios()
# ============================================================================

class TestCompareScenarios:

    def test_raises_on_empty_scenarios(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        with pytest.raises(ValueError):
            compare_scenarios(roster, employees, venue, forecasts, [])

    def test_base_result_present(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove Cara", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        assert comp.base_result.scenario.name == "Base roster"

    def test_scenario_results_count(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenarios = [
            Scenario(name="A", mutations=[ScenarioMutation(type=MutationType.remove_shift, shift_id="s-3")]),
            Scenario(name="B", mutations=[ScenarioMutation(type=MutationType.remove_shift, shift_id="s-2")]),
        ]
        comp = compare_scenarios(roster, employees, venue, forecasts, scenarios)
        assert len(comp.scenario_results) == 2

    def test_ranked_includes_base(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove Cara", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        names = {r.scenario_name for r in comp.ranked}
        assert "Base roster" in names

    def test_ranked_sorted_by_cost(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove Cara", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s], rank_by="cost")
        costs = [r.total_cost for r in comp.ranked]
        assert costs == sorted(costs)

    def test_ranked_sorted_by_coverage(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove all", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s], rank_by="coverage")
        scores = [r.coverage_score for r in comp.ranked]
        assert scores == sorted(scores, reverse=True)

    def test_delta_cost_computed(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove Cara", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        result = comp.scenario_results[0]
        assert result.delta_cost is not None
        assert result.delta_cost <= Decimal("0")   # removing a shift saves money

    def test_delta_shifts_computed(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove s-3", mutations=[
            ScenarioMutation(type=MutationType.remove_shift, shift_id="s-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        assert comp.scenario_results[0].delta_shifts == -1

    def test_base_roster_not_mutated(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        orig = len(roster.shifts)
        s = Scenario(name="Remove emp-1", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-1")
        ])
        compare_scenarios(roster, employees, venue, forecasts, [s])
        assert len(roster.shifts) == orig

    def test_recommendation_non_empty(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove Cara", mutations=[
            ScenarioMutation(type=MutationType.remove_employee, employee_id="emp-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        assert isinstance(comp.recommendation, str)
        assert len(comp.recommendation) > 0

    def test_best_cost_scenario_name(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Remove s-3", mutations=[
            ScenarioMutation(type=MutationType.remove_shift, shift_id="s-3")
        ])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        # Removing a shift should be cheaper
        assert comp.best_cost_scenario in {"Remove s-3", "Base roster"}

    def test_as_dict_structure(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        s = Scenario(name="Test", mutations=[])
        comp = compare_scenarios(roster, employees, venue, forecasts, [s])
        d = comp.as_dict()
        assert "base" in d
        assert "scenarios" in d
        assert "ranked" in d
        assert "recommendation" in d

    def test_multiple_scenarios_all_evaluated(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenarios = [
            Scenario(name=f"Scenario {i}", mutations=[]) for i in range(4)
        ]
        comp = compare_scenarios(roster, employees, venue, forecasts, scenarios)
        assert len(comp.scenario_results) == 4
        assert len(comp.ranked) == 5  # 4 + base


# ============================================================================
# run_sensitivity()
# ============================================================================

class TestRunSensitivity:

    def test_covers_ratio_sweep_point_count(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        values = [10.0, 12.0, 15.0, 18.0, 20.0]
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="covers_ratio", values=values,
        )
        assert len(result.points) == len(values)

    def test_demand_multiplier_sweep_point_count(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        values = [0.8, 1.0, 1.2, 1.5]
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="demand_multiplier", values=values,
        )
        assert len(result.points) == len(values)

    def test_optimal_value_in_values(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        values = [10.0, 15.0, 20.0]
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="covers_ratio", values=values,
        )
        assert result.optimal_value in values

    def test_parameter_name_preserved(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="covers_ratio", values=[15.0],
        )
        assert result.parameter_name == "covers_ratio"

    def test_unknown_parameter_raises(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        with pytest.raises(ValueError, match="covers_ratio"):
            run_sensitivity(
                roster, employees, venue, forecasts,
                parameter="invalid_param", values=[1.0],
            )

    def test_empty_values_raises(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        with pytest.raises(ValueError):
            run_sensitivity(
                roster, employees, venue, forecasts,
                parameter="covers_ratio", values=[],
            )

    def test_point_fields_present(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="covers_ratio", values=[15.0],
        )
        p = result.points[0]
        assert hasattr(p, "parameter_value")
        assert hasattr(p, "total_cost")
        assert hasattr(p, "understaffed_hours")
        assert hasattr(p, "overstaffed_hours")
        assert hasattr(p, "coverage_score")

    def test_as_dict_serialisable(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="covers_ratio", values=[10.0, 15.0, 20.0],
        )
        d = result.as_dict()
        assert "parameter_name" in d
        assert "points" in d
        assert "optimal_value" in d
        assert "optimal_cost" in d

    def test_higher_covers_ratio_increases_understaffed_hours(self):
        """More covers per staff = same staff can handle more demand = less understaffing
        when demand is low. Conversely very high ratio = more understaffed hours."""
        roster, employees, venue, forecasts = base_roster_and_context()
        # Use forecasts with high demand so the ratio matters
        busy_forecasts = [make_forecast(WEEK_START, h, 200.0) for h in range(10, 22)]
        result = run_sensitivity(
            roster, employees, venue, busy_forecasts,
            parameter="covers_ratio", values=[5.0, 50.0],
        )
        # Low ratio (5 covers/staff) needs more staff → more understaffed at same roster
        # High ratio (50 covers/staff) needs fewer staff → less understaffed
        low_ratio_pt = next(p for p in result.points if p.parameter_value == 5.0)
        high_ratio_pt = next(p for p in result.points if p.parameter_value == 50.0)
        assert low_ratio_pt.understaffed_hours >= high_ratio_pt.understaffed_hours

    def test_single_value_returns_one_point(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter="covers_ratio", values=[15.0],
        )
        assert len(result.points) == 1
        assert result.optimal_value == pytest.approx(15.0)


# ============================================================================
# Convenience builders
# ============================================================================

class TestConvenienceBuilders:

    def test_build_remove_casuals_scenario_excludes_non_casuals(self):
        emp1 = make_employee("e1", "Alice", EmploymentType.full_time)
        emp2 = make_employee("e2", "Bob", EmploymentType.casual)
        emp3 = make_employee("e3", "Cara", EmploymentType.part_time)
        employees = {"e1": emp1, "e2": emp2, "e3": emp3}
        scenario = build_remove_casuals_scenario(employees)
        mutated_ids = {m.employee_id for m in scenario.mutations}
        assert "e2" in mutated_ids
        assert "e1" not in mutated_ids
        assert "e3" not in mutated_ids

    def test_build_remove_casuals_applies_correctly(self):
        emp1 = make_employee("emp-1", "Alice", EmploymentType.full_time)
        emp3 = make_employee("emp-3", "Cara", EmploymentType.casual)
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = build_remove_casuals_scenario(employees)
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        emp_ids = {s.employee_id for s in result.roster.shifts}
        assert "emp-3" not in emp_ids

    def test_build_remove_casuals_date_filter(self):
        emp3 = make_employee("emp-3", "Cara", EmploymentType.casual)
        s_mon = make_shift("s-c1", "emp-3", WEEK_START)
        s_tue = make_shift("s-c2", "emp-3", WEEK_START + timedelta(days=1))
        roster = make_roster([s_mon, s_tue])
        employees = {"emp-3": emp3}
        venue = make_venue()
        scenario = build_remove_casuals_scenario(employees, date_filter=WEEK_START)
        result = apply_scenario(roster, employees, venue, [], scenario)
        dates = {s.date for s in result.roster.shifts}
        assert WEEK_START not in dates
        assert WEEK_START + timedelta(days=1) in dates

    def test_build_week_demand_scenario_covers_all_dates(self):
        forecasts = [
            make_forecast(WEEK_START + timedelta(days=d), 12, 60.0)
            for d in range(7)
        ]
        scenario = build_week_demand_scenario(forecasts, multiplier=1.2)
        mutation_dates = {m.date for m in scenario.mutations}
        forecast_dates = {f.date for f in forecasts}
        assert mutation_dates == forecast_dates

    def test_build_week_demand_scenario_multiplier_in_name(self):
        forecasts = [make_forecast(WEEK_START, 12, 60.0)]
        s_pos = build_week_demand_scenario(forecasts, 1.3)
        s_neg = build_week_demand_scenario(forecasts, 0.7)
        assert "+" in s_pos.name
        assert "-" in s_neg.name

    def test_build_week_demand_scenario_applies(self):
        roster, employees, venue, forecasts = base_roster_and_context()
        scenario = build_week_demand_scenario(forecasts, multiplier=2.0)
        result = apply_scenario(roster, employees, venue, forecasts, scenario)
        # 2x demand with same roster → more understaffed
        base_result = apply_scenario(roster, employees, venue, forecasts, Scenario(name="base", mutations=[]))
        assert result.understaffed_hours >= base_result.understaffed_hours
