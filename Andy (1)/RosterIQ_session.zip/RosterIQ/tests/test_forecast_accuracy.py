"""
Tests for forecast_accuracy — scoring and backtesting module.

Coverage
--------
- AccuracyMetrics: correctness of MAE, RMSE, MAPE, bias, R², within-band rates
- calculate_metrics: edge cases (empty, perfect, zero actuals, large bias)
- Temporal breakdowns: by_hour, by_weekday grouping
- Signal breakdown grouping
- walk-forward backtest(): window count, no look-ahead, metric types
- AccuracyTracker: record(), score(), rolling window, date filtering
- score_week() convenience helper
- worst_periods() helper
- _detect_improvement() slope detection
"""

import math
import pytest
from collections import defaultdict
from datetime import date, datetime, timedelta

from rosteriq.models import VenueConfig, State, DemandForecast, SignalType
from rosteriq.ensemble import (
    EnsembleForecaster,
    COLD_START_DAY_DEFAULTS,
    _get_hour_multiplier,
    DEFAULT_TRADING_HOURS,
    MIN_TRAINING_WEEKS,
)
from rosteriq.forecast_accuracy import (
    AccuracyMetrics,
    AccuracyTracker,
    BacktestReport,
    BacktestWindow,
    DailyBreakdown,
    ForecastRecord,
    HourlyBreakdown,
    SignalBreakdown,
    backtest,
    calculate_metrics,
    score_week,
    worst_periods,
    _detect_improvement,
    _records_by_hour,
    _records_by_weekday,
    _records_by_signal,
    _WEEKDAY_NAMES,
)


# ============================================================================
# Shared helpers
# ============================================================================

def make_venue() -> VenueConfig:
    return VenueConfig(
        id="venue-test",
        name="Test Venue",
        tanda_org_id="org-1",
        state=State.vic,
        max_labour_pct=32.0,
        created_at=datetime(2025, 1, 1),
    )


def make_record(
    predicted: float,
    actual: float,
    hour: int = 12,
    weekday_offset: int = 0,
    signals: list[SignalType] = None,
) -> ForecastRecord:
    """Build a minimal ForecastRecord for metric testing."""
    d = date(2026, 1, 5) + timedelta(days=weekday_offset)  # starts on a Monday
    return ForecastRecord(
        forecast_id=str(id(object())),
        venue_id="venue-test",
        forecast_date=d,
        hour=hour,
        predicted_covers=predicted,
        actual_covers=actual,
        confidence=0.8,
        model_version="cold_start_v1",
        signals_used=signals or [SignalType.historical],
    )


def make_historical_data(weeks: int, start: date = None) -> list[dict]:
    """Generate N weeks of synthetic venue data (6am–midnight)."""
    start = start or date(2026, 1, 5)
    data = []
    for week in range(weeks):
        for day in range(7):
            d = start + timedelta(weeks=week, days=day)
            base = COLD_START_DAY_DEFAULTS.get(d.weekday(), 50)
            for hour in range(6, 24):
                covers = base * _get_hour_multiplier(hour)
                data.append({"date": d, "hour": hour, "covers": covers})
    return data


def make_forecasts_and_actuals(
    target_date: date,
    hours: list[int] = None,
    bias: float = 0.0,
) -> tuple[list[DemandForecast], dict[date, dict[int, float]]]:
    """
    Return (forecasts, actuals) for a single day.
    bias > 0 means forecasts are inflated above actuals.
    """
    if hours is None:
        hours = list(range(12, 22))
    venue = make_venue()
    fc = EnsembleForecaster(venue)
    forecasts = fc.predict(target_date, hours=hours)
    # Actuals = predicted - bias (so bias=+5 → over-forecast by 5 covers)
    actuals: dict[date, dict[int, float]] = defaultdict(dict)
    for f in forecasts:
        actuals[f.date][f.hour] = max(0.0, f.predicted_covers - bias)
    return forecasts, actuals


# ============================================================================
# ForecastRecord properties
# ============================================================================

class TestForecastRecord:
    def test_error_positive(self):
        r = make_record(predicted=100, actual=80)
        assert r.error == pytest.approx(20.0)

    def test_error_negative(self):
        r = make_record(predicted=70, actual=90)
        assert r.error == pytest.approx(-20.0)

    def test_absolute_error(self):
        r = make_record(predicted=70, actual=90)
        assert r.absolute_error == pytest.approx(20.0)

    def test_percentage_error(self):
        r = make_record(predicted=110, actual=100)
        assert r.percentage_error == pytest.approx(0.10)

    def test_percentage_error_zero_actual(self):
        r = make_record(predicted=5, actual=0)
        assert r.percentage_error is None

    def test_perfect_prediction(self):
        r = make_record(predicted=50, actual=50)
        assert r.error == 0.0
        assert r.absolute_error == 0.0
        assert r.percentage_error == 0.0


# ============================================================================
# calculate_metrics — correctness
# ============================================================================

class TestCalculateMetrics:
    def test_empty_returns_zeros(self):
        m = calculate_metrics([])
        assert m.n == 0
        assert m.mae == 0.0
        assert m.rmse == 0.0
        assert m.mape == 0.0
        assert m.bias == 0.0
        assert m.r_squared == 0.0

    def test_perfect_forecasts(self):
        records = [make_record(100, 100) for _ in range(5)]
        m = calculate_metrics(records)
        assert m.mae == pytest.approx(0.0)
        assert m.rmse == pytest.approx(0.0)
        assert m.mape == pytest.approx(0.0)
        assert m.bias == pytest.approx(0.0)
        assert m.r_squared == pytest.approx(1.0)
        assert m.within_10_pct == pytest.approx(1.0)
        assert m.within_20_pct == pytest.approx(1.0)

    def test_mae_single_record(self):
        records = [make_record(110, 100)]
        m = calculate_metrics(records)
        assert m.mae == pytest.approx(10.0)

    def test_mae_multiple(self):
        # Errors: 10, 20, 30 → MAE = 20
        records = [
            make_record(110, 100),
            make_record(120, 100),
            make_record(130, 100),
        ]
        m = calculate_metrics(records)
        assert m.mae == pytest.approx(20.0)

    def test_rmse_larger_than_mae_when_variance(self):
        # Errors 10 and 30 → MAE=20, RMSE=sqrt((100+900)/2)=sqrt(500)≈22.36
        records = [make_record(110, 100), make_record(130, 100)]
        m = calculate_metrics(records)
        assert m.rmse > m.mae
        assert m.rmse == pytest.approx(math.sqrt(500), abs=0.01)

    def test_rmse_equals_mae_when_uniform_errors(self):
        # All errors == 10 → MAE == RMSE == 10
        records = [make_record(110, 100) for _ in range(4)]
        m = calculate_metrics(records)
        assert m.rmse == pytest.approx(m.mae, rel=1e-6)

    def test_mape_basic(self):
        # |110-100|/100 = 0.10
        records = [make_record(110, 100)]
        m = calculate_metrics(records)
        assert m.mape == pytest.approx(0.10, abs=0.001)

    def test_mape_skips_zero_actuals(self):
        records = [
            make_record(10, 0),   # skipped
            make_record(110, 100),  # 10%
        ]
        m = calculate_metrics(records)
        assert m.mape == pytest.approx(0.10, abs=0.001)

    def test_mape_all_zero_actuals(self):
        records = [make_record(10, 0), make_record(5, 0)]
        m = calculate_metrics(records)
        assert m.mape == pytest.approx(0.0)

    def test_bias_positive_when_over_forecast(self):
        # Predicted always above actual → positive bias
        records = [make_record(120, 100) for _ in range(3)]
        m = calculate_metrics(records)
        assert m.bias > 0

    def test_bias_negative_when_under_forecast(self):
        records = [make_record(80, 100) for _ in range(3)]
        m = calculate_metrics(records)
        assert m.bias < 0

    def test_bias_zero_on_symmetric_errors(self):
        # +10 and -10 should cancel
        records = [make_record(110, 100), make_record(90, 100)]
        m = calculate_metrics(records)
        assert m.bias == pytest.approx(0.0, abs=1e-9)

    def test_r_squared_perfect(self):
        # All predictions == actuals → R² = 1
        records = [make_record(float(v), float(v)) for v in [50, 70, 90, 110]]
        m = calculate_metrics(records)
        assert m.r_squared == pytest.approx(1.0, abs=0.001)

    def test_r_squared_negative_when_terrible(self):
        # Predictions wildly wrong
        records = [make_record(200, 10), make_record(200, 20), make_record(200, 15)]
        m = calculate_metrics(records)
        assert m.r_squared < 0

    def test_r_squared_clamped_to_minus_one(self):
        # Should never go below -1 due to clamping
        records = [make_record(1000, 1) for _ in range(5)]
        m = calculate_metrics(records)
        assert m.r_squared >= -1.0

    def test_within_10_pct(self):
        # 10% error → exactly at boundary → should count as within
        records = [make_record(110, 100)]
        m = calculate_metrics(records)
        assert m.within_10_pct == pytest.approx(1.0)

    def test_within_20_pct_excludes_larger_error(self):
        # 25% error → outside 20% band
        records = [make_record(125, 100)]
        m = calculate_metrics(records)
        assert m.within_20_pct == pytest.approx(0.0)

    def test_within_bands_mixed(self):
        # 5% err, 15% err, 25% err → 1/3 within 10%, 2/3 within 20%
        records = [
            make_record(105, 100),  # 5% — within both
            make_record(115, 100),  # 15% — within 20% only
            make_record(125, 100),  # 25% — outside both
        ]
        m = calculate_metrics(records)
        assert m.within_10_pct == pytest.approx(1 / 3, abs=0.001)
        assert m.within_20_pct == pytest.approx(2 / 3, abs=0.001)

    def test_n_equals_record_count(self):
        records = [make_record(100, 100) for _ in range(7)]
        m = calculate_metrics(records)
        assert m.n == 7

    def test_as_dict_keys(self):
        m = calculate_metrics([make_record(100, 100)])
        d = m.as_dict()
        for key in ("n", "mae", "rmse", "mape_pct", "bias", "r_squared",
                    "within_10_pct", "within_20_pct"):
            assert key in d

    def test_as_dict_mape_is_percentage(self):
        # mape=0.10 → mape_pct=10.0
        records = [make_record(110, 100)]
        m = calculate_metrics(records)
        assert m.as_dict()["mape_pct"] == pytest.approx(10.0, abs=0.01)


# ============================================================================
# Temporal breakdown helpers
# ============================================================================

class TestTemporalBreakdowns:
    def test_by_hour_groups_correctly(self):
        records = [
            make_record(100, 90, hour=12),
            make_record(100, 90, hour=12),
            make_record(100, 80, hour=19),
        ]
        breakdowns = _records_by_hour(records)
        hours = {b.hour for b in breakdowns}
        assert hours == {12, 19}

    def test_by_hour_sorted(self):
        records = [make_record(100, 90, hour=h) for h in [19, 12, 8]]
        breakdowns = _records_by_hour(records)
        assert [b.hour for b in breakdowns] == [8, 12, 19]

    def test_by_hour_metrics_per_group(self):
        # Hour 12: error 10; Hour 19: error 20
        records = [
            make_record(110, 100, hour=12),
            make_record(120, 100, hour=19),
        ]
        breakdowns = _records_by_hour(records)
        by_hour = {b.hour: b.metrics for b in breakdowns}
        assert by_hour[12].mae == pytest.approx(10.0)
        assert by_hour[19].mae == pytest.approx(20.0)

    def test_by_weekday_groups_correctly(self):
        # day 0 = Monday, day 4 = Friday (offset from 2026-01-05 which is Monday)
        records = [
            make_record(100, 90, weekday_offset=0),  # Monday
            make_record(100, 90, weekday_offset=4),  # Friday
        ]
        breakdowns = _records_by_weekday(records)
        weekdays = {b.weekday for b in breakdowns}
        assert weekdays == {0, 4}

    def test_by_weekday_names(self):
        records = [make_record(100, 90, weekday_offset=i) for i in range(7)]
        breakdowns = _records_by_weekday(records)
        names = {b.weekday_name for b in breakdowns}
        assert "Monday" in names
        assert "Saturday" in names
        assert "Sunday" in names

    def test_by_weekday_sorted(self):
        records = [make_record(100, 90, weekday_offset=i) for i in [4, 0, 2]]
        breakdowns = _records_by_weekday(records)
        assert [b.weekday for b in breakdowns] == sorted([0, 2, 4])


# ============================================================================
# Signal breakdown
# ============================================================================

class TestSignalBreakdown:
    def test_by_signal_groups_correctly(self):
        records = [
            make_record(100, 90, signals=[SignalType.historical]),
            make_record(100, 90, signals=[SignalType.weather]),
            make_record(100, 90, signals=[SignalType.historical, SignalType.bookings]),
        ]
        breakdowns = _records_by_signal(records)
        signal_types = {b.signal_type for b in breakdowns}
        assert SignalType.historical in signal_types
        assert SignalType.weather in signal_types
        assert SignalType.bookings in signal_types

    def test_multi_signal_record_counted_once_per_signal(self):
        # Record with 2 signals contributes to both groups
        record = make_record(100, 90, signals=[SignalType.historical, SignalType.weather])
        breakdowns = _records_by_signal([record])
        assert len(breakdowns) == 2
        for b in breakdowns:
            assert b.metrics.n == 1

    def test_empty_signals_list(self):
        records = [make_record(100, 90, signals=[])]
        breakdowns = _records_by_signal(records)
        assert breakdowns == []

    def test_as_dict_signal_type_is_string(self):
        records = [make_record(100, 90, signals=[SignalType.historical])]
        b = _records_by_signal(records)[0]
        d = b.as_dict()
        assert isinstance(d["signal_type"], str)


# ============================================================================
# _detect_improvement
# ============================================================================

class TestDetectImprovement:
    def _make_window(self, idx: int, mae: float) -> BacktestWindow:
        empty = AccuracyMetrics(
            n=10, mae=mae, rmse=mae * 1.2, mape=0.1,
            bias=0.0, r_squared=0.5,
            within_10_pct=0.7, within_20_pct=0.9,
        )
        return BacktestWindow(
            window_index=idx,
            train_start=date(2026, 1, 5),
            train_end=date(2026, 1, 19),
            test_start=date(2026, 1, 20),
            test_end=date(2026, 1, 26),
            train_weeks=2,
            metrics=empty,
            model_version="cold_start_v1",
        )

    def test_improving_trend(self):
        windows = [self._make_window(i, mae=30 - i * 3) for i in range(5)]
        assert _detect_improvement(windows) is True

    def test_worsening_trend(self):
        windows = [self._make_window(i, mae=10 + i * 5) for i in range(5)]
        assert _detect_improvement(windows) is False

    def test_flat_trend(self):
        windows = [self._make_window(i, mae=20) for i in range(5)]
        assert _detect_improvement(windows) is False

    def test_fewer_than_3_windows_returns_false(self):
        windows = [self._make_window(i, mae=10) for i in range(2)]
        assert _detect_improvement(windows) is False


# ============================================================================
# Walk-forward backtest()
# ============================================================================

class TestBacktest:
    def test_empty_data_returns_empty_report(self):
        report = backtest(make_venue(), [])
        assert report.total_windows == 0
        assert report.total_forecasts_scored == 0

    def test_insufficient_data_returns_empty_report(self):
        # 2 weeks of data, min_train_weeks=4 → not enough for any window
        data = make_historical_data(weeks=2)
        report = backtest(make_venue(), data, min_train_weeks=4)
        assert report.total_windows == 0

    def test_sufficient_data_produces_windows(self):
        # 6 weeks: first 4 train, week 5 test, week 6 test
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert report.total_windows >= 1

    def test_windows_have_no_overlap(self):
        data = make_historical_data(weeks=8)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        for i in range(len(report.windows) - 1):
            assert report.windows[i].test_end < report.windows[i + 1].test_start

    def test_train_end_before_test_start(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        for w in report.windows:
            assert w.train_end < w.test_start

    def test_no_lookahead(self):
        """Test data is never in the training set."""
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        for w in report.windows:
            assert w.train_end < w.test_start

    def test_overall_metrics_type(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert isinstance(report.overall, AccuracyMetrics)
        assert report.overall.n > 0

    def test_overall_mae_non_negative(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert report.overall.mae >= 0

    def test_by_hour_present(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert len(report.by_hour) > 0
        assert all(isinstance(h, HourlyBreakdown) for h in report.by_hour)

    def test_by_weekday_present(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert len(report.by_weekday) > 0
        assert all(isinstance(d, DailyBreakdown) for d in report.by_weekday)

    def test_by_signal_present(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert len(report.by_signal) >= 0  # may be empty if no signals recorded

    def test_worst_hour_is_valid_trading_hour(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        if report.worst_hour is not None:
            assert 0 <= report.worst_hour <= 23

    def test_best_hour_differs_from_worst(self):
        data = make_historical_data(weeks=8)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        if report.worst_hour is not None and report.best_hour is not None and len(report.by_hour) > 1:
            # They should differ unless all hours have identical MAE
            pass  # acceptable either way

    def test_venue_id_propagated(self):
        venue = make_venue()
        data = make_historical_data(weeks=6)
        report = backtest(venue, data, min_train_weeks=4, test_weeks=1)
        assert report.venue_id == venue.id

    def test_as_dict_serialisable(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        d = report.as_dict()
        assert isinstance(d, dict)
        assert "overall" in d
        assert "windows" in d
        assert "by_hour" in d
        assert "by_weekday" in d

    def test_generated_at_is_recent(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data)
        delta = (datetime.now() - report.generated_at).total_seconds()
        assert delta < 30

    def test_total_forecasts_scored_matches_records(self):
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)
        assert report.total_forecasts_scored == report.overall.n


# ============================================================================
# AccuracyTracker
# ============================================================================

class TestAccuracyTracker:
    def _tracker(self) -> AccuracyTracker:
        return AccuracyTracker(venue_id="venue-test")

    def test_initial_state(self):
        t = self._tracker()
        assert t.record_count == 0

    def test_record_returns_count(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        n = t.record(forecasts, actuals)
        assert n == len(forecasts)

    def test_record_count_increases(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(forecasts, actuals)
        assert t.record_count == len(forecasts)

    def test_unmatched_forecasts_not_recorded(self):
        t = self._tracker()
        forecasts, _ = make_forecasts_and_actuals(date(2026, 3, 2))
        # Provide empty actuals
        n = t.record(forecasts, {})
        assert n == 0
        assert t.record_count == 0

    def test_score_after_record(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(forecasts, actuals)
        report = t.score()
        assert report.total_forecasts_scored == len(forecasts)

    def test_score_empty_tracker(self):
        t = self._tracker()
        report = t.score()
        assert report.total_forecasts_scored == 0
        assert report.overall.n == 0

    def test_score_perfect_forecasts(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2), bias=0.0)
        t.record(forecasts, actuals)
        report = t.score()
        assert report.overall.mae == pytest.approx(0.0, abs=0.01)

    def test_score_bias_reflected(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2), bias=10.0)
        t.record(forecasts, actuals)
        report = t.score()
        # Predicted = actual + 10 → bias ≈ +10
        assert report.overall.bias == pytest.approx(10.0, abs=1.0)

    def test_rolling_window_drops_oldest(self):
        t = AccuracyTracker(venue_id="venue-test", max_records=5)
        for i in range(3):
            forecasts, actuals = make_forecasts_and_actuals(
                date(2026, 3, i + 1), hours=[12, 13]
            )
            t.record(forecasts, actuals)
        # 3 days × 2 hours = 6 > max_records=5 → oldest dropped
        assert t.record_count == 5

    def test_clear_removes_all(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(forecasts, actuals)
        t.clear()
        assert t.record_count == 0

    def test_recent_records_returns_n(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(forecasts, actuals)
        recent = t.recent_records(3)
        assert len(recent) == min(3, len(forecasts))

    def test_date_filter_since(self):
        t = self._tracker()
        for day in [1, 5, 10]:
            f, a = make_forecasts_and_actuals(date(2026, 3, day), hours=[12])
            t.record(f, a)
        report = t.score(since=date(2026, 3, 5))
        # Only days 5 and 10 should be included
        assert all(r.forecast_date >= date(2026, 3, 5) for r in t.recent_records(100))

    def test_date_filter_until(self):
        t = self._tracker()
        for day in [1, 5, 10]:
            f, a = make_forecasts_and_actuals(date(2026, 3, day), hours=[12])
            t.record(f, a)
        report = t.score(until=date(2026, 3, 5))
        assert report.total_forecasts_scored <= 2  # days 1 and 5

    def test_to_historical_data_format(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(forecasts, actuals)
        historical = t.to_historical_data()
        assert len(historical) == len(forecasts)
        for entry in historical:
            assert "date" in entry
            assert "hour" in entry
            assert "covers" in entry

    def test_to_historical_data_uses_actuals_not_predictions(self):
        t = self._tracker()
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2), bias=15.0)
        t.record(forecasts, actuals)
        historical = t.to_historical_data()
        # Actual covers = predicted - 15; historical should match actuals
        for h in historical:
            matched = [
                actuals[d][hr]
                for d, hrs in actuals.items()
                for hr, v in hrs.items()
                if d == h["date"] and hr == h["hour"]
            ]
            if matched:
                assert h["covers"] == pytest.approx(matched[0], abs=0.01)

    def test_accumulates_across_multiple_weeks(self):
        t = self._tracker()
        total = 0
        for week in range(3):
            d = date(2026, 3, 1) + timedelta(weeks=week)
            f, a = make_forecasts_and_actuals(d, hours=list(range(12, 18)))
            total += t.record(f, a)
        assert t.record_count == total

    def test_score_by_hour_present(self):
        t = self._tracker()
        f, a = make_forecasts_and_actuals(date(2026, 3, 2), hours=[12, 18, 19])
        t.record(f, a)
        report = t.score()
        assert len(report.by_hour) > 0

    def test_score_by_weekday_present(self):
        t = self._tracker()
        f, a = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(f, a)
        report = t.score()
        assert len(report.by_weekday) > 0

    def test_score_windows_empty(self):
        # AccuracyTracker.score() doesn't run walk-forward splits
        t = self._tracker()
        f, a = make_forecasts_and_actuals(date(2026, 3, 2))
        t.record(f, a)
        report = t.score()
        assert report.windows == []
        assert report.total_windows == 0


# ============================================================================
# score_week() helper
# ============================================================================

class TestScoreWeek:
    def test_returns_accuracy_metrics(self):
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        m = score_week(forecasts, actuals, venue_id="venue-test")
        assert isinstance(m, AccuracyMetrics)

    def test_perfect_week(self):
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2), bias=0.0)
        m = score_week(forecasts, actuals, venue_id="venue-test")
        assert m.mae == pytest.approx(0.0, abs=0.01)

    def test_biased_week(self):
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2), bias=5.0)
        m = score_week(forecasts, actuals, venue_id="venue-test")
        assert m.bias == pytest.approx(5.0, abs=1.0)

    def test_empty_actuals_returns_zero_n(self):
        forecasts, _ = make_forecasts_and_actuals(date(2026, 3, 2))
        m = score_week(forecasts, {}, venue_id="venue-test")
        assert m.n == 0

    def test_n_matches_paired_count(self):
        forecasts, actuals = make_forecasts_and_actuals(date(2026, 3, 2))
        m = score_week(forecasts, actuals, venue_id="venue-test")
        assert m.n == len(forecasts)


# ============================================================================
# worst_periods() helper
# ============================================================================

class TestWorstPeriods:
    def _make_report(self) -> BacktestReport:
        data = make_historical_data(weeks=6)
        return backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)

    def test_returns_hours_and_weekdays(self):
        report = self._make_report()
        result = worst_periods(report, top_n=3)
        assert "hours" in result
        assert "weekdays" in result

    def test_top_n_respected_hours(self):
        report = self._make_report()
        result = worst_periods(report, top_n=2)
        assert len(result["hours"]) <= 2

    def test_top_n_respected_weekdays(self):
        report = self._make_report()
        result = worst_periods(report, top_n=2)
        assert len(result["weekdays"]) <= 2

    def test_hours_sorted_worst_first(self):
        report = self._make_report()
        result = worst_periods(report, top_n=5)
        maes = [h["mae"] for h in result["hours"]]
        assert maes == sorted(maes, reverse=True)

    def test_weekdays_sorted_worst_first(self):
        report = self._make_report()
        result = worst_periods(report, top_n=7)
        maes = [d["mae"] for d in result["weekdays"]]
        assert maes == sorted(maes, reverse=True)

    def test_hour_keys_present(self):
        report = self._make_report()
        result = worst_periods(report, top_n=3)
        for h in result["hours"]:
            assert "hour" in h
            assert "mae" in h
            assert "mape_pct" in h

    def test_weekday_keys_present(self):
        report = self._make_report()
        result = worst_periods(report, top_n=3)
        for d in result["weekdays"]:
            assert "weekday" in d
            assert "name" in d
            assert "mae" in d

    def test_empty_report_returns_empty_lists(self):
        report = backtest(make_venue(), [])
        result = worst_periods(report)
        assert result["hours"] == []
        assert result["weekdays"] == []


# ============================================================================
# Integration — tracker → to_historical_data → re-train
# ============================================================================

class TestIntegration:
    def test_tracker_actuals_can_retrain_forecaster(self):
        """
        The actuals recorded by AccuracyTracker should be suitable as
        training data for the EnsembleForecaster (same dict format).
        """
        t = AccuracyTracker(venue_id="venue-test")
        for week in range(3):
            d = date(2026, 2, 2) + timedelta(weeks=week)
            f, a = make_forecasts_and_actuals(d)
            t.record(f, a)

        historical = t.to_historical_data()
        venue = make_venue()
        fc = EnsembleForecaster(venue)
        fc.add_historical_data(historical)  # should not raise
        assert len(fc.historical_data) == len(historical)

    def test_backtest_and_tracker_agree_on_coverage(self):
        """
        For a given dataset, both the walk-forward backtest and a manually
        populated tracker should report the same number of scored observations
        if we seed the tracker with identical pairs.
        """
        data = make_historical_data(weeks=6)
        report = backtest(make_venue(), data, min_train_weeks=4, test_weeks=1)

        if report.total_forecasts_scored == 0:
            pytest.skip("Insufficient data for comparison")

        # The overall MAE from backtest should be a real positive float
        assert report.overall.mae >= 0
        assert report.total_forecasts_scored > 0
