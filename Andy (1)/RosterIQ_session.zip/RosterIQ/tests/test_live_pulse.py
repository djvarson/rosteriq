"""
Tests for live_pulse — live headcount integration engine.

Coverage
--------
LivePulseSession.start()         — field initialisation, defaults
LivePulseSession.update_hour()   — advances hour, replaces signals
LivePulseSession.latest_count    — None before taps, correct after
LivePulseSession.tap_count       — increments on each record()

_build_headcount_signal()
    - over-forecast (positive value)
    - under-forecast (negative value)
    - exact match (zero value)
    - zero baseline (fallback)
    - confidence and weight constants

_build_signal_breakdown()
    - live headcount flagged is_live=True
    - sorted by contribution descending
    - contribution_pct sums to ~100%

_status_line() / _urgency()
    - ok state, on-target wording
    - understaffed high urgency
    - overstaffed high urgency
    - urgency thresholds (low/medium/high)

LivePulseEngine.record()
    - base roster not mutated
    - headcount appended to session history
    - variance in [-1, 1]
    - status matches breach
    - status "ok" when within threshold
    - recommendations non-empty when understaffed/overstaffed
    - accuracy tracker fed
    - adjusted_forecast != baseline when variance != 0
    - covers_per_staff computed
    - as_dict serialises cleanly

LivePulseEngine.session_summary()
    - empty session returns message
    - correct peak, avg, breach count

build_context_signals()
    - returns only non-zero signals
    - historical, bookings, weather, events all optional
    - each has correct signal_type
"""

import pytest
from datetime import date, datetime, time
from decimal import Decimal

from rosteriq.models import (
    AwardLevel, DemandForecast, Employee, EmploymentType,
    Shift, ShiftStatus, SignalType, State, VenueConfig, VarianceSignal,
)
from rosteriq.forecast_accuracy import AccuracyTracker
from rosteriq.live_pulse import (
    LiveHeadcount,
    LivePulseEngine,
    LivePulseSession,
    PulseResult,
    HEADCOUNT_CONFIDENCE,
    HEADCOUNT_SIGNAL_WEIGHT,
    VARIANCE_THRESHOLD,
    _build_headcount_signal,
    _build_signal_breakdown,
    _status_line,
    _urgency,
    build_context_signals,
)
from rosteriq.variance_engine import create_signal, DEFAULT_WEIGHTS


# ============================================================================
# Helpers
# ============================================================================

TODAY = date(2026, 4, 6)
HOUR = 19


def make_employee(
    eid="e1", name="Alice",
    etype=EmploymentType.full_time,
    rate=28.0,
) -> Employee:
    return Employee(
        id=eid, name=name, employment_type=etype,
        award_level=AwardLevel.level_3, state=State.vic,
        hourly_base_rate=Decimal(str(rate)),
        max_hours_per_week=38.0, consecutive_days_limit=6,
        created_at=datetime(2025, 1, 1), updated_at=datetime(2025, 1, 1),
    )


def make_shift(sid="s1", eid="e1", start=17, end=23) -> Shift:
    return Shift(
        id=sid, employee_id=eid, date=TODAY,
        start_time=time(start, 0), end_time=time(end % 24, 0),
        break_minutes=0, status=ShiftStatus.scheduled, role="floor",
    )


def make_weather_signal(impact=0.15) -> VarianceSignal:
    return VarianceSignal(
        signal_type=SignalType.weather,
        value=impact,
        weight=DEFAULT_WEIGHTS[SignalType.weather],
        confidence=0.75,
        source="weather_feed",
        timestamp=datetime.now(),
    )


def make_bookings_signal(actual=40, expected=35) -> VarianceSignal:
    return create_signal(
        signal_type=SignalType.bookings,
        actual=float(actual),
        expected=float(expected),
        confidence=0.85,
        source="resdiary",
    )


def base_session(
    forecast=80.0,
    signals=None,
    tracker=None,
) -> LivePulseSession:
    return LivePulseSession.start(
        venue_id="venue-1",
        forecast_covers=forecast,
        context_signals=signals or [],
        trading_date=TODAY,
        hour=HOUR,
        accuracy_tracker=tracker,
    )


# ============================================================================
# LivePulseSession.start()
# ============================================================================

class TestLivePulseSessionStart:

    def test_venue_id_set(self):
        s = base_session()
        assert s.venue_id == "venue-1"

    def test_baseline_forecast_set(self):
        s = base_session(forecast=95.0)
        assert s.baseline_forecast == 95.0

    def test_trading_date_set(self):
        s = base_session()
        assert s.trading_date == TODAY

    def test_hour_set(self):
        s = base_session()
        assert s.current_hour == HOUR

    def test_pulse_history_empty(self):
        s = base_session()
        assert s.pulse_history == []

    def test_tap_count_zero(self):
        s = base_session()
        assert s.tap_count == 0

    def test_latest_count_none_before_taps(self):
        s = base_session()
        assert s.latest_count is None

    def test_context_signals_stored(self):
        sig = make_weather_signal()
        s = base_session(signals=[sig])
        assert len(s.context_signals) == 1

    def test_session_id_unique(self):
        s1 = base_session()
        s2 = base_session()
        assert s1.session_id != s2.session_id

    def test_covers_per_staff_default(self):
        s = base_session()
        assert s.covers_per_staff_target == 15.0

    def test_accuracy_tracker_attached(self):
        tracker = AccuracyTracker(venue_id="venue-1")
        s = base_session(tracker=tracker)
        assert s.accuracy_tracker is tracker


class TestLivePulseSessionUpdateHour:

    def test_hour_updated(self):
        s = base_session()
        new_sig = make_weather_signal(0.05)
        s.update_hour(20, 90.0, [new_sig])
        assert s.current_hour == 20

    def test_forecast_updated(self):
        s = base_session(forecast=80.0)
        s.update_hour(20, 90.0, [])
        assert s.baseline_forecast == 90.0

    def test_signals_replaced(self):
        old_sig = make_weather_signal(0.15)
        s = base_session(signals=[old_sig])
        new_sig = make_weather_signal(0.05)
        s.update_hour(20, 90.0, [new_sig])
        assert s.context_signals[0].value == pytest.approx(0.05)

    def test_history_preserved_after_update(self):
        s = base_session()
        engine = LivePulseEngine()
        engine.record(s, actual_count=85)
        s.update_hour(20, 90.0, [])
        assert s.tap_count == 1


# ============================================================================
# _build_headcount_signal()
# ============================================================================

class TestBuildHeadcountSignal:

    def test_over_forecast_positive_value(self):
        sig = _build_headcount_signal(actual_count=100, baseline_forecast=80.0)
        assert sig.value > 0

    def test_under_forecast_negative_value(self):
        sig = _build_headcount_signal(actual_count=60, baseline_forecast=80.0)
        assert sig.value < 0

    def test_exact_match_zero_value(self):
        sig = _build_headcount_signal(actual_count=80, baseline_forecast=80.0)
        assert sig.value == pytest.approx(0.0, abs=1e-6)

    def test_zero_baseline_handled(self):
        sig = _build_headcount_signal(actual_count=50, baseline_forecast=0.0)
        assert -1.0 <= sig.value <= 1.0

    def test_confidence_is_maximum(self):
        sig = _build_headcount_signal(80, 80.0)
        assert sig.confidence == pytest.approx(HEADCOUNT_CONFIDENCE)

    def test_weight_is_boosted(self):
        sig = _build_headcount_signal(80, 80.0)
        assert sig.weight == pytest.approx(HEADCOUNT_SIGNAL_WEIGHT)

    def test_signal_type_is_pos_trends(self):
        sig = _build_headcount_signal(80, 80.0)
        assert sig.signal_type == SignalType.pos_trends

    def test_source_is_live_headcount(self):
        sig = _build_headcount_signal(80, 80.0)
        assert sig.source == "live_headcount"

    def test_value_clamped_to_range(self):
        sig = _build_headcount_signal(1000, 1.0)
        assert sig.value <= 1.0
        sig2 = _build_headcount_signal(0, 1000.0)
        assert sig2.value >= -1.0

    def test_25_pct_over_gives_correct_value(self):
        sig = _build_headcount_signal(100, 80.0)
        assert sig.value == pytest.approx(0.25, abs=0.001)

    def test_25_pct_under_gives_correct_value(self):
        sig = _build_headcount_signal(60, 80.0)
        assert sig.value == pytest.approx(-0.25, abs=0.001)


# ============================================================================
# _build_signal_breakdown()
# ============================================================================

class TestBuildSignalBreakdown:

    def _breakdown(self, actual=100, forecast=80.0, extra_signals=None):
        hc = _build_headcount_signal(actual, forecast)
        signals = extra_signals or [make_weather_signal(), make_bookings_signal()]
        return _build_signal_breakdown(signals, hc)

    def test_headcount_is_live_true(self):
        bd = self._breakdown()
        live_items = [r for r in bd if r["is_live"]]
        assert len(live_items) == 1

    def test_non_headcount_is_live_false(self):
        bd = self._breakdown()
        non_live = [r for r in bd if not r["is_live"]]
        assert all(not r["is_live"] for r in non_live)

    def test_contribution_pct_sums_near_100(self):
        bd = self._breakdown()
        total = sum(r["contribution_pct"] for r in bd)
        assert total == pytest.approx(100.0, abs=2.0)

    def test_sorted_by_contribution_desc(self):
        bd = self._breakdown()
        contribs = [r["contribution_pct"] for r in bd]
        assert contribs == sorted(contribs, reverse=True)

    def test_all_required_keys_present(self):
        bd = self._breakdown()
        for row in bd:
            for key in ("signal", "source", "value_pct", "direction", "confidence",
                        "weight", "contribution_pct", "is_live"):
                assert key in row

    def test_direction_above_when_positive(self):
        hc = _build_headcount_signal(100, 80.0)
        bd = _build_signal_breakdown([], hc)
        assert bd[0]["direction"] == "above"

    def test_direction_below_when_negative(self):
        hc = _build_headcount_signal(60, 80.0)
        bd = _build_signal_breakdown([], hc)
        assert bd[0]["direction"] == "below"

    def test_direction_on_target_when_zero(self):
        hc = _build_headcount_signal(80, 80.0)
        bd = _build_signal_breakdown([], hc)
        assert bd[0]["direction"] == "on target"


# ============================================================================
# _urgency()
# ============================================================================

class TestUrgency:

    def test_low_when_small_variance(self):
        assert _urgency(0.10, 10.0) == "low"

    def test_medium_when_moderate_variance(self):
        assert _urgency(0.25, 25.0) == "medium"

    def test_high_when_large_variance(self):
        assert _urgency(0.45, 45.0) == "high"

    def test_negative_variance_low(self):
        assert _urgency(-0.10, -10.0) == "low"

    def test_negative_variance_high(self):
        assert _urgency(-0.45, -45.0) == "high"

    def test_boundary_medium(self):
        assert _urgency(0.20, 20.0) == "medium"

    def test_boundary_high(self):
        assert _urgency(0.40, 40.0) == "high"


# ============================================================================
# _status_line()
# ============================================================================

class TestStatusLine:

    def _line(self, status="ok", variance=0.05, delta_pct=5.0,
              on_floor=5, suggested=5, actual=84, forecast=80.0, urgency="low"):
        return _status_line(
            variance=variance, delta_pct=delta_pct, status=status,
            urgency=urgency, on_floor=on_floor, suggested=suggested,
            actual_count=actual, baseline_forecast=forecast,
        )

    def test_ok_returns_string(self):
        assert isinstance(self._line(status="ok"), str)

    def test_ok_near_zero_says_on_track(self):
        line = self._line(status="ok", delta_pct=2.0, actual=82, forecast=80.0)
        assert "track" in line.lower() or "match" in line.lower()

    def test_understaffed_mentions_call(self):
        line = self._line(status="understaffed", variance=0.30, delta_pct=30.0,
                          on_floor=4, suggested=6, urgency="high", actual=104, forecast=80.0)
        assert any(w in line.lower() for w in ("call", "busy", "more"))

    def test_overstaffed_mentions_send_home(self):
        line = self._line(status="overstaffed", variance=-0.35, delta_pct=-35.0,
                          on_floor=8, suggested=4, urgency="high", actual=52, forecast=80.0)
        assert any(w in line.lower() for w in ("send", "home", "early", "quiet"))

    def test_non_empty_for_all_statuses(self):
        for status in ("ok", "understaffed", "overstaffed"):
            assert len(self._line(status=status)) > 0


# ============================================================================
# LivePulseEngine.record()
# ============================================================================

class TestLivePulseEngineRecord:

    def _record(self, actual=85, forecast=80.0, signals=None, tracker=None,
                active_shifts=None, available=None):
        session = base_session(forecast=forecast, signals=signals or [], tracker=tracker)
        engine = LivePulseEngine()
        emp1 = make_employee("e1", "Alice", EmploymentType.full_time)
        emp2 = make_employee("e2", "Bob", EmploymentType.casual)
        shifts = active_shifts if active_shifts is not None else [
            (emp1, make_shift("s1", "e1")),
            (emp2, make_shift("s2", "e2")),
        ]
        avail = available if available is not None else [make_employee("e3", "Cara", EmploymentType.casual)]
        return engine.record(session, actual, active_shifts=shifts, available_employees=avail), session

    def test_returns_pulse_result(self):
        result, _ = self._record()
        assert isinstance(result, PulseResult)

    def test_variance_in_range(self):
        result, _ = self._record(actual=85, forecast=80.0)
        assert -1.0 <= result.variance <= 1.0

    def test_headcount_appended_to_session(self):
        result, session = self._record(actual=85)
        assert session.tap_count == 1
        assert session.latest_count == 85

    def test_multiple_taps_accumulate(self):
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        for count in [80, 90, 100]:
            engine.record(session, count)
        assert session.tap_count == 3

    def test_status_ok_when_near_forecast(self):
        result, _ = self._record(actual=82, forecast=80.0)
        assert result.status == "ok"

    def test_status_understaffed_when_very_busy(self):
        # 120 actual vs 80 forecast = +50% — well above threshold
        result, _ = self._record(actual=120, forecast=80.0)
        assert result.status == "understaffed"

    def test_status_overstaffed_when_very_quiet(self):
        # 40 actual vs 80 forecast = -50%
        result, _ = self._record(actual=40, forecast=80.0)
        assert result.status == "overstaffed"

    def test_status_line_is_non_empty_string(self):
        result, _ = self._record()
        assert isinstance(result.status_line, str)
        assert len(result.status_line) > 0

    def test_signal_breakdown_non_empty(self):
        result, _ = self._record()
        assert len(result.signal_breakdown) >= 1

    def test_signal_breakdown_has_live_entry(self):
        result, _ = self._record()
        assert any(r["is_live"] for r in result.signal_breakdown)

    def test_recommendations_when_understaffed(self):
        result, _ = self._record(actual=160, forecast=80.0)
        # Should recommend calling someone in
        assert result.status == "understaffed"
        # recommendations may be empty if no available staff pass the threshold
        # but status must be correct
        assert result.status_line != ""

    def test_on_floor_now_matches_active_shifts(self):
        result, _ = self._record(actual=85)
        assert result.on_floor_now == 2   # two active shifts

    def test_suggested_floor_positive(self):
        result, _ = self._record(actual=85, forecast=80.0)
        assert result.suggested_floor >= 1

    def test_covers_per_staff_computed(self):
        result, _ = self._record(actual=90)
        # on_floor=2, actual=90 → covers_per_staff=45
        assert result.covers_per_staff == pytest.approx(45.0)

    def test_adjusted_forecast_differs_when_variance_nonzero(self):
        result, session = self._record(actual=120, forecast=80.0)
        assert result.adjusted_forecast != pytest.approx(session.baseline_forecast, abs=1.0)

    def test_adjusted_forecast_near_baseline_when_on_forecast(self):
        result, session = self._record(actual=80, forecast=80.0)
        # Near-zero variance → adjusted close to baseline
        assert abs(result.adjusted_forecast - session.baseline_forecast) < 15

    def test_forecast_delta_pct_positive_when_over(self):
        result, _ = self._record(actual=100, forecast=80.0)
        assert result.forecast_delta_pct > 0

    def test_forecast_delta_pct_negative_when_under(self):
        result, _ = self._record(actual=60, forecast=80.0)
        assert result.forecast_delta_pct < 0

    def test_accuracy_tracker_receives_record(self):
        tracker = AccuracyTracker(venue_id="venue-1")
        result, _ = self._record(tracker=tracker)
        assert tracker.record_count == 1

    def test_accuracy_tracker_uses_actual_count(self):
        tracker = AccuracyTracker(venue_id="venue-1")
        result, _ = self._record(actual=112, forecast=80.0, tracker=tracker)
        assert tracker._records[-1].actual_covers == pytest.approx(112.0)

    def test_accuracy_tracker_uses_baseline_as_predicted(self):
        tracker = AccuracyTracker(venue_id="venue-1")
        result, _ = self._record(actual=112, forecast=80.0, tracker=tracker)
        assert tracker._records[-1].predicted_covers == pytest.approx(80.0)

    def test_base_session_context_signals_not_mutated(self):
        weather = make_weather_signal()
        session = base_session(forecast=80.0, signals=[weather])
        engine = LivePulseEngine()
        original_len = len(session.context_signals)
        engine.record(session, 100)
        assert len(session.context_signals) == original_len

    def test_as_dict_serialises_cleanly(self):
        result, _ = self._record()
        d = result.as_dict()
        assert isinstance(d, dict)
        for key in ("headcount_id", "actual_count", "variance", "status",
                    "status_line", "adjusted_forecast", "recommendations",
                    "signal_breakdown", "on_floor_now", "suggested_floor"):
            assert key in d

    def test_as_dict_recommendations_is_list(self):
        result, _ = self._record()
        assert isinstance(result.as_dict()["recommendations"], list)

    def test_urgency_values_valid(self):
        result, _ = self._record()
        assert result.urgency in ("low", "medium", "high")

    def test_note_stored_in_headcount(self):
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        engine.record(session, 95, note="AFL crowd from MCG")
        assert session.pulse_history[0].note == "AFL crowd from MCG"

    def test_context_signals_influence_variance(self):
        # Strong positive events signal should push variance up even with moderate count
        events_sig = VarianceSignal(
            signal_type=SignalType.events,
            value=0.8,
            weight=DEFAULT_WEIGHTS[SignalType.events],
            confidence=0.9,
            source="test",
            timestamp=datetime.now(),
        )
        result_with, _ = self._record(actual=82, forecast=80.0, signals=[events_sig])
        result_without, _ = self._record(actual=82, forecast=80.0, signals=[])
        assert result_with.variance > result_without.variance


# ============================================================================
# LivePulseEngine.session_summary()
# ============================================================================

class TestSessionSummary:

    def test_empty_session_message(self):
        session = base_session()
        engine = LivePulseEngine()
        summary = engine.session_summary(session)
        assert "No headcounts" in summary["message"]
        assert summary["taps"] == 0

    def test_summary_after_taps(self):
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        for count in [75, 90, 110]:
            engine.record(session, count)
        summary = engine.session_summary(session)
        assert summary["taps"] == 3
        assert summary["peak_actual"] == 110
        assert summary["avg_actual"] == pytest.approx(91.67, abs=0.1)

    def test_tap_history_in_summary(self):
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        engine.record(session, 95, note="busy")
        summary = engine.session_summary(session)
        assert len(summary["tap_history"]) == 1
        assert summary["tap_history"][0]["count"] == 95
        assert summary["tap_history"][0]["note"] == "busy"

    def test_baseline_forecast_in_summary(self):
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        engine.record(session, 80)
        summary = engine.session_summary(session)
        assert summary["baseline_forecast"] == pytest.approx(80.0)

    def test_threshold_breaches_counted(self):
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        engine.record(session, 80)    # ok — no breach
        engine.record(session, 140)   # far above — breach
        engine.record(session, 30)    # far below — breach
        summary = engine.session_summary(session)
        assert summary["threshold_breaches"] >= 2

    def test_date_in_summary(self):
        session = base_session()
        engine = LivePulseEngine()
        engine.record(session, 85)
        summary = engine.session_summary(session)
        assert summary["date"] == TODAY.isoformat()


# ============================================================================
# build_context_signals()
# ============================================================================

class TestBuildContextSignals:

    def test_empty_returns_empty_list(self):
        sigs = build_context_signals(forecast_covers=80.0)
        assert sigs == []

    def test_historical_signal_included_when_nonzero(self):
        sigs = build_context_signals(forecast_covers=80.0, historical_avg=75.0)
        types = [s.signal_type for s in sigs]
        assert SignalType.historical in types

    def test_bookings_signal_included_when_forecast_nonzero(self):
        sigs = build_context_signals(forecast_covers=80.0, booking_count=35, booking_forecast=30.0)
        types = [s.signal_type for s in sigs]
        assert SignalType.bookings in types

    def test_weather_signal_included_when_impact_nonzero(self):
        sigs = build_context_signals(forecast_covers=80.0, weather_impact_pct=0.15)
        types = [s.signal_type for s in sigs]
        assert SignalType.weather in types

    def test_events_signal_included_when_impact_nonzero(self):
        sigs = build_context_signals(forecast_covers=80.0, event_impact_pct=0.25)
        types = [s.signal_type for s in sigs]
        assert SignalType.events in types

    def test_zero_impacts_produce_no_weather_or_events(self):
        sigs = build_context_signals(
            forecast_covers=80.0,
            weather_impact_pct=0.0,
            event_impact_pct=0.0,
        )
        types = [s.signal_type for s in sigs]
        assert SignalType.weather not in types
        assert SignalType.events not in types

    def test_all_signals_have_valid_confidence(self):
        sigs = build_context_signals(
            forecast_covers=80.0,
            historical_avg=75.0,
            booking_count=30, booking_forecast=25.0,
            weather_impact_pct=0.10,
            event_impact_pct=0.20,
        )
        for s in sigs:
            assert 0.0 <= s.confidence <= 1.0

    def test_all_signals_have_valid_weight(self):
        sigs = build_context_signals(
            forecast_covers=80.0,
            historical_avg=75.0,
            weather_impact_pct=0.10,
        )
        for s in sigs:
            assert 0.0 <= s.weight <= 1.0

    def test_all_signals_have_valid_value(self):
        sigs = build_context_signals(
            forecast_covers=80.0,
            historical_avg=75.0,
            booking_count=30, booking_forecast=25.0,
            weather_impact_pct=0.10,
            event_impact_pct=0.20,
        )
        for s in sigs:
            assert -1.0 <= s.value <= 1.0

    def test_weather_value_clamped(self):
        sigs = build_context_signals(forecast_covers=80.0, weather_impact_pct=5.0)
        weather = next(s for s in sigs if s.signal_type == SignalType.weather)
        assert weather.value <= 1.0

    def test_negative_weather_impact(self):
        sigs = build_context_signals(forecast_covers=80.0, weather_impact_pct=-0.20)
        weather = next(s for s in sigs if s.signal_type == SignalType.weather)
        assert weather.value < 0


# ============================================================================
# Integration — full headcount flow feeds accuracy tracker
# ============================================================================

class TestIntegration:

    def test_full_service_flow(self):
        """
        Simulate a full service: load context, record taps every 30 min,
        check that the tracker accumulates records for each tap.
        """
        tracker = AccuracyTracker(venue_id="venue-1")
        context = build_context_signals(
            forecast_covers=80.0,
            historical_avg=78.0,
            booking_count=32, booking_forecast=28.0,
            weather_impact_pct=0.10,
            event_impact_pct=0.25,
        )
        session = LivePulseSession.start(
            venue_id="venue-1",
            forecast_covers=80.0,
            context_signals=context,
            trading_date=TODAY,
            hour=18,
            accuracy_tracker=tracker,
        )
        engine = LivePulseEngine()
        counts = [75, 88, 102, 115, 108, 92, 78, 65]
        for count in counts:
            engine.record(session, count)

        assert session.tap_count == len(counts)
        assert tracker.record_count == len(counts)

        # All tracker records should use correct venue and forecast
        for rec in tracker._records:
            assert rec.venue_id == "venue-1"
            assert rec.predicted_covers == pytest.approx(80.0)

    def test_hour_update_resets_baseline_not_history(self):
        """
        Advancing to a new hour refreshes the forecast but keeps tap history.
        """
        session = base_session(forecast=80.0)
        engine = LivePulseEngine()
        engine.record(session, 85)
        assert session.tap_count == 1

        new_context = build_context_signals(
            forecast_covers=95.0, historical_avg=90.0
        )
        session.update_hour(20, 95.0, new_context)
        assert session.current_hour == 20
        assert session.baseline_forecast == 95.0
        assert session.tap_count == 1   # history preserved

    def test_accuracy_tracker_score_after_taps(self):
        """
        Taps recorded through the engine can be scored by AccuracyTracker.score().
        """
        tracker = AccuracyTracker(venue_id="venue-1")
        session = base_session(forecast=80.0, tracker=tracker)
        engine = LivePulseEngine()
        for count in [78, 82, 85, 79, 81]:
            engine.record(session, count)

        report = tracker.score()
        assert report.total_forecasts_scored == 5
        assert report.overall.mae >= 0
        # These counts are close to 80 so MAPE should be small
        assert report.overall.mape < 0.15
