"""
Forecast accuracy scoring and backtesting module for RosterIQ.

Provides tools to measure, track, and improve the ensemble forecaster's
accuracy over time by comparing past predictions against actual POS data.

Core capabilities
-----------------
1. **Accuracy metrics** — MAE, RMSE, MAPE, and bias for any set of
   (predicted, actual) pairs.

2. **Walk-forward backtesting** — train on weeks 1–N, predict week N+1,
   then slide the window forward. Mirrors real-world conditions so the
   accuracy score is honest (no look-ahead bias).

3. **Signal attribution** — break accuracy down by the dominant signal
   type used in each forecast so you can see which signals actually help.

4. **Temporal breakdown** — accuracy by hour-of-day (lunch vs dinner vs
   shoulder) and day-of-week (weekday vs weekend vs public holiday) to
   identify where the model struggles most.

5. **AccuracyTracker** — a persistent tracker that accumulates
   (forecast, actual) pairs week-by-week and re-scores on demand.
   Designed to sit alongside the EnsembleForecaster in the API layer.

Metric definitions
------------------
- MAE   : Mean Absolute Error — average absolute miss in covers.
- RMSE  : Root Mean Squared Error — penalises large misses more.
- MAPE  : Mean Absolute Percentage Error — relative error, comparable
          across venues. Skips hours where actual == 0 to avoid division.
- Bias  : Signed mean error (predicted − actual). Positive = over-forecast.
- R²    : Coefficient of determination — how much variance is explained.
          1.0 is perfect; 0.0 is no better than predicting the mean.

Usage
-----
    from rosteriq.forecast_accuracy import backtest, AccuracyTracker

    # One-shot backtest on historical data
    report = backtest(forecaster, historical_data, min_train_weeks=4)

    # Ongoing tracking
    tracker = AccuracyTracker(venue_id="venue-1")
    tracker.record(forecasts, actuals)  # call each week after close
    summary = tracker.score()
"""

from __future__ import annotations

import math
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Optional

from rosteriq.models import DemandForecast, SignalType, VenueConfig
from rosteriq.ensemble import EnsembleForecaster, MIN_TRAINING_WEEKS


# ============================================================================
# Data transfer objects
# ============================================================================


@dataclass
class AccuracyMetrics:
    """
    Accuracy metrics for a set of forecast vs actual comparisons.

    All cover counts are in the same unit as the input data (typically
    covers/customers per hour). MAPE is expressed as a fraction (0.15 = 15%).
    """

    n: int                          # Number of (predicted, actual) pairs scored
    mae: float                      # Mean Absolute Error (covers)
    rmse: float                     # Root Mean Squared Error (covers)
    mape: float                     # Mean Absolute Percentage Error (fraction)
    bias: float                     # Signed mean error, + = over-forecast (covers)
    r_squared: float                # Coefficient of determination (-inf to 1.0)
    within_10_pct: float            # Fraction of forecasts within ±10% of actual
    within_20_pct: float            # Fraction of forecasts within ±20% of actual

    def as_dict(self) -> dict:
        return {
            "n": self.n,
            "mae": round(self.mae, 2),
            "rmse": round(self.rmse, 2),
            "mape_pct": round(self.mape * 100, 1),
            "bias": round(self.bias, 2),
            "r_squared": round(self.r_squared, 3),
            "within_10_pct": round(self.within_10_pct * 100, 1),
            "within_20_pct": round(self.within_20_pct * 100, 1),
        }


@dataclass
class HourlyBreakdown:
    """Accuracy metrics grouped by hour of day."""

    hour: int
    metrics: AccuracyMetrics

    def as_dict(self) -> dict:
        return {"hour": self.hour, **self.metrics.as_dict()}


@dataclass
class DailyBreakdown:
    """Accuracy metrics grouped by day of week (0=Mon, 6=Sun)."""

    weekday: int                    # 0 = Monday … 6 = Sunday
    weekday_name: str
    metrics: AccuracyMetrics

    def as_dict(self) -> dict:
        return {
            "weekday": self.weekday,
            "weekday_name": self.weekday_name,
            **self.metrics.as_dict(),
        }


@dataclass
class SignalBreakdown:
    """Accuracy metrics for forecasts that used a specific signal type."""

    signal_type: SignalType
    metrics: AccuracyMetrics

    def as_dict(self) -> dict:
        return {
            "signal_type": self.signal_type.value,
            **self.metrics.as_dict(),
        }


@dataclass
class BacktestWindow:
    """Results for a single walk-forward backtest window."""

    window_index: int
    train_start: date
    train_end: date
    test_start: date
    test_end: date
    train_weeks: int
    metrics: AccuracyMetrics
    model_version: str

    def as_dict(self) -> dict:
        return {
            "window_index": self.window_index,
            "train_start": self.train_start.isoformat(),
            "train_end": self.train_end.isoformat(),
            "test_start": self.test_start.isoformat(),
            "test_end": self.test_end.isoformat(),
            "train_weeks": self.train_weeks,
            "model_version": self.model_version,
            **self.metrics.as_dict(),
        }


@dataclass
class BacktestReport:
    """
    Full backtesting report produced by the ``backtest()`` function.

    Aggregates results across all walk-forward windows plus breakdowns
    by hour, day-of-week, and signal type.
    """

    venue_id: str
    generated_at: datetime
    total_windows: int
    total_forecasts_scored: int
    overall: AccuracyMetrics
    windows: list[BacktestWindow]
    by_hour: list[HourlyBreakdown]
    by_weekday: list[DailyBreakdown]
    by_signal: list[SignalBreakdown]
    model_improving: bool           # True if later windows have lower MAE
    worst_hour: Optional[int]       # Hour with highest MAE
    best_hour: Optional[int]        # Hour with lowest MAE
    worst_weekday: Optional[int]    # Weekday with highest MAE

    def as_dict(self) -> dict:
        return {
            "venue_id": self.venue_id,
            "generated_at": self.generated_at.isoformat(),
            "total_windows": self.total_windows,
            "total_forecasts_scored": self.total_forecasts_scored,
            "overall": self.overall.as_dict(),
            "windows": [w.as_dict() for w in self.windows],
            "by_hour": [h.as_dict() for h in self.by_hour],
            "by_weekday": [d.as_dict() for d in self.by_weekday],
            "by_signal": [s.as_dict() for s in self.by_signal],
            "model_improving": self.model_improving,
            "worst_hour": self.worst_hour,
            "best_hour": self.best_hour,
            "worst_weekday": self.worst_weekday,
        }


@dataclass
class ForecastRecord:
    """
    A single paired (forecast, actual) observation stored by AccuracyTracker.
    """

    forecast_id: str
    venue_id: str
    forecast_date: date
    hour: int
    predicted_covers: float
    actual_covers: float
    confidence: float
    model_version: str
    signals_used: list[SignalType] = field(default_factory=list)
    recorded_at: datetime = field(default_factory=datetime.now)

    @property
    def error(self) -> float:
        """Signed error: predicted − actual."""
        return self.predicted_covers - self.actual_covers

    @property
    def absolute_error(self) -> float:
        return abs(self.error)

    @property
    def percentage_error(self) -> Optional[float]:
        """Absolute percentage error, or None if actual == 0."""
        if self.actual_covers == 0:
            return None
        return abs(self.error) / self.actual_covers


# ============================================================================
# Core metric calculation
# ============================================================================

_WEEKDAY_NAMES = [
    "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday",
]


def calculate_metrics(records: list[ForecastRecord]) -> AccuracyMetrics:
    """
    Calculate accuracy metrics from a list of ForecastRecord pairs.

    Args:
        records: Paired forecast/actual observations.

    Returns:
        AccuracyMetrics. If records is empty, returns a zero-filled instance
        with n=0 and r_squared=0.

    Raises:
        ValueError: If records contains entries with negative actual_covers.
    """
    if not records:
        return AccuracyMetrics(
            n=0, mae=0.0, rmse=0.0, mape=0.0,
            bias=0.0, r_squared=0.0,
            within_10_pct=0.0, within_20_pct=0.0,
        )

    n = len(records)
    errors = [r.error for r in records]
    abs_errors = [abs(e) for e in errors]
    sq_errors = [e ** 2 for e in errors]

    mae = sum(abs_errors) / n
    rmse = math.sqrt(sum(sq_errors) / n)
    bias = sum(errors) / n

    # MAPE — skip zero-actual hours to avoid division by zero
    pct_errors = [r.percentage_error for r in records if r.percentage_error is not None]
    mape = sum(pct_errors) / len(pct_errors) if pct_errors else 0.0

    # R² = 1 − SS_res / SS_tot
    actuals = [r.actual_covers for r in records]
    mean_actual = sum(actuals) / n
    ss_res = sum((a - p) ** 2 for r in records for a, p in [(r.actual_covers, r.predicted_covers)])
    ss_tot = sum((a - mean_actual) ** 2 for a in actuals)
    if ss_tot == 0:
        r_squared = 1.0 if ss_res == 0 else 0.0  # perfect or no variance to explain
    else:
        r_squared = 1.0 - (ss_res / ss_tot)

    # Within-N-pct bands
    within_10 = sum(
        1 for r in records
        if r.actual_covers == 0 or abs(r.error) / r.actual_covers <= 0.10
    )
    within_20 = sum(
        1 for r in records
        if r.actual_covers == 0 or abs(r.error) / r.actual_covers <= 0.20
    )

    return AccuracyMetrics(
        n=n,
        mae=mae,
        rmse=rmse,
        mape=mape,
        bias=bias,
        r_squared=max(-1.0, r_squared),  # clamp for degenerate cases
        within_10_pct=within_10 / n,
        within_20_pct=within_20 / n,
    )


def _records_by_hour(records: list[ForecastRecord]) -> list[HourlyBreakdown]:
    """Group records by hour and compute metrics per hour."""
    by_hour: dict[int, list[ForecastRecord]] = defaultdict(list)
    for r in records:
        by_hour[r.hour].append(r)

    return [
        HourlyBreakdown(hour=h, metrics=calculate_metrics(hrs))
        for h, hrs in sorted(by_hour.items())
    ]


def _records_by_weekday(records: list[ForecastRecord]) -> list[DailyBreakdown]:
    """Group records by weekday and compute metrics per day."""
    by_day: dict[int, list[ForecastRecord]] = defaultdict(list)
    for r in records:
        by_day[r.forecast_date.weekday()].append(r)

    return [
        DailyBreakdown(
            weekday=wd,
            weekday_name=_WEEKDAY_NAMES[wd],
            metrics=calculate_metrics(recs),
        )
        for wd, recs in sorted(by_day.items())
    ]


def _records_by_signal(records: list[ForecastRecord]) -> list[SignalBreakdown]:
    """
    Group records by the signals used in each forecast.

    A record contributes to every signal type listed in signals_used,
    so totals across signals will exceed total record count.
    """
    by_signal: dict[SignalType, list[ForecastRecord]] = defaultdict(list)
    for r in records:
        for sig in r.signals_used:
            by_signal[sig].append(r)

    return [
        SignalBreakdown(signal_type=sig, metrics=calculate_metrics(recs))
        for sig, recs in sorted(by_signal.items(), key=lambda x: x[0].value)
    ]


def _detect_improvement(windows: list[BacktestWindow]) -> bool:
    """
    Return True if later backtest windows show lower MAE than earlier ones.

    Uses a simple linear regression on (window_index, MAE) and checks
    whether the slope is negative.
    """
    if len(windows) < 3:
        return False

    xs = list(range(len(windows)))
    ys = [w.metrics.mae for w in windows]
    n = len(xs)
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if denominator == 0:
        return False
    slope = numerator / denominator
    return slope < 0


# ============================================================================
# Walk-forward backtesting
# ============================================================================


def backtest(
    venue_config: VenueConfig,
    historical_data: list[dict],
    min_train_weeks: int = MIN_TRAINING_WEEKS,
    test_weeks: int = 1,
) -> BacktestReport:
    """
    Walk-forward backtest of the EnsembleForecaster on historical data.

    The data is split into rolling windows: the forecaster trains on
    the first N weeks, predicts the next ``test_weeks`` week(s), then
    the window slides forward. This avoids look-ahead bias and gives an
    honest picture of how accurate the model would have been in practice.

    Minimum data requirement: min_train_weeks + test_weeks weeks total.
    If the data is insufficient, the report will have 0 windows and will
    note this via total_windows == 0.

    Args:
        venue_config: Venue configuration (used to initialise the forecaster).
        historical_data: List of dicts, each with 'date' (date), 'hour' (int),
            and 'covers' (float).
        min_train_weeks: Minimum weeks of training data before the first
            prediction window (default 4).
        test_weeks: Number of weeks to forecast per window (default 1).

    Returns:
        BacktestReport with per-window results plus aggregated breakdowns.
    """
    if not historical_data:
        return _empty_report(venue_config.id)

    # Sort and index data by date
    data_by_date: dict[date, list[dict]] = defaultdict(list)
    for entry in historical_data:
        data_by_date[entry["date"]].append(entry)

    all_dates = sorted(data_by_date.keys())
    if len(all_dates) < 2:
        return _empty_report(venue_config.id)

    # Identify week boundaries (Monday-aligned)
    first_monday = all_dates[0] - timedelta(days=all_dates[0].weekday())
    last_date = all_dates[-1]

    all_records: list[ForecastRecord] = []
    windows: list[BacktestWindow] = []
    window_index = 0

    train_start = first_monday
    while True:
        train_end = train_start + timedelta(weeks=min_train_weeks) - timedelta(days=1)
        test_start = train_end + timedelta(days=1)
        test_end = test_start + timedelta(weeks=test_weeks) - timedelta(days=1)

        if test_end > last_date:
            break

        # Build training data up to train_end
        train_data = [
            entry for entry in historical_data
            if entry["date"] <= train_end
        ]

        # Build test actuals for the test window
        test_data_by_date: dict[date, dict[int, float]] = defaultdict(dict)
        for entry in historical_data:
            if test_start <= entry["date"] <= test_end:
                test_data_by_date[entry["date"]][entry["hour"]] = entry["covers"]

        if not test_data_by_date:
            train_start += timedelta(weeks=1)
            continue

        # Train forecaster on historical slice
        forecaster = EnsembleForecaster(venue_config)
        forecaster.add_historical_data(train_data)
        forecaster.train()

        # Predict each day in the test window
        window_records: list[ForecastRecord] = []
        current = test_start
        while current <= test_end:
            if current in test_data_by_date:
                actuals = test_data_by_date[current]
                forecasts = forecaster.predict(current, hours=list(actuals.keys()))
                for f in forecasts:
                    if f.hour in actuals:
                        window_records.append(ForecastRecord(
                            forecast_id=f.id,
                            venue_id=venue_config.id,
                            forecast_date=current,
                            hour=f.hour,
                            predicted_covers=f.predicted_covers,
                            actual_covers=actuals[f.hour],
                            confidence=f.confidence,
                            model_version=f.model_version,
                            signals_used=list(f.signals_used),
                        ))
            current += timedelta(days=1)

        if window_records:
            weeks_used = max(1, (train_end - train_start).days // 7)
            w = BacktestWindow(
                window_index=window_index,
                train_start=train_start,
                train_end=train_end,
                test_start=test_start,
                test_end=test_end,
                train_weeks=weeks_used,
                metrics=calculate_metrics(window_records),
                model_version=forecaster.get_model_status()["model_version"],
            )
            windows.append(w)
            all_records.extend(window_records)
            window_index += 1

        train_start += timedelta(weeks=1)

    if not all_records:
        return _empty_report(venue_config.id)

    overall = calculate_metrics(all_records)
    by_hour = _records_by_hour(all_records)
    by_weekday = _records_by_weekday(all_records)
    by_signal = _records_by_signal(all_records)

    worst_hour = max(by_hour, key=lambda h: h.metrics.mae).hour if by_hour else None
    best_hour = min(by_hour, key=lambda h: h.metrics.mae).hour if by_hour else None
    worst_weekday = max(by_weekday, key=lambda d: d.metrics.mae).weekday if by_weekday else None

    return BacktestReport(
        venue_id=venue_config.id,
        generated_at=datetime.now(),
        total_windows=len(windows),
        total_forecasts_scored=len(all_records),
        overall=overall,
        windows=windows,
        by_hour=by_hour,
        by_weekday=by_weekday,
        by_signal=by_signal,
        model_improving=_detect_improvement(windows),
        worst_hour=worst_hour,
        best_hour=best_hour,
        worst_weekday=worst_weekday,
    )


def _empty_report(venue_id: str) -> BacktestReport:
    """Return a zero-result BacktestReport when no data is available."""
    empty_metrics = AccuracyMetrics(
        n=0, mae=0.0, rmse=0.0, mape=0.0,
        bias=0.0, r_squared=0.0,
        within_10_pct=0.0, within_20_pct=0.0,
    )
    return BacktestReport(
        venue_id=venue_id,
        generated_at=datetime.now(),
        total_windows=0,
        total_forecasts_scored=0,
        overall=empty_metrics,
        windows=[],
        by_hour=[],
        by_weekday=[],
        by_signal=[],
        model_improving=False,
        worst_hour=None,
        best_hour=None,
        worst_weekday=None,
    )


# ============================================================================
# Ongoing accuracy tracker
# ============================================================================


class AccuracyTracker:
    """
    Persistent accuracy tracker for a single venue.

    Designed to be kept alive alongside the EnsembleForecaster in the API
    layer. Each week after trading closes, call ``record()`` with that
    week's forecasts and actual POS data. Call ``score()`` at any time to
    get up-to-date metrics.

    Example
    -------
        tracker = AccuracyTracker(venue_id="venue-1")

        # Each week after close
        tracker.record(forecasts, actuals_by_date_hour)

        # On demand
        summary = tracker.score()
        print(summary.overall.as_dict())
    """

    def __init__(self, venue_id: str, max_records: int = 10_000):
        """
        Initialise the tracker.

        Args:
            venue_id: ID of the venue being tracked.
            max_records: Maximum records to retain. Older records are
                discarded when the limit is exceeded (rolling window).
        """
        self.venue_id = venue_id
        self.max_records = max_records
        self._records: list[ForecastRecord] = []

    def record(
        self,
        forecasts: list[DemandForecast],
        actuals: dict[date, dict[int, float]],
    ) -> int:
        """
        Record a batch of forecast vs actual pairs.

        Args:
            forecasts: DemandForecast objects from the ensemble.
            actuals: Nested dict mapping date → hour → actual cover count.
                     Only hours present in both forecasts and actuals are scored.

        Returns:
            Number of new pairs recorded.
        """
        new_records = []
        for f in forecasts:
            if f.date in actuals and f.hour in actuals[f.date]:
                new_records.append(ForecastRecord(
                    forecast_id=f.id,
                    venue_id=self.venue_id,
                    forecast_date=f.date,
                    hour=f.hour,
                    predicted_covers=f.predicted_covers,
                    actual_covers=actuals[f.date][f.hour],
                    confidence=f.confidence,
                    model_version=f.model_version,
                    signals_used=list(f.signals_used),
                ))

        self._records.extend(new_records)

        # Rolling window: drop oldest records if over limit
        if len(self._records) > self.max_records:
            self._records = self._records[-self.max_records:]

        return len(new_records)

    def score(
        self,
        since: Optional[date] = None,
        until: Optional[date] = None,
    ) -> BacktestReport:
        """
        Score all recorded pairs and return a BacktestReport.

        Args:
            since: Only score records on or after this date.
            until: Only score records on or before this date.

        Returns:
            BacktestReport. The ``windows`` field will be empty (the tracker
            doesn't re-run walk-forward splits — use ``backtest()`` for that).
            All other breakdown fields are populated.
        """
        records = self._records
        if since:
            records = [r for r in records if r.forecast_date >= since]
        if until:
            records = [r for r in records if r.forecast_date <= until]

        if not records:
            return _empty_report(self.venue_id)

        overall = calculate_metrics(records)
        by_hour = _records_by_hour(records)
        by_weekday = _records_by_weekday(records)
        by_signal = _records_by_signal(records)

        worst_hour = max(by_hour, key=lambda h: h.metrics.mae).hour if by_hour else None
        best_hour = min(by_hour, key=lambda h: h.metrics.mae).hour if by_hour else None
        worst_weekday = max(by_weekday, key=lambda d: d.metrics.mae).weekday if by_weekday else None

        return BacktestReport(
            venue_id=self.venue_id,
            generated_at=datetime.now(),
            total_windows=0,      # tracker doesn't run walk-forward splits
            total_forecasts_scored=len(records),
            overall=overall,
            windows=[],
            by_hour=by_hour,
            by_weekday=by_weekday,
            by_signal=by_signal,
            model_improving=False,
            worst_hour=worst_hour,
            best_hour=best_hour,
            worst_weekday=worst_weekday,
        )

    @property
    def record_count(self) -> int:
        return len(self._records)

    def clear(self) -> None:
        """Remove all stored records."""
        self._records = []

    def recent_records(self, n: int = 100) -> list[ForecastRecord]:
        """Return the most recent N records."""
        return self._records[-n:]

    def to_historical_data(self) -> list[dict]:
        """
        Export actual covers as a historical data list compatible with
        EnsembleForecaster.add_historical_data().

        Useful for re-training the forecaster on confirmed actuals rather
        than on the original POS CSV import.
        """
        return [
            {
                "date": r.forecast_date,
                "hour": r.hour,
                "covers": r.actual_covers,
            }
            for r in self._records
        ]


# ============================================================================
# Convenience helpers for the API layer
# ============================================================================


def score_week(
    forecasts: list[DemandForecast],
    actuals: dict[date, dict[int, float]],
    venue_id: str,
) -> AccuracyMetrics:
    """
    Quick one-shot scoring of a single week's forecasts.

    Convenience wrapper that doesn't require an AccuracyTracker instance.

    Args:
        forecasts: Forecasts produced for the week.
        actuals: Actual covers indexed by date → hour.
        venue_id: Venue identifier (used for ForecastRecord metadata only).

    Returns:
        AccuracyMetrics for the paired observations found.
    """
    records = []
    for f in forecasts:
        if f.date in actuals and f.hour in actuals[f.date]:
            records.append(ForecastRecord(
                forecast_id=f.id,
                venue_id=venue_id,
                forecast_date=f.date,
                hour=f.hour,
                predicted_covers=f.predicted_covers,
                actual_covers=actuals[f.date][f.hour],
                confidence=f.confidence,
                model_version=f.model_version,
                signals_used=list(f.signals_used),
            ))
    return calculate_metrics(records)


def worst_periods(report: BacktestReport, top_n: int = 3) -> dict:
    """
    Extract the highest-error periods from a BacktestReport.

    Returns the top N worst hours and worst weekdays by MAE, which is
    the most actionable insight for venue operators.

    Args:
        report: A completed BacktestReport.
        top_n: Number of worst periods to return.

    Returns:
        Dict with 'hours' and 'weekdays' lists, each sorted worst-first.
    """
    sorted_hours = sorted(report.by_hour, key=lambda h: h.metrics.mae, reverse=True)
    sorted_days = sorted(report.by_weekday, key=lambda d: d.metrics.mae, reverse=True)

    return {
        "hours": [
            {"hour": h.hour, "mae": round(h.metrics.mae, 2), "mape_pct": round(h.metrics.mape * 100, 1)}
            for h in sorted_hours[:top_n]
        ],
        "weekdays": [
            {"weekday": d.weekday, "name": d.weekday_name, "mae": round(d.metrics.mae, 2)}
            for d in sorted_days[:top_n]
        ],
    }
