-- RosterIQ Schema Migration: Forecast Accuracy
-- Run after schema.sql to add backtesting and accuracy tracking tables.
-- Idempotent — safe to run more than once.

-- ============================================================================
-- Forecast accuracy records
-- Stores paired (predicted, actual) observations for ongoing accuracy scoring.
-- Written by AccuracyTracker.record() after each week's trade closes.
-- ============================================================================

CREATE TABLE IF NOT EXISTS forecast_accuracy_records (
    id                  TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    venue_id            TEXT NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
    forecast_id         TEXT NOT NULL,               -- DemandForecast.id
    forecast_date       DATE NOT NULL,
    hour                INTEGER NOT NULL CHECK (hour BETWEEN 0 AND 23),
    predicted_covers    NUMERIC(8,1) NOT NULL,
    actual_covers       NUMERIC(8,1) NOT NULL,
    confidence          NUMERIC(3,2) NOT NULL,
    model_version       TEXT NOT NULL,
    signals_used        TEXT[] DEFAULT '{}',
    absolute_error      NUMERIC(8,2) GENERATED ALWAYS AS (ABS(predicted_covers - actual_covers)) STORED,
    signed_error        NUMERIC(8,2) GENERATED ALWAYS AS (predicted_covers - actual_covers) STORED,
    recorded_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_accuracy_venue_date
    ON forecast_accuracy_records(venue_id, forecast_date);

CREATE INDEX IF NOT EXISTS idx_accuracy_venue_model
    ON forecast_accuracy_records(venue_id, model_version);

CREATE INDEX IF NOT EXISTS idx_accuracy_recorded_at
    ON forecast_accuracy_records(venue_id, recorded_at DESC);

-- Prevent duplicate observations for the same (venue, date, hour, model)
CREATE UNIQUE INDEX IF NOT EXISTS idx_accuracy_unique
    ON forecast_accuracy_records(venue_id, forecast_date, hour, model_version);


-- ============================================================================
-- Backtest run log
-- One row per backtest execution; stores the overall metrics as JSONB.
-- Useful for auditing how the model's accuracy has evolved over time.
-- ============================================================================

CREATE TABLE IF NOT EXISTS backtest_runs (
    id                          TEXT PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    venue_id                    TEXT NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
    run_at                      TIMESTAMPTZ NOT NULL DEFAULT now(),
    min_train_weeks             INTEGER NOT NULL DEFAULT 4,
    test_weeks                  INTEGER NOT NULL DEFAULT 1,
    total_windows               INTEGER NOT NULL DEFAULT 0,
    total_forecasts_scored      INTEGER NOT NULL DEFAULT 0,
    overall_mae                 NUMERIC(8,2),
    overall_rmse                NUMERIC(8,2),
    overall_mape_pct            NUMERIC(5,1),
    overall_bias                NUMERIC(8,2),
    overall_r_squared           NUMERIC(5,3),
    within_10_pct               NUMERIC(5,1),
    within_20_pct               NUMERIC(5,1),
    model_improving             BOOLEAN DEFAULT false,
    worst_hour                  INTEGER,
    best_hour                   INTEGER,
    worst_weekday               INTEGER,
    full_report_json            JSONB,               -- full BacktestReport.as_dict()
    triggered_by                TEXT DEFAULT 'api'   -- 'api', 'scheduler', 'manual'
);

CREATE INDEX IF NOT EXISTS idx_backtest_runs_venue
    ON backtest_runs(venue_id, run_at DESC);
