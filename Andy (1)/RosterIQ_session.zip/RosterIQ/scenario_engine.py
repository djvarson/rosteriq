"""
What-if scenario comparison engine for RosterIQ.

Lets managers ask "what if I…" questions against a base roster and get
instant cost, compliance, and coverage impact. Multiple scenarios can be
run in parallel and ranked by any metric.

Core concepts
-------------
ScenarioMutation
    A single typed change to apply to a base roster or its context. The
    supported mutation types are:

    - ``remove_employee``  — drop all shifts for one employee (send home).
    - ``add_shift``        — insert a new shift for an employee on a given day.
    - ``remove_shift``     — delete a specific shift by ID.
    - ``change_hours``     — move a shift's start and/or end time.
    - ``replace_employee`` — swap one employee for another on a shift.
    - ``adjust_covers_ratio`` — change the covers-per-staff ratio used for
      coverage scoring (e.g. "what if we need to serve 20 covers/staff instead of 15?").
    - ``change_demand``    — scale demand on a given date by a multiplier
      (e.g. "what if it's 20% busier than forecast?").
    - ``trim_shift_end``   — cut a shift short to a specific end hour (early finish).

Scenario
    A named bundle of mutations with optional notes. Scenarios are applied
    to a snapshot of the base roster so they never modify the original.

ScenarioResult
    The full analysis of one scenario: cost breakdown, compliance issues,
    hourly coverage vs demand, and summary delta vs the base.

ScenarioComparison
    Side-by-side results for two or more scenarios plus a ranked leaderboard.

SensitivityResult
    Output of run_sensitivity() — a sweep of one parameter across a range,
    returning the metric value at each step (e.g. total cost as covers/staff
    ratio varies from 10 to 25).

Usage
-----
    from rosteriq.scenario_engine import (
        Scenario, ScenarioMutation, MutationType,
        apply_scenario, compare_scenarios, run_sensitivity,
    )

    # Remove one casual on a quiet Monday to see savings
    scenario = Scenario(
        name="Remove Jake on Monday",
        mutations=[
            ScenarioMutation(
                type=MutationType.remove_employee,
                employee_id="emp-jake",
                date=date(2026, 4, 13),
            )
        ],
    )
    result = apply_scenario(base_roster, employees, venue, forecasts, scenario)
    print(result.delta_cost)       # e.g. Decimal("-187.50") — $187.50 saved

    # Compare three scenarios side by side
    comparison = compare_scenarios(base_roster, employees, venue, forecasts, scenarios)
    print(comparison.ranked[0].scenario_name)   # cheapest scenario
"""

from __future__ import annotations

import copy
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Optional

from rosteriq.models import (
    CostBreakdown,
    DemandForecast,
    Employee,
    EmploymentType,
    Roster,
    Shift,
    ShiftStatus,
    State,
    VenueConfig,
)
from rosteriq.award_rules import (
    get_day_type,
    get_minimum_break_minutes,
    get_penalty_multiplier,
    validate_shift_compliance,
)
from rosteriq.cost_calculator import calculate_shift_cost_breakdown
from rosteriq.roster_optimiser import (
    DEFAULT_COVERS_PER_STAFF,
    calculate_required_staff,
)


# ============================================================================
# Mutation types and data classes
# ============================================================================


class MutationType(str, Enum):
    """All supported what-if mutation types."""

    remove_employee = "remove_employee"
    """Drop every shift belonging to employee_id (optionally filtered by date)."""

    add_shift = "add_shift"
    """Insert a new shift for employee_id on date with given start/end hours."""

    remove_shift = "remove_shift"
    """Delete the shift identified by shift_id."""

    change_hours = "change_hours"
    """Move a shift's start_hour and/or end_hour. Recalculates break minutes."""

    replace_employee = "replace_employee"
    """Swap employee_id → replacement_employee_id on the shift identified by
    shift_id. Keeps the same times; re-scores cost."""

    adjust_covers_ratio = "adjust_covers_ratio"
    """Change the covers-per-staff ratio used for coverage scoring.
    Does not touch the roster — affects coverage gap calculations only."""

    change_demand = "change_demand"
    """Scale all forecast covers on ``date`` by ``demand_multiplier``.
    Affects coverage gap calculations; does not add or remove staff."""

    trim_shift_end = "trim_shift_end"
    """Cut the shift identified by shift_id short to ``end_hour``.
    Useful for "send home early" what-ifs."""


@dataclass
class ScenarioMutation:
    """
    A single typed mutation to apply to a base roster snapshot.

    Not all fields are required for every mutation type — see each
    MutationType for which fields are used.
    """

    type: MutationType

    # --- Employee / shift targeting ---
    employee_id: Optional[str] = None
    """ID of the employee to act on (remove_employee, add_shift, replace_employee)."""

    shift_id: Optional[str] = None
    """ID of the specific shift to modify (remove_shift, change_hours,
    replace_employee, trim_shift_end)."""

    replacement_employee_id: Optional[str] = None
    """Employee ID to swap in (replace_employee only)."""

    # --- Scheduling fields ---
    date: Optional[date] = None
    """Target date. Required for add_shift and change_demand; optional for
    remove_employee (if None, removes from all days)."""

    start_hour: Optional[int] = None
    """New start hour 0–23 (add_shift, change_hours)."""

    end_hour: Optional[int] = None
    """New end hour 1–24 (add_shift, change_hours, trim_shift_end)."""

    role: str = "general"
    """Role for the new shift (add_shift only)."""

    # --- Coverage / demand adjustment ---
    covers_ratio: Optional[float] = None
    """New covers-per-staff ratio (adjust_covers_ratio only)."""

    demand_multiplier: Optional[float] = None
    """Demand scale factor, e.g. 1.2 = 20% busier (change_demand only)."""

    def validate(self) -> list[str]:
        """
        Return a list of validation error strings, empty if valid.

        Does not raise — callers decide how to handle errors.
        """
        errors: list[str] = []

        if self.type == MutationType.remove_employee and not self.employee_id:
            errors.append("remove_employee requires employee_id")

        if self.type == MutationType.add_shift:
            if not self.employee_id:
                errors.append("add_shift requires employee_id")
            if not self.date:
                errors.append("add_shift requires date")
            if self.start_hour is None:
                errors.append("add_shift requires start_hour")
            if self.end_hour is None:
                errors.append("add_shift requires end_hour")
            if self.start_hour is not None and self.end_hour is not None:
                if not (0 <= self.start_hour <= 23):
                    errors.append("start_hour must be 0–23")
                if not (1 <= self.end_hour <= 24):
                    errors.append("end_hour must be 1–24")
                if self.end_hour <= self.start_hour:
                    errors.append("end_hour must be greater than start_hour")

        if self.type in (MutationType.remove_shift, MutationType.trim_shift_end) and not self.shift_id:
            errors.append(f"{self.type.value} requires shift_id")

        if self.type == MutationType.change_hours:
            if not self.shift_id:
                errors.append("change_hours requires shift_id")
            if self.start_hour is None and self.end_hour is None:
                errors.append("change_hours requires at least one of start_hour or end_hour")

        if self.type == MutationType.replace_employee:
            if not self.shift_id:
                errors.append("replace_employee requires shift_id")
            if not self.replacement_employee_id:
                errors.append("replace_employee requires replacement_employee_id")

        if self.type == MutationType.adjust_covers_ratio:
            if self.covers_ratio is None:
                errors.append("adjust_covers_ratio requires covers_ratio")
            elif self.covers_ratio <= 0:
                errors.append("covers_ratio must be positive")

        if self.type == MutationType.change_demand:
            if not self.date:
                errors.append("change_demand requires date")
            if self.demand_multiplier is None:
                errors.append("change_demand requires demand_multiplier")
            elif self.demand_multiplier <= 0:
                errors.append("demand_multiplier must be positive")

        if self.type == MutationType.trim_shift_end:
            if self.end_hour is None:
                errors.append("trim_shift_end requires end_hour")

        return errors


@dataclass
class Scenario:
    """
    A named collection of mutations representing one what-if hypothesis.

    Scenarios are applied to a deep-copy of the base roster so the
    original is never modified.
    """

    name: str
    mutations: list[ScenarioMutation] = field(default_factory=list)
    notes: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def validate(self) -> list[str]:
        """Return all validation errors across all mutations."""
        errors: list[str] = []
        for i, m in enumerate(self.mutations):
            for e in m.validate():
                errors.append(f"mutation[{i}] ({m.type.value}): {e}")
        return errors


# ============================================================================
# Coverage analysis helpers
# ============================================================================


@dataclass
class HourlyCoverage:
    """Staffing vs demand for one hour on one day."""

    date: date
    hour: int
    actual_staff: int
    required_staff: int
    forecast_covers: float

    @property
    def gap(self) -> int:
        """Positive = understaffed, negative = overstaffed."""
        return self.required_staff - self.actual_staff

    @property
    def is_understaffed(self) -> bool:
        return self.gap > 0

    @property
    def is_overstaffed(self) -> bool:
        return self.gap < 0

    def as_dict(self) -> dict:
        return {
            "date": self.date.isoformat(),
            "hour": self.hour,
            "actual_staff": self.actual_staff,
            "required_staff": self.required_staff,
            "forecast_covers": round(self.forecast_covers, 1),
            "gap": self.gap,
            "status": "understaffed" if self.is_understaffed else (
                "overstaffed" if self.is_overstaffed else "ok"
            ),
        }


@dataclass
class CostSummary:
    """Aggregated cost breakdown across all shifts in a scenario."""

    total: Decimal
    base_pay: Decimal
    penalty_rates: Decimal
    casual_loading: Decimal
    superannuation: Decimal
    total_hours: float
    total_shifts: int
    unique_employees: int
    avg_hourly_rate: Decimal        # total / total_hours
    labour_pct: Optional[float]     # None when revenue unknown

    def as_dict(self) -> dict:
        return {
            "total": float(self.total),
            "base_pay": float(self.base_pay),
            "penalty_rates": float(self.penalty_rates),
            "casual_loading": float(self.casual_loading),
            "superannuation": float(self.superannuation),
            "total_hours": round(self.total_hours, 1),
            "total_shifts": self.total_shifts,
            "unique_employees": self.unique_employees,
            "avg_hourly_rate": float(self.avg_hourly_rate),
            "labour_pct": self.labour_pct,
        }


@dataclass
class ComplianceSummary:
    """All Fair Work compliance issues found in a scenario roster."""

    issues: list[dict]          # [{employee, shift_id, date, violation}]
    is_clean: bool
    issue_count: int

    def as_dict(self) -> dict:
        return {
            "is_clean": self.is_clean,
            "issue_count": self.issue_count,
            "issues": [
                {**i, "date": i["date"].isoformat() if isinstance(i["date"], date) else i["date"]}
                for i in self.issues
            ],
        }


# ============================================================================
# Scenario result
# ============================================================================


@dataclass
class ScenarioResult:
    """
    Complete analysis of one scenario applied to the base roster.

    Includes cost breakdown, compliance check, hourly coverage vs demand,
    and a delta summary comparing against the base roster.
    """

    scenario: Scenario
    roster: Roster                          # mutated roster snapshot
    cost: CostSummary
    compliance: ComplianceSummary
    coverage: list[HourlyCoverage]
    covers_ratio_used: float
    applied_mutations: int                  # number of mutations successfully applied
    skipped_mutations: list[str]            # mutations that could not be applied + reason

    # Delta vs base (populated by compare_scenarios, None for standalone results)
    delta_cost: Optional[Decimal] = None
    delta_hours: Optional[float] = None
    delta_shifts: Optional[int] = None
    delta_understaffed_hours: Optional[int] = None
    delta_compliance_issues: Optional[int] = None

    @property
    def understaffed_hours(self) -> int:
        return sum(1 for c in self.coverage if c.is_understaffed)

    @property
    def overstaffed_hours(self) -> int:
        return sum(1 for c in self.coverage if c.is_overstaffed)

    @property
    def coverage_score(self) -> float:
        """Fraction of hours that are neither over nor understaffed (0–1)."""
        if not self.coverage:
            return 1.0
        ok = sum(1 for c in self.coverage if not c.is_understaffed and not c.is_overstaffed)
        return ok / len(self.coverage)

    def as_dict(self) -> dict:
        return {
            "scenario_id": self.scenario.id,
            "scenario_name": self.scenario.name,
            "scenario_notes": self.scenario.notes,
            "applied_mutations": self.applied_mutations,
            "skipped_mutations": self.skipped_mutations,
            "cost": self.cost.as_dict(),
            "compliance": self.compliance.as_dict(),
            "coverage_score": round(self.coverage_score, 3),
            "understaffed_hours": self.understaffed_hours,
            "overstaffed_hours": self.overstaffed_hours,
            "coverage": [c.as_dict() for c in self.coverage],
            "delta": {
                "cost": float(self.delta_cost) if self.delta_cost is not None else None,
                "hours": self.delta_hours,
                "shifts": self.delta_shifts,
                "understaffed_hours": self.delta_understaffed_hours,
                "compliance_issues": self.delta_compliance_issues,
            },
        }


# ============================================================================
# Scenario comparison
# ============================================================================


@dataclass
class RankedScenario:
    """One entry in a comparison leaderboard."""

    rank: int
    scenario_name: str
    scenario_id: str
    total_cost: Decimal
    delta_cost: Optional[Decimal]
    coverage_score: float
    compliance_clean: bool
    understaffed_hours: int
    total_hours: float

    def as_dict(self) -> dict:
        return {
            "rank": self.rank,
            "scenario_name": self.scenario_name,
            "scenario_id": self.scenario_id,
            "total_cost": float(self.total_cost),
            "delta_cost": float(self.delta_cost) if self.delta_cost is not None else None,
            "coverage_score": round(self.coverage_score, 3),
            "compliance_clean": self.compliance_clean,
            "understaffed_hours": self.understaffed_hours,
            "total_hours": round(self.total_hours, 1),
        }


@dataclass
class ScenarioComparison:
    """
    Side-by-side comparison of a base roster against one or more scenarios.

    The base roster is always included in results as scenario index 0.
    ``ranked`` lists all scenarios ordered from lowest to highest total cost.
    """

    base_result: ScenarioResult
    scenario_results: list[ScenarioResult]
    ranked: list[RankedScenario]
    best_cost_scenario: str             # scenario name with lowest total cost
    best_coverage_scenario: str         # scenario name with highest coverage score
    recommendation: str                 # plain-English summary

    def as_dict(self) -> dict:
        return {
            "base": self.base_result.as_dict(),
            "scenarios": [r.as_dict() for r in self.scenario_results],
            "ranked": [r.as_dict() for r in self.ranked],
            "best_cost_scenario": self.best_cost_scenario,
            "best_coverage_scenario": self.best_coverage_scenario,
            "recommendation": self.recommendation,
        }


# ============================================================================
# Sensitivity sweep
# ============================================================================


@dataclass
class SensitivityPoint:
    """One data point in a sensitivity sweep."""

    parameter_value: float
    total_cost: float
    understaffed_hours: int
    overstaffed_hours: int
    coverage_score: float

    def as_dict(self) -> dict:
        return {
            "parameter_value": round(self.parameter_value, 2),
            "total_cost": round(self.total_cost, 2),
            "understaffed_hours": self.understaffed_hours,
            "overstaffed_hours": self.overstaffed_hours,
            "coverage_score": round(self.coverage_score, 3),
        }


@dataclass
class SensitivityResult:
    """
    Result of sweeping one parameter across a range.

    E.g. covers_ratio swept from 10 to 25 in steps of 1 shows how
    coverage gaps change as the venue becomes busier per staff member.
    """

    parameter_name: str
    points: list[SensitivityPoint]
    optimal_value: float        # value that minimises cost while keeping coverage_score ≥ 0.8
    optimal_cost: float

    def as_dict(self) -> dict:
        return {
            "parameter_name": self.parameter_name,
            "points": [p.as_dict() for p in self.points],
            "optimal_value": round(self.optimal_value, 2),
            "optimal_cost": round(self.optimal_cost, 2),
        }


# ============================================================================
# Internal helpers
# ============================================================================


def _deep_copy_roster(roster: Roster) -> Roster:
    """Return a deep copy of a roster so mutations don't affect the original."""
    return Roster(
        id=roster.id,
        venue_id=roster.venue_id,
        week_start=roster.week_start,
        week_end=roster.week_end,
        total_cost=roster.total_cost,
        created_at=roster.created_at,
        shifts=[
            Shift(
                id=s.id,
                employee_id=s.employee_id,
                date=s.date,
                start_time=s.start_time,
                end_time=s.end_time,
                break_minutes=s.break_minutes,
                status=s.status,
                role=s.role,
                cost=s.cost,
                penalty_multiplier=s.penalty_multiplier,
            )
            for s in roster.shifts
        ],
    )


def _deep_copy_forecasts(forecasts: list[DemandForecast]) -> list[DemandForecast]:
    """Return a shallow-enough copy of forecasts that mutations can scale them."""
    return [
        DemandForecast(
            id=f.id,
            venue_id=f.venue_id,
            date=f.date,
            hour=f.hour,
            predicted_covers=f.predicted_covers,
            confidence=f.confidence,
            signals_used=list(f.signals_used),
            model_version=f.model_version,
        )
        for f in forecasts
    ]


def _make_shift(
    employee: Employee,
    target_date: date,
    start_hour: int,
    end_hour: int,
    role: str = "general",
) -> Shift:
    """Create a Shift object with automatically computed break minutes."""
    duration = end_hour - start_hour
    break_minutes = get_minimum_break_minutes(float(duration))
    end_h = min(end_hour, 24)
    end_time = time(end_h % 24, 0)
    return Shift(
        id=str(uuid.uuid4())[:8],
        employee_id=employee.id,
        date=target_date,
        start_time=time(start_hour, 0),
        end_time=end_time,
        break_minutes=break_minutes,
        status=ShiftStatus.scheduled,
        role=role,
    )


def _build_cost_summary(
    shifts: list[Shift],
    employees: dict[str, Employee],
    state: State,
    revenue: Optional[Decimal] = None,
) -> CostSummary:
    """Aggregate cost across all shifts into a CostSummary."""
    total = Decimal("0")
    base_pay = Decimal("0")
    penalty_rates = Decimal("0")
    casual_loading = Decimal("0")
    superannuation = Decimal("0")
    total_hours = 0.0
    employee_ids: set[str] = set()

    for shift in shifts:
        emp = employees.get(shift.employee_id)
        if not emp:
            continue
        bd: CostBreakdown = calculate_shift_cost_breakdown(emp, shift, state)
        total += bd.total_cost
        base_pay += bd.base_cost
        penalty_rates += bd.penalty_cost
        casual_loading += bd.casual_loading
        superannuation += bd.super_contribution
        total_hours += shift.net_hours
        employee_ids.add(shift.employee_id)

    avg_hourly = (
        (total / Decimal(str(total_hours))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        if total_hours > 0
        else Decimal("0")
    )

    labour_pct = None
    if revenue and revenue > 0:
        labour_pct = float((total / revenue * Decimal("100")).quantize(Decimal("0.1")))

    return CostSummary(
        total=total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
        base_pay=base_pay.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
        penalty_rates=penalty_rates.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
        casual_loading=casual_loading.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
        superannuation=superannuation.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
        total_hours=total_hours,
        total_shifts=len(shifts),
        unique_employees=len(employee_ids),
        avg_hourly_rate=avg_hourly,
        labour_pct=labour_pct,
    )


def _build_compliance_summary(
    shifts: list[Shift],
    employees: dict[str, Employee],
) -> ComplianceSummary:
    """Run Fair Work compliance checks across all shifts."""
    issues: list[dict] = []
    for shift in shifts:
        emp = employees.get(shift.employee_id)
        if not emp:
            continue
        emp_shifts = [s for s in shifts if s.employee_id == shift.employee_id]
        violations = validate_shift_compliance(emp, shift, emp_shifts)
        for v in violations:
            issues.append({
                "employee": emp.name,
                "employee_id": emp.id,
                "shift_id": shift.id,
                "date": shift.date,
                "violation": v,
            })
    return ComplianceSummary(
        issues=issues,
        is_clean=len(issues) == 0,
        issue_count=len(issues),
    )


def _build_coverage(
    shifts: list[Shift],
    forecasts: list[DemandForecast],
    covers_ratio: float,
) -> list[HourlyCoverage]:
    """Build hourly coverage records comparing actual staff to required staff."""
    # Actual staffing: date → hour → count
    actual: dict[date, dict[int, int]] = defaultdict(lambda: defaultdict(int))
    for shift in shifts:
        start_h = shift.start_time.hour
        end_h = shift.end_time.hour
        if end_h == 0:          # midnight end
            end_h = 24
        if end_h <= start_h:    # overnight
            end_h += 24
        for h in range(start_h, min(end_h, 24)):
            actual[shift.date][h] += 1

    coverage: list[HourlyCoverage] = []
    for fc in forecasts:
        required = max(1, int(fc.predicted_covers / covers_ratio + 0.5))
        staff = actual.get(fc.date, {}).get(fc.hour, 0)
        coverage.append(HourlyCoverage(
            date=fc.date,
            hour=fc.hour,
            actual_staff=staff,
            required_staff=required,
            forecast_covers=fc.predicted_covers,
        ))

    return sorted(coverage, key=lambda c: (c.date, c.hour))


# ============================================================================
# Mutation application
# ============================================================================


def _apply_mutation(
    mutation: ScenarioMutation,
    roster: Roster,
    employees: dict[str, Employee],
    forecasts: list[DemandForecast],
    covers_ratio_ref: list[float],   # mutable single-element list for ratio
) -> Optional[str]:
    """
    Apply one mutation in-place to roster/forecasts.

    Returns None on success, or an error string if the mutation could
    not be applied (e.g. shift_id not found).
    """

    if mutation.type == MutationType.remove_employee:
        before = len(roster.shifts)
        roster.shifts = [
            s for s in roster.shifts
            if not (
                s.employee_id == mutation.employee_id
                and (mutation.date is None or s.date == mutation.date)
            )
        ]
        if len(roster.shifts) == before:
            return f"remove_employee: no shifts found for employee {mutation.employee_id!r}"
        return None

    if mutation.type == MutationType.add_shift:
        emp = employees.get(mutation.employee_id)
        if not emp:
            return f"add_shift: employee {mutation.employee_id!r} not found"
        # Check not already scheduled that day
        existing_day = [s for s in roster.shifts
                        if s.employee_id == mutation.employee_id and s.date == mutation.date]
        if existing_day:
            return (f"add_shift: {emp.name} already has a shift on {mutation.date} "
                    f"(shift {existing_day[0].id})")
        shift = _make_shift(emp, mutation.date, mutation.start_hour, mutation.end_hour, mutation.role)
        roster.shifts.append(shift)
        return None

    if mutation.type == MutationType.remove_shift:
        before = len(roster.shifts)
        roster.shifts = [s for s in roster.shifts if s.id != mutation.shift_id]
        if len(roster.shifts) == before:
            return f"remove_shift: shift {mutation.shift_id!r} not found"
        return None

    if mutation.type == MutationType.change_hours:
        shift = next((s for s in roster.shifts if s.id == mutation.shift_id), None)
        if not shift:
            return f"change_hours: shift {mutation.shift_id!r} not found"
        new_start = mutation.start_hour if mutation.start_hour is not None else shift.start_time.hour
        new_end = mutation.end_hour if mutation.end_hour is not None else shift.end_time.hour
        if new_end <= new_start:
            return f"change_hours: end_hour ({new_end}) must be > start_hour ({new_start})"
        duration = new_end - new_start
        break_mins = get_minimum_break_minutes(float(duration))
        shift.start_time = time(new_start, 0)
        shift.end_time = time(new_end % 24, 0)
        shift.break_minutes = break_mins
        return None

    if mutation.type == MutationType.replace_employee:
        shift = next((s for s in roster.shifts if s.id == mutation.shift_id), None)
        if not shift:
            return f"replace_employee: shift {mutation.shift_id!r} not found"
        new_emp = employees.get(mutation.replacement_employee_id)
        if not new_emp:
            return f"replace_employee: replacement employee {mutation.replacement_employee_id!r} not found"
        # Check replacement not already scheduled that day
        conflict = [s for s in roster.shifts
                    if s.employee_id == mutation.replacement_employee_id
                    and s.date == shift.date
                    and s.id != shift.id]
        if conflict:
            return (f"replace_employee: {new_emp.name} already has a shift on {shift.date} "
                    f"(shift {conflict[0].id})")
        shift.employee_id = mutation.replacement_employee_id
        return None

    if mutation.type == MutationType.adjust_covers_ratio:
        covers_ratio_ref[0] = mutation.covers_ratio
        return None

    if mutation.type == MutationType.change_demand:
        multiplier = mutation.demand_multiplier
        for fc in forecasts:
            if fc.date == mutation.date:
                fc.predicted_covers = max(0.0, round(fc.predicted_covers * multiplier, 1))
        return None

    if mutation.type == MutationType.trim_shift_end:
        shift = next((s for s in roster.shifts if s.id == mutation.shift_id), None)
        if not shift:
            return f"trim_shift_end: shift {mutation.shift_id!r} not found"
        new_end = mutation.end_hour
        if new_end <= shift.start_time.hour:
            return (f"trim_shift_end: end_hour ({new_end}) must be > "
                    f"shift start ({shift.start_time.hour})")
        duration = new_end - shift.start_time.hour
        break_mins = get_minimum_break_minutes(float(duration))
        shift.end_time = time(new_end % 24, 0)
        shift.break_minutes = break_mins
        return None

    return f"Unknown mutation type: {mutation.type!r}"


# ============================================================================
# Public API
# ============================================================================


def apply_scenario(
    base_roster: Roster,
    employees: dict[str, Employee],
    venue: VenueConfig,
    forecasts: list[DemandForecast],
    scenario: Scenario,
    covers_ratio: float = DEFAULT_COVERS_PER_STAFF,
    revenue: Optional[Decimal] = None,
) -> ScenarioResult:
    """
    Apply a scenario's mutations to a deep copy of the base roster and
    return a full analysis.

    The base roster is never modified. Each call operates on a fresh copy.

    Args:
        base_roster: The roster to use as the starting point.
        employees: Full employee dict (id → Employee).
        venue: Venue configuration.
        forecasts: Demand forecasts for the week (used for coverage scoring).
        scenario: The scenario to apply.
        covers_ratio: Initial covers-per-staff ratio for coverage scoring.
            Can be overridden by an adjust_covers_ratio mutation.
        revenue: Optional weekly revenue for labour % calculation.

    Returns:
        ScenarioResult with full cost, compliance, and coverage analysis.
    """
    # Work on isolated copies
    roster_copy = _deep_copy_roster(base_roster)
    forecasts_copy = _deep_copy_forecasts(forecasts)
    ratio_ref = [covers_ratio]

    applied = 0
    skipped: list[str] = []

    for mutation in scenario.mutations:
        # Validate first
        errors = mutation.validate()
        if errors:
            skipped.append(f"[{mutation.type.value}] Invalid: {'; '.join(errors)}")
            continue

        error = _apply_mutation(mutation, roster_copy, employees, forecasts_copy, ratio_ref)
        if error:
            skipped.append(error)
        else:
            applied += 1

    active_shifts = [s for s in roster_copy.shifts if s.status != ShiftStatus.cancelled]
    cost = _build_cost_summary(active_shifts, employees, venue.state, revenue)
    compliance = _build_compliance_summary(active_shifts, employees)
    coverage = _build_coverage(active_shifts, forecasts_copy, ratio_ref[0])

    return ScenarioResult(
        scenario=scenario,
        roster=roster_copy,
        cost=cost,
        compliance=compliance,
        coverage=coverage,
        covers_ratio_used=ratio_ref[0],
        applied_mutations=applied,
        skipped_mutations=skipped,
    )


def _make_base_scenario(base_roster: Roster) -> Scenario:
    """Create a no-op 'Base roster' scenario for comparison."""
    return Scenario(name="Base roster", mutations=[], notes="Original unmodified roster")


def compare_scenarios(
    base_roster: Roster,
    employees: dict[str, Employee],
    venue: VenueConfig,
    forecasts: list[DemandForecast],
    scenarios: list[Scenario],
    covers_ratio: float = DEFAULT_COVERS_PER_STAFF,
    revenue: Optional[Decimal] = None,
    rank_by: str = "cost",
) -> ScenarioComparison:
    """
    Run and compare multiple what-if scenarios against the base roster.

    The base roster is always evaluated as scenario 0 so deltas are accurate.

    Args:
        base_roster: Starting roster (never modified).
        employees: Full employee pool.
        venue: Venue configuration.
        forecasts: Demand forecasts for the week.
        scenarios: List of Scenario objects to evaluate.
        covers_ratio: Initial covers-per-staff ratio.
        revenue: Optional revenue for labour % calculation.
        rank_by: Ranking metric — "cost" (default), "coverage", or "compliance".

    Returns:
        ScenarioComparison with all results plus ranked leaderboard.

    Raises:
        ValueError: If scenarios list is empty.
    """
    if not scenarios:
        raise ValueError("At least one scenario is required")

    # Evaluate base
    base_scenario = _make_base_scenario(base_roster)
    base_result = apply_scenario(
        base_roster, employees, venue, forecasts, base_scenario,
        covers_ratio=covers_ratio, revenue=revenue,
    )

    # Evaluate each scenario and compute deltas
    scenario_results: list[ScenarioResult] = []
    for scenario in scenarios:
        result = apply_scenario(
            base_roster, employees, venue, forecasts, scenario,
            covers_ratio=covers_ratio, revenue=revenue,
        )
        result.delta_cost = result.cost.total - base_result.cost.total
        result.delta_hours = result.cost.total_hours - base_result.cost.total_hours
        result.delta_shifts = result.cost.total_shifts - base_result.cost.total_shifts
        result.delta_understaffed_hours = result.understaffed_hours - base_result.understaffed_hours
        result.delta_compliance_issues = result.compliance.issue_count - base_result.compliance.issue_count
        scenario_results.append(result)

    # Build leaderboard including the base
    all_results = [base_result] + scenario_results
    for r in all_results:
        if r.delta_cost is None:
            r.delta_cost = Decimal("0")

    if rank_by == "coverage":
        sorted_results = sorted(all_results, key=lambda r: -r.coverage_score)
    elif rank_by == "compliance":
        sorted_results = sorted(all_results, key=lambda r: r.compliance.issue_count)
    else:
        sorted_results = sorted(all_results, key=lambda r: r.cost.total)

    ranked = [
        RankedScenario(
            rank=i + 1,
            scenario_name=r.scenario.name,
            scenario_id=r.scenario.id,
            total_cost=r.cost.total,
            delta_cost=r.delta_cost,
            coverage_score=r.coverage_score,
            compliance_clean=r.compliance.is_clean,
            understaffed_hours=r.understaffed_hours,
            total_hours=r.cost.total_hours,
        )
        for i, r in enumerate(sorted_results)
    ]

    best_cost = min(all_results, key=lambda r: r.cost.total).scenario.name
    best_coverage = max(all_results, key=lambda r: r.coverage_score).scenario.name

    recommendation = _generate_recommendation(base_result, scenario_results, ranked)

    return ScenarioComparison(
        base_result=base_result,
        scenario_results=scenario_results,
        ranked=ranked,
        best_cost_scenario=best_cost,
        best_coverage_scenario=best_coverage,
        recommendation=recommendation,
    )


def _generate_recommendation(
    base: ScenarioResult,
    scenarios: list[ScenarioResult],
    ranked: list[RankedScenario],
) -> str:
    """Generate a plain-English recommendation from comparison results."""
    if not scenarios:
        return "No scenarios to compare."

    best_cost_result = min(scenarios, key=lambda r: r.cost.total)
    best_coverage_result = max(scenarios, key=lambda r: r.coverage_score)
    savings = base.cost.total - best_cost_result.cost.total

    if savings <= 0 and all(r.coverage_score <= base.coverage_score for r in scenarios):
        return (
            "None of the proposed scenarios improve on the base roster in either "
            "cost or coverage. Consider a different combination of changes."
        )

    if best_cost_result.scenario.id == best_coverage_result.scenario.id:
        return (
            f"'{best_cost_result.scenario.name}' is the clear winner: saves "
            f"${abs(float(savings)):.2f} and {'maintains' if best_cost_result.coverage_score >= base.coverage_score - 0.05 else 'reduces'} "
            f"coverage ({best_cost_result.coverage_score:.0%} on floor)."
            + (" All compliance checks pass." if best_cost_result.compliance.is_clean else
               f" Note: {best_cost_result.compliance.issue_count} compliance issue(s) to review.")
        )

    if savings > 0 and best_cost_result.compliance.is_clean:
        coverage_delta = best_cost_result.coverage_score - base.coverage_score
        coverage_note = (
            f" Coverage is {'unchanged' if abs(coverage_delta) < 0.02 else ('improved' if coverage_delta > 0 else f'reduced by {abs(coverage_delta):.0%}')}."
        )
        return (
            f"'{best_cost_result.scenario.name}' saves ${float(savings):.2f} with no "
            f"compliance issues.{coverage_note} "
            f"If coverage is a priority, consider '{best_coverage_result.scenario.name}' instead."
        )

    return (
        f"'{best_cost_result.scenario.name}' has the lowest cost (saves ${float(savings):.2f}) "
        f"but review the compliance and coverage trade-offs before committing. "
        f"'{best_coverage_result.scenario.name}' offers the best staffing coverage."
    )


def run_sensitivity(
    base_roster: Roster,
    employees: dict[str, Employee],
    venue: VenueConfig,
    forecasts: list[DemandForecast],
    parameter: str,
    values: list[float],
    covers_ratio: float = DEFAULT_COVERS_PER_STAFF,
    revenue: Optional[Decimal] = None,
) -> SensitivityResult:
    """
    Sweep a single parameter across a range and return the metric curve.

    Supported parameters
    --------------------
    ``covers_ratio``
        How many covers each staff member handles. Higher = fewer staff needed
        for the same demand. Shows the cost/coverage trade-off.

    ``demand_multiplier``
        Scale all forecasts by this factor to model a busier or quieter week.
        Applied uniformly across all days.

    Args:
        base_roster: Base roster (never modified).
        employees: Employee pool.
        venue: Venue configuration.
        forecasts: Demand forecasts.
        parameter: One of "covers_ratio" or "demand_multiplier".
        values: List of parameter values to evaluate (e.g. [10, 12, 14, 16, 18, 20]).
        covers_ratio: Base covers ratio (used when parameter != "covers_ratio").
        revenue: Optional revenue for labour % calculation.

    Returns:
        SensitivityResult with a point per value plus the optimal value.

    Raises:
        ValueError: If parameter is not recognised or values is empty.
    """
    SUPPORTED = {"covers_ratio", "demand_multiplier"}
    if parameter not in SUPPORTED:
        raise ValueError(f"parameter must be one of {SUPPORTED}, got {parameter!r}")
    if not values:
        raise ValueError("values must be a non-empty list")

    points: list[SensitivityPoint] = []
    for v in values:
        if parameter == "covers_ratio":
            mutation = ScenarioMutation(type=MutationType.adjust_covers_ratio, covers_ratio=v)
        else:  # demand_multiplier — apply to all days
            # We create a special multi-date scenario
            scenario_mutations = []
            seen_dates = sorted(set(f.date for f in forecasts))
            for d in seen_dates:
                scenario_mutations.append(
                    ScenarioMutation(
                        type=MutationType.change_demand,
                        date=d,
                        demand_multiplier=v,
                    )
                )
            scenario = Scenario(name=f"demand_x{v:.2f}", mutations=scenario_mutations)
            result = apply_scenario(
                base_roster, employees, venue, forecasts, scenario,
                covers_ratio=covers_ratio, revenue=revenue,
            )
            points.append(SensitivityPoint(
                parameter_value=v,
                total_cost=float(result.cost.total),
                understaffed_hours=result.understaffed_hours,
                overstaffed_hours=result.overstaffed_hours,
                coverage_score=result.coverage_score,
            ))
            continue

        scenario = Scenario(name=f"{parameter}={v:.1f}", mutations=[mutation])
        result = apply_scenario(
            base_roster, employees, venue, forecasts, scenario,
            covers_ratio=covers_ratio, revenue=revenue,
        )
        points.append(SensitivityPoint(
            parameter_value=v,
            total_cost=float(result.cost.total),
            understaffed_hours=result.understaffed_hours,
            overstaffed_hours=result.overstaffed_hours,
            coverage_score=result.coverage_score,
        ))

    # Optimal: lowest cost point that keeps coverage_score >= 0.8
    qualified = [p for p in points if p.coverage_score >= 0.8]
    if qualified:
        best = min(qualified, key=lambda p: p.total_cost)
    else:
        best = min(points, key=lambda p: p.total_cost)

    return SensitivityResult(
        parameter_name=parameter,
        points=points,
        optimal_value=best.parameter_value,
        optimal_cost=best.total_cost,
    )


# ============================================================================
# Convenience: pre-built common scenarios
# ============================================================================


def scenario_remove_all_casuals(date_filter: Optional[date] = None) -> Scenario:
    """
    Convenience: a scenario that removes all shifts with no employee attached.

    Because we don't know IDs at build time, returns an empty scenario with
    a note. Callers should enumerate casual employee IDs and build mutations.

    This is a documentation helper — see ``build_remove_casuals_scenario``
    for the callable version.
    """
    return Scenario(
        name="Remove all casuals" + (f" on {date_filter}" if date_filter else ""),
        notes="Removes every casual employee from the roster to show maximum savings potential.",
        mutations=[],
    )


def build_remove_casuals_scenario(
    employees: dict[str, Employee],
    date_filter: Optional[date] = None,
) -> Scenario:
    """
    Build a scenario that removes all casual employees.

    Args:
        employees: Full employee dict.
        date_filter: If provided, only remove casuals on this date.

    Returns:
        Ready-to-apply Scenario.
    """
    mutations = [
        ScenarioMutation(
            type=MutationType.remove_employee,
            employee_id=emp_id,
            date=date_filter,
        )
        for emp_id, emp in employees.items()
        if emp.employment_type == EmploymentType.casual
    ]
    return Scenario(
        name="Remove all casuals" + (f" on {date_filter}" if date_filter else ""),
        notes="Shows maximum labour cost reduction if all casual shifts are cut.",
        mutations=mutations,
    )


def build_demand_shift_scenario(multiplier: float, label: str = "") -> Scenario:
    """
    Build a scenario that scales all demand by a multiplier.

    Useful for "what if it's 20% busier than forecast?" questions.

    Args:
        multiplier: Demand scale factor (e.g. 1.2 = 20% busier).
        label: Optional label suffix for the scenario name.

    Returns:
        Scenario with a single change_demand mutation.
        Note: date must be set by the caller — this returns a template
        with date=None. Use build_week_demand_scenario for full weeks.
    """
    pct = int((multiplier - 1) * 100)
    sign = "+" if pct >= 0 else ""
    return Scenario(
        name=f"Demand {sign}{pct}%" + (f" — {label}" if label else ""),
        notes=f"What if demand is {sign}{pct}% vs forecast?",
        mutations=[],   # caller must add change_demand mutations with specific dates
    )


def build_week_demand_scenario(
    forecasts: list[DemandForecast],
    multiplier: float,
    label: str = "",
) -> Scenario:
    """
    Build a full-week demand-shift scenario across all forecast dates.

    Args:
        forecasts: The week's demand forecasts.
        multiplier: Scale factor applied to all days.
        label: Optional label suffix.

    Returns:
        Ready-to-apply Scenario.
    """
    seen_dates = sorted(set(f.date for f in forecasts))
    pct = int((multiplier - 1) * 100)
    sign = "+" if pct >= 0 else ""
    mutations = [
        ScenarioMutation(
            type=MutationType.change_demand,
            date=d,
            demand_multiplier=multiplier,
        )
        for d in seen_dates
    ]
    return Scenario(
        name=f"Demand {sign}{pct}%" + (f" — {label}" if label else ""),
        notes=f"What if every day this week is {sign}{pct}% vs forecast?",
        mutations=mutations,
    )
