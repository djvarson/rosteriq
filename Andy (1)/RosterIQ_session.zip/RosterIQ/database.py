"""
Database layer for RosterIQ.

Provides a thin abstraction over PostgreSQL using psycopg2.
Falls back to in-memory storage when no DATABASE_URL is set.

Usage:
    from rosteriq.database import get_db
    db = get_db()
    db.save_venue(venue)
    venues = db.list_venues()
"""

import os
import json
import logging
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Optional

from rosteriq.models import (
    Employee, Shift, Roster, DemandForecast, VenueConfig,
    EmploymentType, ShiftStatus, AwardLevel, State,
)

logger = logging.getLogger(__name__)

DATABASE_URL = os.environ.get("DATABASE_URL")


# ============================================================================
# Abstract store interface
# ============================================================================

class BaseStore:
    """Interface that both in-memory and PostgreSQL stores implement."""

    def save_venue(self, venue: VenueConfig) -> None:
        raise NotImplementedError

    def list_venues(self) -> list[VenueConfig]:
        raise NotImplementedError

    def get_venue(self, venue_id: str) -> Optional[VenueConfig]:
        raise NotImplementedError

    def save_employee(self, employee: Employee) -> None:
        raise NotImplementedError

    def save_employees(self, employees: list[Employee]) -> None:
        for emp in employees:
            self.save_employee(emp)

    def list_employees(self) -> list[Employee]:
        raise NotImplementedError

    def get_employee(self, employee_id: str) -> Optional[Employee]:
        raise NotImplementedError

    def get_employees_dict(self) -> dict[str, Employee]:
        return {e.id: e for e in self.list_employees()}

    def add_forecasts(self, forecasts: list[DemandForecast]) -> None:
        raise NotImplementedError

    def get_forecasts(
        self,
        venue_id: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> list[DemandForecast]:
        raise NotImplementedError

    def save_roster(self, roster: Roster) -> None:
        raise NotImplementedError

    def list_rosters(self) -> list[Roster]:
        raise NotImplementedError

    def get_roster(self, roster_id: str) -> Optional[Roster]:
        raise NotImplementedError


# ============================================================================
# In-memory store (development / testing)
# ============================================================================

class MemoryStore(BaseStore):
    """In-memory storage — same as the existing _store dict but structured."""

    def __init__(self):
        self._venues: dict[str, VenueConfig] = {}
        self._employees: dict[str, Employee] = {}
        self._forecasts: list[DemandForecast] = []
        self._rosters: dict[str, Roster] = {}

    def save_venue(self, venue):
        self._venues[venue.id] = venue

    def list_venues(self):
        return list(self._venues.values())

    def get_venue(self, venue_id):
        return self._venues.get(venue_id)

    def save_employee(self, employee):
        self._employees[employee.id] = employee

    def list_employees(self):
        return list(self._employees.values())

    def get_employee(self, employee_id):
        return self._employees.get(employee_id)

    def add_forecasts(self, forecasts):
        self._forecasts.extend(forecasts)

    def get_forecasts(self, venue_id=None, start_date=None, end_date=None):
        results = self._forecasts
        if venue_id:
            results = [f for f in results if f.venue_id == venue_id]
        if start_date:
            results = [f for f in results if f.date >= start_date]
        if end_date:
            results = [f for f in results if f.date <= end_date]
        return results

    def save_roster(self, roster):
        self._rosters[roster.id] = roster

    def list_rosters(self):
        return list(self._rosters.values())

    def get_roster(self, roster_id):
        return self._rosters.get(roster_id)


# ============================================================================
# PostgreSQL store (production)
# ============================================================================

class PostgresStore(BaseStore):
    """PostgreSQL-backed storage using psycopg2."""

    def __init__(self, dsn: str):
        try:
            import psycopg2
            import psycopg2.extras
            self._conn = psycopg2.connect(dsn)
            self._conn.autocommit = True
            logger.info("Connected to PostgreSQL: %s", dsn.split("@")[-1])
        except ImportError:
            raise RuntimeError("psycopg2 not installed — run: pip install psycopg2-binary")

    def _cursor(self):
        import psycopg2.extras
        return self._conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    # --- Venues ---

    def save_venue(self, venue):
        with self._cursor() as cur:
            cur.execute("""
                INSERT INTO venues (id, name, tanda_org_id, state, timezone, min_staff, max_labour_pct, pos_system, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    name=EXCLUDED.name, tanda_org_id=EXCLUDED.tanda_org_id,
                    state=EXCLUDED.state, min_staff=EXCLUDED.min_staff,
                    max_labour_pct=EXCLUDED.max_labour_pct, pos_system=EXCLUDED.pos_system,
                    updated_at=now()
            """, (
                venue.id, venue.name, venue.tanda_org_id, venue.state.value,
                venue.timezone, json.dumps(venue.min_staff),
                float(venue.max_labour_pct), venue.pos_system, venue.created_at,
            ))

    def list_venues(self):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM venues ORDER BY name")
            return [self._row_to_venue(r) for r in cur.fetchall()]

    def get_venue(self, venue_id):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM venues WHERE id = %s", (venue_id,))
            row = cur.fetchone()
            return self._row_to_venue(row) if row else None

    def _row_to_venue(self, row):
        return VenueConfig(
            id=row["id"], name=row["name"], tanda_org_id=row["tanda_org_id"],
            state=State(row["state"]), timezone=row["timezone"],
            min_staff=row["min_staff"] if isinstance(row["min_staff"], dict) else json.loads(row["min_staff"]),
            max_labour_pct=float(row["max_labour_pct"]),
            pos_system=row.get("pos_system"),
            created_at=row["created_at"],
        )

    # --- Employees ---

    def save_employee(self, emp):
        with self._cursor() as cur:
            cur.execute("""
                INSERT INTO employees (id, venue_id, tanda_id, name, employment_type, award_level,
                    hourly_base_rate, skills, availability, max_hours_per_week, consecutive_days, phone, email, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    name=EXCLUDED.name, employment_type=EXCLUDED.employment_type,
                    hourly_base_rate=EXCLUDED.hourly_base_rate, skills=EXCLUDED.skills,
                    availability=EXCLUDED.availability, max_hours_per_week=EXCLUDED.max_hours_per_week,
                    phone=EXCLUDED.phone, email=EXCLUDED.email, updated_at=now()
            """, (
                emp.id, getattr(emp, 'venue_id', 'demo-venue'), emp.tanda_id, emp.name,
                emp.employment_type.value, emp.award_level.value,
                float(emp.hourly_base_rate), emp.skills,
                json.dumps(emp.availability), emp.max_hours_per_week,
                emp.consecutive_days_limit, emp.phone, emp.email,
                emp.created_at, emp.updated_at,
            ))

    def list_employees(self):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM employees WHERE active = true ORDER BY name")
            return [self._row_to_employee(r) for r in cur.fetchall()]

    def get_employee(self, employee_id):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM employees WHERE id = %s", (employee_id,))
            row = cur.fetchone()
            return self._row_to_employee(row) if row else None

    def _row_to_employee(self, row):
        avail = row["availability"]
        if isinstance(avail, str):
            avail = json.loads(avail)
        return Employee(
            id=row["id"], tanda_id=row.get("tanda_id"), name=row["name"],
            employment_type=EmploymentType(row["employment_type"]),
            award_level=AwardLevel(row["award_level"]),
            state=State("vic"),  # Will derive from venue in production
            hourly_base_rate=Decimal(str(row["hourly_base_rate"])),
            phone=row.get("phone"), email=row.get("email"),
            skills=row.get("skills", []),
            availability=avail,
            max_hours_per_week=float(row["max_hours_per_week"]),
            consecutive_days_limit=row.get("consecutive_days", 6),
            created_at=row["created_at"], updated_at=row["updated_at"],
        )

    # --- Forecasts ---

    def add_forecasts(self, forecasts):
        with self._cursor() as cur:
            for fc in forecasts:
                signals = [s.value if hasattr(s, 'value') else s for s in fc.signals_used]
                cur.execute("""
                    INSERT INTO forecasts (id, venue_id, forecast_date, hour, predicted_covers, confidence, signals_used, model_version)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (venue_id, forecast_date, hour, model_version) DO UPDATE SET
                        predicted_covers=EXCLUDED.predicted_covers, confidence=EXCLUDED.confidence
                """, (
                    fc.id, fc.venue_id, fc.date, fc.hour,
                    float(fc.predicted_covers), float(fc.confidence),
                    signals, fc.model_version,
                ))

    def get_forecasts(self, venue_id=None, start_date=None, end_date=None):
        conditions, params = [], []
        if venue_id:
            conditions.append("venue_id = %s")
            params.append(venue_id)
        if start_date:
            conditions.append("forecast_date >= %s")
            params.append(start_date)
        if end_date:
            conditions.append("forecast_date <= %s")
            params.append(end_date)

        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        with self._cursor() as cur:
            cur.execute(f"SELECT * FROM forecasts{where} ORDER BY forecast_date, hour", params)
            return [self._row_to_forecast(r) for r in cur.fetchall()]

    def _row_to_forecast(self, row):
        return DemandForecast(
            id=row["id"], venue_id=row["venue_id"],
            date=row["forecast_date"], hour=row["hour"],
            predicted_covers=float(row["predicted_covers"]),
            confidence=float(row["confidence"]),
            signals_used=row.get("signals_used", []),
            model_version=row["model_version"],
        )

    # --- Rosters ---

    def save_roster(self, roster):
        with self._cursor() as cur:
            cur.execute("""
                INSERT INTO rosters (id, venue_id, week_start, week_end, total_cost, created_at)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET total_cost=EXCLUDED.total_cost
            """, (
                roster.id, roster.venue_id, roster.week_start, roster.week_end,
                float(roster.total_cost) if roster.total_cost else None,
                roster.created_at,
            ))
            # Save shifts
            for shift in roster.shifts:
                cur.execute("""
                    INSERT INTO shifts (id, roster_id, employee_id, shift_date, start_time, end_time,
                        break_minutes, status, role, cost, penalty_multiplier)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO NOTHING
                """, (
                    shift.id, roster.id, shift.employee_id, shift.date,
                    shift.start_time, shift.end_time, shift.break_minutes,
                    shift.status.value, shift.role,
                    float(shift.cost) if shift.cost else None,
                    shift.penalty_multiplier,
                ))

    def list_rosters(self):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM rosters ORDER BY week_start DESC")
            rosters = []
            for row in cur.fetchall():
                cur.execute("SELECT * FROM shifts WHERE roster_id = %s ORDER BY shift_date, start_time", (row["id"],))
                shifts = [self._row_to_shift(s) for s in cur.fetchall()]
                rosters.append(self._row_to_roster(row, shifts))
            return rosters

    def get_roster(self, roster_id):
        with self._cursor() as cur:
            cur.execute("SELECT * FROM rosters WHERE id = %s", (roster_id,))
            row = cur.fetchone()
            if not row:
                return None
            cur.execute("SELECT * FROM shifts WHERE roster_id = %s ORDER BY shift_date, start_time", (roster_id,))
            shifts = [self._row_to_shift(s) for s in cur.fetchall()]
            return self._row_to_roster(row, shifts)

    def _row_to_roster(self, row, shifts):
        return Roster(
            id=row["id"], venue_id=row["venue_id"],
            week_start=row["week_start"], week_end=row["week_end"],
            shifts=shifts,
            total_cost=Decimal(str(row["total_cost"])) if row["total_cost"] else None,
            created_at=row["created_at"],
        )

    def _row_to_shift(self, row):
        return Shift(
            id=row["id"], employee_id=row["employee_id"],
            date=row["shift_date"],
            start_time=row["start_time"], end_time=row["end_time"],
            break_minutes=row.get("break_minutes", 0),
            status=ShiftStatus(row["status"]),
            role=row.get("role", "general"),
            cost=Decimal(str(row["cost"])) if row.get("cost") else None,
            penalty_multiplier=float(row.get("penalty_multiplier", 1.0)),
        )


# ============================================================================
# Factory
# ============================================================================

_instance: Optional[BaseStore] = None


def get_db() -> BaseStore:
    """Get the database store (singleton). Uses PostgreSQL if DATABASE_URL is set."""
    global _instance
    if _instance is None:
        if DATABASE_URL:
            try:
                _instance = PostgresStore(DATABASE_URL)
                logger.info("Using PostgreSQL store")
            except Exception as e:
                logger.warning("PostgreSQL unavailable (%s), falling back to in-memory", e)
                _instance = MemoryStore()
        else:
            logger.info("No DATABASE_URL set — using in-memory store")
            _instance = MemoryStore()
    return _instance


def reset_db():
    """Reset the database instance (for testing)."""
    global _instance
    _instance = None
