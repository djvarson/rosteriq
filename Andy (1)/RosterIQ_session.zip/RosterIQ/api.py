"""
RosterIQ FastAPI server.

Thin API layer over the existing engine modules. Provides REST endpoints
for roster generation, analysis, forecasting, and real-time decisions.

Run:
    uvicorn rosteriq.api:app --reload
    # or
    python -m rosteriq.api
"""

import os
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional
from collections import defaultdict

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from rosteriq import __version__
from rosteriq.models import (
    Employee, Shift, Roster, DemandForecast, VenueConfig,
    EmploymentType, ShiftStatus, AwardLevel, State,
    CostBreakdown, VarianceSignal, StaffingRecommendation,
)
from rosteriq.roster_optimiser import (
    generate_weekly_roster, generate_daily_roster,
    analyse_roster, suggest_improvements,
    calculate_required_staff, identify_peak_periods,
    DEFAULT_COVERS_PER_STAFF,
)
from rosteriq.cost_calculator import (
    calculate_shift_cost_breakdown, calculate_roster_cost,
    compare_rosters, calculate_labour_percentage,
    find_cost_savings_opportunities,
)
from rosteriq.variance_engine import (
    calculate_weighted_variance, detect_threshold_breach,
    create_signal, combine_forecasts, get_signal_summary,
)
from rosteriq.decision_engine import make_decision
from rosteriq.award_rules import (
    get_day_type, get_penalty_multiplier,
    validate_shift_compliance, get_public_holidays,
)
from rosteriq.ensemble import EnsembleForecaster
from rosteriq.database import get_db
from rosteriq.forecast_accuracy import (
    AccuracyTracker,
    backtest,
    score_week,
    worst_periods,
)
from rosteriq.scenario_engine import (
    MutationType,
    Scenario,
    ScenarioMutation,
    apply_scenario,
    build_remove_casuals_scenario,
    build_week_demand_scenario,
    compare_scenarios,
    run_sensitivity,
)


# ============================================================================
# App setup
# ============================================================================

app = FastAPI(
    title="RosterIQ",
    description="AI-powered predictive rostering for Australian hospitality",
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================================
# Data store — uses PostgreSQL when DATABASE_URL is set, otherwise in-memory
# ============================================================================

# The _store dict is kept for backward compatibility with all endpoint code.
# On startup, get_db() decides the backend (Postgres or memory).
# The _store proxy delegates to get_db() so we don't rewrite every endpoint.
_db = get_db()

class _StoreProxy(dict):
    """Dict-like proxy that delegates to the database layer."""

    def __getitem__(self, key):
        if key == "venues":
            return _VenueProxy(_db)
        if key == "employees":
            return _EmployeeProxy(_db)
        if key == "rosters":
            return _RosterProxy(_db)
        if key == "forecasts":
            return _ForecastProxy(_db)
        if key == "forecasters":
            return {}
        raise KeyError(key)


class _VenueProxy:
    def __init__(self, db): self._db = db
    def __setitem__(self, k, v): self._db.save_venue(v)
    def __getitem__(self, k):
        v = self._db.get_venue(k)
        if v is None: raise KeyError(k)
        return v
    def __contains__(self, k): return self._db.get_venue(k) is not None
    def get(self, k, default=None): return self._db.get_venue(k) or default
    def values(self): return self._db.list_venues()
    def __len__(self): return len(self._db.list_venues())


class _EmployeeProxy:
    def __init__(self, db): self._db = db
    def __setitem__(self, k, v): self._db.save_employee(v)
    def __getitem__(self, k):
        e = self._db.get_employee(k)
        if e is None: raise KeyError(k)
        return e
    def __contains__(self, k): return self._db.get_employee(k) is not None
    def get(self, k, default=None): return self._db.get_employee(k) or default
    def values(self): return self._db.list_employees()
    def __len__(self): return len(self._db.list_employees())


class _RosterProxy:
    def __init__(self, db): self._db = db
    def __setitem__(self, k, v): self._db.save_roster(v)
    def __getitem__(self, k):
        r = self._db.get_roster(k)
        if r is None: raise KeyError(k)
        return r
    def __contains__(self, k): return self._db.get_roster(k) is not None
    def get(self, k, default=None): return self._db.get_roster(k) or default
    def values(self): return self._db.list_rosters()
    def __len__(self): return len(self._db.list_rosters())


class _ForecastProxy(list):
    def __init__(self, db):
        super().__init__()
        self._db = db
    def extend(self, items):
        self._db.add_forecasts(list(items))
    def append(self, item):
        self._db.add_forecasts([item])
    def __iter__(self):
        return iter(self._db.get_forecasts())
    def __len__(self):
        return len(self._db.get_forecasts())


_store = _StoreProxy()


# ============================================================================
# JSON helpers — Decimal/date serialisation
# ============================================================================

class RIQJSONResponse(JSONResponse):
    def render(self, content) -> bytes:
        import json

        def default(obj):
            if isinstance(obj, Decimal):
                return float(obj)
            if isinstance(obj, (date, datetime)):
                return obj.isoformat()
            if isinstance(obj, set):
                return list(obj)
            if hasattr(obj, "model_dump"):
                return obj.model_dump()
            if hasattr(obj, "value"):
                return obj.value
            raise TypeError(f"Not serialisable: {type(obj)}")

        return json.dumps(content, default=default, ensure_ascii=False).encode("utf-8")


app.default_response_class = RIQJSONResponse


# ============================================================================
# Request/response schemas
# ============================================================================

class GenerateRosterRequest(BaseModel):
    venue_id: str
    week_start: date
    covers_per_staff: float = DEFAULT_COVERS_PER_STAFF


class DailyRosterRequest(BaseModel):
    venue_id: str
    target_date: date
    covers_per_staff: float = DEFAULT_COVERS_PER_STAFF


class VarianceRequest(BaseModel):
    signals: list[dict]  # list of {signal_type, value, weight, confidence, source}


class DecisionRequest(BaseModel):
    venue_id: str
    variance: float
    threshold: float = 0.15


class HealthResponse(BaseModel):
    status: str
    version: str
    modules: list[str]
    venues_loaded: int
    employees_loaded: int


# ============================================================================
# Health & info
# ============================================================================

@app.get("/", response_model=HealthResponse)
async def root():
    return HealthResponse(
        status="ok",
        version=__version__,
        modules=[
            "models", "award_rules", "cost_calculator", "variance_engine",
            "decision_engine", "ensemble", "tanda_adapter", "pos_import",
            "roster_optimiser",
        ],
        venues_loaded=len(_store["venues"]),
        employees_loaded=len(_store["employees"]),
    )


@app.get("/health")
async def health():
    return {"status": "ok", "version": __version__}


# ============================================================================
# Venue management
# ============================================================================

@app.post("/venues")
async def create_venue(venue: VenueConfig):
    _store["venues"][venue.id] = venue
    return {"id": venue.id, "status": "created"}


@app.get("/venues")
async def list_venues():
    return list(_store["venues"].values())


@app.get("/venues/{venue_id}")
async def get_venue(venue_id: str):
    if venue_id not in _store["venues"]:
        raise HTTPException(404, f"Venue {venue_id} not found")
    return _store["venues"][venue_id]


# ============================================================================
# Employee management
# ============================================================================

@app.post("/employees")
async def create_employee(employee: Employee):
    _store["employees"][employee.id] = employee
    return {"id": employee.id, "status": "created"}


@app.post("/employees/bulk")
async def bulk_create_employees(employees: list[Employee]):
    for emp in employees:
        _store["employees"][emp.id] = emp
    return {"count": len(employees), "status": "created"}


@app.get("/employees")
async def list_employees():
    return list(_store["employees"].values())


@app.get("/employees/{employee_id}")
async def get_employee(employee_id: str):
    if employee_id not in _store["employees"]:
        raise HTTPException(404, f"Employee {employee_id} not found")
    return _store["employees"][employee_id]


# ============================================================================
# Forecasts
# ============================================================================

@app.post("/forecasts")
async def add_forecasts(forecasts: list[DemandForecast]):
    _store["forecasts"].extend(forecasts)
    return {"count": len(forecasts), "status": "added"}


@app.get("/forecasts")
async def get_forecasts(
    venue_id: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
):
    results = _store["forecasts"]
    if venue_id:
        results = [f for f in results if f.venue_id == venue_id]
    if start_date:
        results = [f for f in results if f.date >= start_date]
    if end_date:
        results = [f for f in results if f.date <= end_date]
    return results


@app.get("/forecasts/required-staff")
async def get_required_staff(
    venue_id: str,
    target_date: date,
    covers_per_staff: float = DEFAULT_COVERS_PER_STAFF,
):
    day_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id and f.date == target_date
    ]
    if not day_forecasts:
        raise HTTPException(404, f"No forecasts for {venue_id} on {target_date}")

    venue = _store["venues"].get(venue_id)
    min_staff = venue.min_staff if venue else None
    required = calculate_required_staff(day_forecasts, covers_per_staff, min_staff)
    periods = identify_peak_periods(required)

    return {"date": target_date, "required_by_hour": required, "peak_periods": periods}


# ============================================================================
# Roster generation
# ============================================================================

@app.post("/rosters/generate")
async def generate_roster(req: GenerateRosterRequest):
    venue = _store["venues"].get(req.venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {req.venue_id} not found")

    employees = list(_store["employees"].values())
    if not employees:
        raise HTTPException(400, "No employees loaded")

    week_end = req.week_start + timedelta(days=6)
    forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == req.venue_id
        and req.week_start <= f.date <= week_end
    ]
    if not forecasts:
        raise HTTPException(400, f"No forecasts for {req.venue_id} in week of {req.week_start}")

    roster = generate_weekly_roster(
        req.week_start, forecasts, employees, venue, req.covers_per_staff
    )

    _store["rosters"][roster.id] = roster
    return roster


@app.post("/rosters/generate-daily")
async def generate_daily(req: DailyRosterRequest):
    venue = _store["venues"].get(req.venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {req.venue_id} not found")

    employees = list(_store["employees"].values())
    forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == req.venue_id and f.date == req.target_date
    ]

    shifts = generate_daily_roster(
        req.target_date, forecasts, employees, venue.state,
        venue_config=venue, covers_per_staff=req.covers_per_staff,
    )
    return {"date": req.target_date, "shifts": shifts, "count": len(shifts)}


# ============================================================================
# Roster analysis
# ============================================================================

@app.get("/rosters")
async def list_rosters():
    return list(_store["rosters"].values())


@app.get("/rosters/{roster_id}")
async def get_roster(roster_id: str):
    if roster_id not in _store["rosters"]:
        raise HTTPException(404, f"Roster {roster_id} not found")
    return _store["rosters"][roster_id]


@app.get("/rosters/{roster_id}/analyse")
async def analyse(roster_id: str):
    roster = _store["rosters"].get(roster_id)
    if not roster:
        raise HTTPException(404, f"Roster {roster_id} not found")

    venue = _store["venues"].get(roster.venue_id)
    state = venue.state if venue else State.vic

    result = analyse_roster(roster, _store["employees"], state)
    return result


@app.get("/rosters/{roster_id}/suggestions")
async def get_suggestions(
    roster_id: str,
    covers_per_staff: float = DEFAULT_COVERS_PER_STAFF,
):
    roster = _store["rosters"].get(roster_id)
    if not roster:
        raise HTTPException(404, f"Roster {roster_id} not found")

    venue = _store["venues"].get(roster.venue_id)
    state = venue.state if venue else State.vic

    week_end = roster.week_start + timedelta(days=6)
    forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == roster.venue_id
        and roster.week_start <= f.date <= week_end
    ]

    suggestions = suggest_improvements(
        roster, forecasts, _store["employees"], state, covers_per_staff
    )
    return {"roster_id": roster_id, "suggestions": suggestions, "count": len(suggestions)}


# ============================================================================
# Cost endpoints
# ============================================================================

@app.get("/costs/shift/{employee_id}")
async def shift_cost(
    employee_id: str,
    shift_date: date = Query(...),
    start_hour: int = Query(...),
    end_hour: int = Query(...),
    break_minutes: int = Query(0),
    state: State = Query(State.vic),
):
    emp = _store["employees"].get(employee_id)
    if not emp:
        raise HTTPException(404, f"Employee {employee_id} not found")

    from rosteriq.models import Shift, ShiftStatus
    from datetime import time
    shift = Shift(
        id="cost-calc", employee_id=employee_id, date=shift_date,
        start_time=time(start_hour, 0),
        end_time=time(end_hour if end_hour < 24 else 0, 0),
        break_minutes=break_minutes, status=ShiftStatus.scheduled, role="general",
    )
    breakdown = calculate_shift_cost_breakdown(emp, shift, state)
    return breakdown


@app.get("/costs/labour-percentage")
async def labour_pct(
    roster_id: str,
    revenue: float,
):
    roster = _store["rosters"].get(roster_id)
    if not roster:
        raise HTTPException(404, f"Roster {roster_id} not found")

    venue = _store["venues"].get(roster.venue_id)
    state = venue.state if venue else State.vic

    total_cost = calculate_roster_cost(roster, _store["employees"], state)
    pct = calculate_labour_percentage(total_cost, Decimal(str(revenue)))
    return {"roster_id": roster_id, "labour_cost": total_cost, "revenue": revenue, "percentage": pct}


# ============================================================================
# Variance & decisions (real-time)
# ============================================================================

@app.post("/variance/calculate")
async def calc_variance(req: VarianceRequest):
    signals = []
    for s in req.signals:
        signals.append(create_signal(
            signal_type=s["signal_type"],
            value=s["value"],
            confidence=s.get("confidence", 0.8),
            source=s.get("source", "api"),
        ))
    variance = calculate_weighted_variance(signals)
    breach = detect_threshold_breach(variance)
    summary = get_signal_summary(signals)
    return {
        "variance": variance,
        "breach": breach,
        "signals": summary,
    }


@app.post("/decisions/recommend")
async def recommend_decision(req: DecisionRequest):
    venue = _store["venues"].get(req.venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {req.venue_id} not found")

    # Get today's active shifts
    today = date.today()
    active_shifts = []
    for roster in _store["rosters"].values():
        for shift in roster.shifts:
            if shift.date == today and shift.status in (
                ShiftStatus.scheduled, ShiftStatus.confirmed, ShiftStatus.in_progress
            ):
                active_shifts.append(shift)

    employees = list(_store["employees"].values())
    available = [e for e in employees if e.id not in {s.employee_id for s in active_shifts}]

    result = make_decision(
        variance=req.variance,
        active_shifts=active_shifts,
        available_employees=available,
        employee_lookup=_store["employees"],
        state=venue.state,
        threshold=req.threshold,
    )
    return result


# ============================================================================
# Award rules helpers
# ============================================================================

@app.get("/awards/day-type")
async def day_type_check(check_date: date, state: State = State.vic):
    dt = get_day_type(check_date, state)
    return {"date": check_date, "state": state, "day_type": dt}


@app.get("/awards/penalty-rate")
async def penalty_rate(
    employment_type: EmploymentType,
    check_date: date,
    state: State = State.vic,
):
    dt = get_day_type(check_date, state)
    mult = get_penalty_multiplier(employment_type, dt)
    return {
        "employment_type": employment_type,
        "date": check_date,
        "day_type": dt,
        "multiplier": float(mult),
    }


@app.get("/awards/public-holidays/{state}")
async def public_holidays(state: State, year: int = 2026):
    holidays = get_public_holidays(state, year)
    return {"state": state, "year": year, "holidays": holidays}


# ============================================================================
# POS data import
# ============================================================================


class POSImportRequest(BaseModel):
    venue_id: str
    csv_data: str  # Raw CSV content
    system: Optional[str] = None  # 'lightspeed', 'square', 'hl' — auto-detected if omitted


@app.post("/pos/import")
async def import_pos(req: POSImportRequest):
    """
    Import POS transaction data from a CSV string.

    Accepts raw CSV content (from Lightspeed, Square, or H&L),
    normalises it, and stores the aggregated hourly records.
    The data feeds the ensemble forecaster for demand prediction.
    """
    venue = _store["venues"].get(req.venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {req.venue_id} not found")

    from rosteriq.pos_import import import_pos_string
    try:
        records = import_pos_string(req.csv_data, system=req.system)
    except ValueError as e:
        raise HTTPException(400, str(e))

    # Convert to DemandForecasts and store
    new_forecasts = []
    for rec in records:
        fc = DemandForecast(
            id=f"pos-{rec['date']}-{rec['hour']}",
            venue_id=req.venue_id,
            date=rec["date"],
            hour=rec["hour"],
            predicted_covers=float(rec["covers"]),
            confidence=0.9,
            signals_used=["historical"],
            model_version="pos-import-v1",
        )
        new_forecasts.append(fc)

    _store["forecasts"].extend(new_forecasts)

    return {
        "status": "imported",
        "records": len(records),
        "forecasts_created": len(new_forecasts),
        "date_range": {
            "from": str(records[0]["date"]) if records else None,
            "to": str(records[-1]["date"]) if records else None,
        },
    }


@app.post("/pos/import-file")
async def import_pos_file(venue_id: str = Query(...), system: Optional[str] = None):
    """
    Import POS data from an uploaded file.

    Use with multipart/form-data upload. The file is parsed,
    normalised, and stored as historical demand data.
    """
    # This endpoint would use FastAPI's UploadFile in production
    # For now, direct users to /pos/import with CSV string
    return {
        "status": "use_csv_endpoint",
        "message": "Upload your CSV to /pos/import as csv_data field",
        "supported_systems": ["lightspeed", "square", "hl"],
    }


# ============================================================================
# What-if scenario comparison
# ============================================================================

class MutationIn(BaseModel):
    """API input model for a single scenario mutation."""
    type: str
    employee_id: Optional[str] = None
    shift_id: Optional[str] = None
    replacement_employee_id: Optional[str] = None
    date: Optional[str] = None           # ISO date string
    start_hour: Optional[int] = None
    end_hour: Optional[int] = None
    role: str = "general"
    covers_ratio: Optional[float] = None
    demand_multiplier: Optional[float] = None

    def to_mutation(self) -> ScenarioMutation:
        from datetime import date as date_type
        d = date_type.fromisoformat(self.date) if self.date else None
        try:
            m_type = MutationType(self.type)
        except ValueError:
            raise HTTPException(400, f"Unknown mutation type: {self.type!r}. "
                                f"Valid types: {[t.value for t in MutationType]}")
        return ScenarioMutation(
            type=m_type,
            employee_id=self.employee_id,
            shift_id=self.shift_id,
            replacement_employee_id=self.replacement_employee_id,
            date=d,
            start_hour=self.start_hour,
            end_hour=self.end_hour,
            role=self.role,
            covers_ratio=self.covers_ratio,
            demand_multiplier=self.demand_multiplier,
        )


class ScenarioIn(BaseModel):
    """API input model for a single scenario."""
    name: str
    notes: str = ""
    mutations: list[MutationIn] = []

    def to_scenario(self) -> Scenario:
        return Scenario(
            name=self.name,
            notes=self.notes,
            mutations=[m.to_mutation() for m in self.mutations],
        )


class ScenarioRequest(BaseModel):
    """POST body for /scenarios/compare."""
    venue_id: str
    roster_id: str
    scenarios: list[ScenarioIn]
    covers_ratio: float = DEFAULT_COVERS_PER_STAFF
    rank_by: str = "cost"
    revenue: Optional[float] = None


class SingleScenarioRequest(BaseModel):
    """POST body for /scenarios/apply."""
    venue_id: str
    roster_id: str
    scenario: ScenarioIn
    covers_ratio: float = DEFAULT_COVERS_PER_STAFF
    revenue: Optional[float] = None


class SensitivityRequest(BaseModel):
    """POST body for /scenarios/sensitivity."""
    venue_id: str
    roster_id: str
    parameter: str
    values: list[float]
    covers_ratio: float = DEFAULT_COVERS_PER_STAFF


def _get_roster_context(venue_id: str, roster_id: str):
    """Fetch roster, employees, venue, and forecasts from store. Raises on missing."""
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id!r} not found")

    roster = next((r for r in _store["rosters"] if r.id == roster_id), None)
    if not roster:
        raise HTTPException(404, f"Roster {roster_id!r} not found")

    employees = {e.id: e for e in _store["employees"] if True}

    forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id
        and roster.week_start <= f.date <= roster.week_end
    ]

    return roster, employees, venue, forecasts


@app.post("/scenarios/apply")
async def scenario_apply(req: SingleScenarioRequest):
    """
    Apply a single what-if scenario to a roster and return full analysis.

    Returns cost breakdown, Fair Work compliance status, hourly coverage
    vs demand, and which mutations were applied or skipped.

    Example scenario — remove one employee on a specific day:

        {
            "venue_id": "venue-1",
            "roster_id": "r-abc",
            "scenario": {
                "name": "Remove Jake on Monday",
                "mutations": [
                    {
                        "type": "remove_employee",
                        "employee_id": "emp-jake",
                        "date": "2026-04-13"
                    }
                ]
            }
        }
    """
    roster, employees, venue, forecasts = _get_roster_context(req.venue_id, req.roster_id)
    scenario = req.scenario.to_scenario()

    errors = scenario.validate()
    if errors:
        raise HTTPException(400, {"validation_errors": errors})

    revenue = Decimal(str(req.revenue)) if req.revenue else None
    result = apply_scenario(
        roster, employees, venue, forecasts, scenario,
        covers_ratio=req.covers_ratio, revenue=revenue,
    )
    return result.as_dict()


@app.post("/scenarios/compare")
async def scenario_compare(req: ScenarioRequest):
    """
    Run and compare multiple what-if scenarios side-by-side.

    Always evaluates the base (unmodified) roster as the reference point.
    Returns all scenario results plus a ranked leaderboard and a plain-English
    recommendation.

    Rank by: "cost" (default), "coverage", or "compliance".
    """
    if not req.scenarios:
        raise HTTPException(400, "At least one scenario is required")

    roster, employees, venue, forecasts = _get_roster_context(req.venue_id, req.roster_id)

    scenarios = [s.to_scenario() for s in req.scenarios]
    for scenario in scenarios:
        errors = scenario.validate()
        if errors:
            raise HTTPException(400, {
                "scenario": scenario.name,
                "validation_errors": errors,
            })

    revenue = Decimal(str(req.revenue)) if req.revenue else None
    comparison = compare_scenarios(
        roster, employees, venue, forecasts, scenarios,
        covers_ratio=req.covers_ratio, revenue=revenue,
        rank_by=req.rank_by,
    )
    return comparison.as_dict()


@app.post("/scenarios/sensitivity")
async def scenario_sensitivity(req: SensitivityRequest):
    """
    Sweep one parameter across a range and return the metric curve.

    Supported parameters:
    - ``covers_ratio``: covers-per-staff ratio (e.g. [10, 12, 14, 16, 18, 20])
    - ``demand_multiplier``: demand scale factor (e.g. [0.8, 0.9, 1.0, 1.1, 1.2])

    Returns a data point per value showing total_cost, understaffed_hours,
    overstaffed_hours, and coverage_score, plus the optimal value (lowest cost
    while keeping coverage_score ≥ 0.8).
    """
    roster, employees, venue, forecasts = _get_roster_context(req.venue_id, req.roster_id)

    if not req.values:
        raise HTTPException(400, "values must be a non-empty list")

    try:
        result = run_sensitivity(
            roster, employees, venue, forecasts,
            parameter=req.parameter,
            values=req.values,
            covers_ratio=req.covers_ratio,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))

    return result.as_dict()


@app.post("/scenarios/quick/remove-casuals")
async def scenario_quick_remove_casuals(
    venue_id: str = Query(...),
    roster_id: str = Query(...),
    date: Optional[str] = Query(None, description="Limit to a single date (YYYY-MM-DD)"),
    covers_ratio: float = Query(DEFAULT_COVERS_PER_STAFF),
):
    """
    Quick scenario: remove all casual employees (optionally on one date).

    Shows the maximum labour saving achievable by cutting casual shifts —
    a useful baseline for "how low can we go?" analysis.
    """
    from datetime import date as date_type
    roster, employees, venue, forecasts = _get_roster_context(venue_id, roster_id)

    date_filter = date_type.fromisoformat(date) if date else None
    scenario = build_remove_casuals_scenario(employees, date_filter=date_filter)

    result = apply_scenario(roster, employees, venue, forecasts, scenario, covers_ratio=covers_ratio)
    return result.as_dict()


@app.post("/scenarios/quick/demand-shift")
async def scenario_quick_demand_shift(
    venue_id: str = Query(...),
    roster_id: str = Query(...),
    multiplier: float = Query(..., gt=0, description="Demand scale factor, e.g. 1.2 = 20% busier"),
    covers_ratio: float = Query(DEFAULT_COVERS_PER_STAFF),
):
    """
    Quick scenario: scale all forecast demand by a multiplier.

    Use 1.2 for "what if it's 20% busier than forecast?" or 0.8 for a quiet week.
    Shows coverage gaps that would emerge if demand differs from the AI forecast.
    """
    roster, employees, venue, forecasts = _get_roster_context(venue_id, roster_id)
    scenario = build_week_demand_scenario(forecasts, multiplier=multiplier)
    result = apply_scenario(roster, employees, venue, forecasts, scenario, covers_ratio=covers_ratio)
    return result.as_dict()


# ============================================================================
# Forecast accuracy & backtesting
# ============================================================================

# In-memory per-venue accuracy trackers. In production these would be backed
# by the forecast_accuracy_records Postgres table (schema_accuracy.sql).
_accuracy_trackers: dict[str, AccuracyTracker] = {}


def _get_tracker(venue_id: str) -> AccuracyTracker:
    if venue_id not in _accuracy_trackers:
        _accuracy_trackers[venue_id] = AccuracyTracker(venue_id=venue_id)
    return _accuracy_trackers[venue_id]


class ActualsPayload(BaseModel):
    """POST body for recording a week's actual cover counts."""
    venue_id: str
    # Nested: { "2026-04-05": { "12": 88, "13": 95, ... }, ... }
    actuals: dict[str, dict[str, float]]


@app.post("/accuracy/record")
async def record_actuals(payload: ActualsPayload):
    """
    Record actual covers for dates where forecasts already exist.

    Call this after each week of trading closes with the confirmed POS data.
    The tracker pairs actuals against previously stored forecasts and
    accumulates them for ongoing accuracy scoring.
    """
    tracker = _get_tracker(payload.venue_id)

    # Parse the string-keyed payload into typed structures
    from datetime import date as date_type
    actuals: dict[date_type, dict[int, float]] = {}
    for date_str, hours in payload.actuals.items():
        try:
            d = date_type.fromisoformat(date_str)
        except ValueError:
            raise HTTPException(400, f"Invalid date: {date_str!r}")
        actuals[d] = {int(h): float(v) for h, v in hours.items()}

    # Match against stored forecasts for this venue
    venue_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == payload.venue_id and f.date in actuals
    ]

    recorded = tracker.record(venue_forecasts, actuals)
    return {
        "venue_id": payload.venue_id,
        "paired_records": recorded,
        "total_records": tracker.record_count,
    }


@app.get("/accuracy/score")
async def get_accuracy_score(
    venue_id: str = Query(..., description="Venue ID"),
    since: Optional[str] = Query(None, description="Score records from this date (YYYY-MM-DD)"),
    until: Optional[str] = Query(None, description="Score records up to this date (YYYY-MM-DD)"),
):
    """
    Return live accuracy metrics from the ongoing tracker.

    Scores all recorded (forecast, actual) pairs for the venue. Optionally
    filter to a date range. Returns MAE, RMSE, MAPE, bias, R², within-band
    rates, and hourly / weekday / signal breakdowns.
    """
    tracker = _get_tracker(venue_id)

    since_date = None
    until_date = None
    if since:
        try:
            from datetime import date as date_type
            since_date = date_type.fromisoformat(since)
        except ValueError:
            raise HTTPException(400, f"Invalid since date: {since!r}")
    if until:
        try:
            from datetime import date as date_type
            until_date = date_type.fromisoformat(until)
        except ValueError:
            raise HTTPException(400, f"Invalid until date: {until!r}")

    report = tracker.score(since=since_date, until=until_date)
    return report.as_dict()


@app.post("/accuracy/backtest")
async def run_backtest(
    venue_id: str = Query(..., description="Venue ID"),
    min_train_weeks: int = Query(4, ge=2, le=52, description="Minimum training weeks"),
    test_weeks: int = Query(1, ge=1, le=4, description="Test window size in weeks"),
):
    """
    Run a walk-forward backtest on all historical POS data for the venue.

    Trains on weeks 1–N, predicts week N+1, slides forward. Returns per-window
    metrics plus aggregated breakdowns by hour, weekday, and signal type.
    No look-ahead bias — each window only trains on data available at the time.

    This can be slow for large datasets; consider running asynchronously
    for venues with 12+ months of history.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id!r} not found")

    # Use historical POS data from the store
    historical = [
        {"date": f.date, "hour": f.hour, "covers": f.predicted_covers}
        for f in _store["forecasts"]
        if f.venue_id == venue_id
    ]

    # Prefer actual covers from the tracker (more accurate than stored forecasts)
    tracker = _get_tracker(venue_id)
    if tracker.record_count > 0:
        historical = tracker.to_historical_data()

    if not historical:
        raise HTTPException(
            400,
            "No historical data found for this venue. Import POS data first "
            "via POST /pos-import or record actuals via POST /accuracy/record."
        )

    report = backtest(
        venue_config=venue,
        historical_data=historical,
        min_train_weeks=min_train_weeks,
        test_weeks=test_weeks,
    )
    return report.as_dict()


@app.get("/accuracy/worst-periods")
async def get_worst_periods(
    venue_id: str = Query(..., description="Venue ID"),
    top_n: int = Query(3, ge=1, le=10, description="Number of worst periods to return"),
):
    """
    Return the top-N highest-error hours and weekdays from the tracker.

    A quick diagnostic to identify where the model needs improvement —
    e.g. 'lunch on Tuesdays is consistently under-forecast by 20%'.
    """
    tracker = _get_tracker(venue_id)
    report = tracker.score()

    if report.total_forecasts_scored == 0:
        return {"venue_id": venue_id, "hours": [], "weekdays": [], "total_scored": 0}

    periods = worst_periods(report, top_n=top_n)
    periods["venue_id"] = venue_id
    periods["total_scored"] = report.total_forecasts_scored
    return periods


@app.get("/accuracy/summary")
async def get_accuracy_summary(venue_id: str = Query(..., description="Venue ID")):
    """
    Compact accuracy summary — overall metrics + worst periods.

    Designed for the dashboard 'model health' widget. Returns a flat dict
    with headline numbers and actionable insights.
    """
    tracker = _get_tracker(venue_id)
    report = tracker.score()

    if report.total_forecasts_scored == 0:
        return {
            "venue_id": venue_id,
            "status": "no_data",
            "message": "No accuracy records yet. Record actuals after each week closes.",
            "total_scored": 0,
        }

    overall = report.overall.as_dict()
    periods = worst_periods(report, top_n=3)

    return {
        "venue_id": venue_id,
        "status": "ok",
        "total_scored": report.total_forecasts_scored,
        "overall": overall,
        "worst_hour": report.worst_hour,
        "best_hour": report.best_hour,
        "worst_weekday": report.worst_weekday,
        "worst_periods": periods,
        "model_health": _model_health_label(overall["mape_pct"]),
    }


def _model_health_label(mape_pct: float) -> str:
    """Translate MAPE % into a human-readable health label."""
    if mape_pct < 10:
        return "excellent"
    elif mape_pct < 20:
        return "good"
    elif mape_pct < 35:
        return "fair"
    else:
        return "needs_improvement"


# ============================================================================
# Demo data loader
# ============================================================================

@app.post("/demo/load")
async def load_demo():
    """Load demo data (same as CLI demo) for quick testing."""
    from rosteriq.cli import _build_demo_employees, _build_demo_forecasts, _build_demo_venue

    venue = _build_demo_venue()
    employees = _build_demo_employees()

    today = date.today()
    days_until_monday = (7 - today.weekday()) % 7
    if days_until_monday == 0:
        days_until_monday = 7
    week_start = today + timedelta(days=days_until_monday)

    forecasts = _build_demo_forecasts(week_start)

    _store["venues"][venue.id] = venue
    for emp in employees:
        _store["employees"][emp.id] = emp
    _store["forecasts"].extend(forecasts)

    return {
        "status": "loaded",
        "venue": venue.name,
        "employees": len(employees),
        "forecasts": len(forecasts),
        "week_start": week_start,
    }


# ============================================================================
# Tanda OAuth & webhook endpoints
# ============================================================================

TANDA_CLIENT_ID = os.environ.get("TANDA_CLIENT_ID", "")
TANDA_CLIENT_SECRET = os.environ.get("TANDA_CLIENT_SECRET", "")
TANDA_REDIRECT_URI = os.environ.get("TANDA_REDIRECT_URI", "http://localhost:8000/tanda/callback")
TANDA_WEBHOOK_SECRET = os.environ.get("TANDA_WEBHOOK_SECRET", "")


@app.get("/tanda/connect")
async def tanda_connect(venue_id: str):
    """Redirect the venue owner to Tanda's OAuth consent screen."""
    if not TANDA_CLIENT_ID:
        raise HTTPException(400, "TANDA_CLIENT_ID not configured")

    from rosteriq.tanda_adapter import TandaOAuth
    oauth = TandaOAuth(TANDA_CLIENT_ID, TANDA_CLIENT_SECRET, TANDA_REDIRECT_URI)
    url = oauth.get_authorize_url()

    # Store venue_id in a state param so we know which venue to link
    return {
        "authorize_url": url + f"&state={venue_id}",
        "instructions": "Redirect the venue owner to authorize_url",
    }


@app.get("/tanda/callback")
async def tanda_callback(code: str, state: str = ""):
    """
    OAuth callback — Tanda redirects here after the venue owner authorizes.

    Exchanges the authorization code for tokens and stores them.
    The 'state' param carries the venue_id.
    """
    if not TANDA_CLIENT_ID:
        raise HTTPException(400, "TANDA_CLIENT_ID not configured")

    from rosteriq.tanda_adapter import TandaOAuth
    oauth = TandaOAuth(TANDA_CLIENT_ID, TANDA_CLIENT_SECRET, TANDA_REDIRECT_URI)

    credentials = await oauth.exchange_code(code)
    venue_id = state

    # Store credentials (in production, encrypt and save to tanda_credentials table)
    if venue_id:
        # Attach to venue
        _store.get("tanda_creds", {})[venue_id] = credentials

    return {
        "status": "connected",
        "venue_id": venue_id,
        "token_expires": credentials.token_expires_at.isoformat() if credentials.token_expires_at else None,
    }


@app.post("/tanda/sync/{venue_id}")
async def tanda_sync(venue_id: str):
    """
    Sync employees and shifts from Tanda for a connected venue.

    Pulls all employees and upcoming shifts, maps them to RosterIQ models,
    and stores them in the database.
    """
    from rosteriq.tanda_adapter import TandaAdapter

    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    # Get stored credentials
    creds = _store.get("tanda_creds", {}).get(venue_id)
    if not creds:
        raise HTTPException(400, f"Venue {venue_id} not connected to Tanda. Use /tanda/connect first.")

    async with TandaAdapter(creds, state=venue.state) as tanda:
        # Health check
        healthy = await tanda.health_check()
        if not healthy:
            raise HTTPException(502, "Cannot reach Tanda API")

        # Sync employees
        employees = await tanda.get_employees()
        for emp in employees:
            _store["employees"][emp.id] = emp

        # Sync upcoming shifts (next 2 weeks)
        today = date.today()
        shifts = await tanda.get_shifts(today, today + timedelta(days=14))

    return {
        "status": "synced",
        "venue_id": venue_id,
        "employees_synced": len(employees),
        "shifts_synced": len(shifts),
    }


@app.post("/tanda/webhook")
async def tanda_webhook(request_obj: dict):
    """
    Receive webhook events from Tanda.

    Supported events:
    - user.created / user.updated: Re-sync the affected employee
    - shift.updated: Update the shift in our store
    - clockin.updated: Log for real-time variance engine
    - roster.published: Trigger roster comparison
    """
    event_type = request_obj.get("event") or request_obj.get("type", "unknown")
    payload = request_obj.get("payload") or request_obj.get("data", {})

    # Log the webhook for audit
    import logging
    logging.getLogger(__name__).info("Tanda webhook: %s", event_type)

    # Process based on event type
    if event_type in ("user.created", "user.updated"):
        # Could trigger employee re-sync here
        return {"status": "received", "action": "employee_sync_queued", "event": event_type}

    elif event_type == "shift.updated":
        return {"status": "received", "action": "shift_updated", "event": event_type}

    elif event_type == "clockin.updated":
        return {"status": "received", "action": "clockin_logged", "event": event_type}

    elif event_type == "roster.published":
        return {"status": "received", "action": "comparison_queued", "event": event_type}

    return {"status": "received", "action": "no_handler", "event": event_type}


# ============================================================================
# Dashboard endpoints — real-time visibility & signal aggregation
# ============================================================================

from rosteriq.data_feeds.base import FeedSignal, FeedCategory, Location, SignalStrength, STRENGTH_MULTIPLIERS
from rosteriq.data_feeds.aggregator import SignalAggregator
import random
import hashlib


# Request/response schemas for dashboard
class DemandOutlookRequest(BaseModel):
    venue_id: str
    target_date: date


class SignalDashboardRequest(BaseModel):
    venue_id: str
    start_date: date
    end_date: Optional[date] = None


class LivePulseRequest(BaseModel):
    venue_id: str


class DataFeedConfig(BaseModel):
    venue_id: str
    feeds_enabled: dict  # {feed_name: True/False}
    api_keys: Optional[dict] = None  # {feed_name: api_key}


def _generate_demo_signals(venue_id: str, target_date: date) -> list[dict]:
    """
    Generate deterministic, realistic-looking demo signals for an Australian pub scenario.
    Same date = same signals (deterministic based on venue_id + date hash).
    """
    # Seed based on venue_id and date so it's deterministic
    seed = int(hashlib.md5(f"{venue_id}{target_date}".encode()).hexdigest(), 16) % (2**31)
    rng = random.Random(seed)

    signals = []
    now = datetime.now()

    # Weather signals (sunny, rainy, cold affects foot traffic)
    weather_types = ["sunny", "rainy", "overcast", "hot", "cool"]
    weather_impact = rng.choice(weather_types)
    signals.append({
        "category": "weather",
        "source": "bom",
        "strength": rng.choice([s.value for s in SignalStrength]),
        "value": weather_impact,
        "confidence": rng.uniform(0.7, 0.95),
        "description": f"Bureau of Meteorology: {weather_impact.title()} conditions",
        "signal_hour": now.hour,
        "fetched_at": now.isoformat(),
    })

    # Local events (footy, concert, market day)
    event_types = ["AFL round", "local market", "school holidays", "concert", "sports match"]
    has_event = rng.random() > 0.6
    if has_event:
        event = rng.choice(event_types)
        signals.append({
            "category": "local_events",
            "source": "eventbrite",
            "strength": rng.choice([s.value for s in SignalStrength]),
            "value": event,
            "confidence": rng.uniform(0.8, 1.0),
            "description": f"Detected upcoming {event} in area",
            "signal_hour": now.hour,
            "fetched_at": now.isoformat(),
        })

    # Social media buzz (mentions of the venue, trending hashtags)
    buzz_levels = ["low", "medium", "high", "viral"]
    socmed_signal = {
        "category": "social_media",
        "source": "twitter_api",
        "strength": rng.choice([s.value for s in SignalStrength]),
        "value": rng.choice(buzz_levels),
        "confidence": rng.uniform(0.65, 0.9),
        "description": f"Social media mentions: {rng.choice(buzz_levels)} buzz detected",
        "signal_hour": now.hour,
        "fetched_at": now.isoformat(),
    }
    signals.append(socmed_signal)

    # Competitor activity (nearby pubs have events, promos)
    competitor_signal = {
        "category": "competitor_activity",
        "source": "web_scraper",
        "strength": rng.choice([s.value for s in SignalStrength]),
        "value": f"nearby_promo_{'active' if rng.random() > 0.5 else 'none'}",
        "confidence": rng.uniform(0.7, 0.85),
        "description": "Competitor promotions detected in 2km radius",
        "signal_hour": now.hour,
        "fetched_at": now.isoformat(),
    }
    signals.append(competitor_signal)

    # Staffing readiness (roster signal — internal)
    roster_signal = {
        "category": "staff_availability",
        "source": "roster_system",
        "strength": rng.choice([s.value for s in SignalStrength]),
        "value": rng.randint(3, 12),
        "confidence": 1.0,
        "description": f"Current roster: {rng.randint(3, 12)} staff scheduled today",
        "signal_hour": now.hour,
        "fetched_at": now.isoformat(),
    }
    signals.append(roster_signal)

    # Booking/reservation signals (if available from booking system)
    if rng.random() > 0.4:
        booking_signal = {
            "category": "reservations",
            "source": "booking_system",
            "strength": rng.choice([s.value for s in SignalStrength]),
            "value": rng.randint(2, 8),
            "confidence": rng.uniform(0.8, 1.0),
            "description": f"{rng.randint(2, 8)} reservations logged for today",
            "signal_hour": now.hour,
            "fetched_at": now.isoformat(),
        }
        signals.append(booking_signal)

    # Payroll/award period (impacts cost, may affect demand)
    day_type = get_day_type(target_date, State.vic)
    if str(day_type).lower() in ["public_holiday", "weekend"]:
        payroll_signal = {
            "category": "payroll_cycles",
            "source": "calendar",
            "strength": "high",
            "value": str(day_type),
            "confidence": 1.0,
            "description": f"{str(day_type).replace('_', ' ').title()} — penalty rates apply",
            "signal_hour": now.hour,
            "fetched_at": now.isoformat(),
        }
        signals.append(payroll_signal)

    return signals


def _demand_classification(predicted_covers: float, venue_avg: float = 45) -> str:
    """Classify demand level based on covers."""
    if predicted_covers < venue_avg * 0.4:
        return "quiet"
    elif predicted_covers < venue_avg * 0.7:
        return "normal"
    elif predicted_covers < venue_avg * 1.2:
        return "busy"
    elif predicted_covers < venue_avg * 1.5:
        return "very_busy"
    else:
        return "extreme"


def _get_today_costs(roster: Optional[Roster], employees_lookup: dict) -> float:
    """Calculate total labour cost for today's active shifts."""
    if not roster:
        return 0.0
    today = date.today()
    today_shifts = [s for s in roster.shifts if s.date == today]
    total = 0.0
    for shift in today_shifts:
        emp = employees_lookup.get(shift.employee_id)
        if emp:
            bd = calculate_shift_cost_breakdown(emp, shift, State.vic)
            total += float(bd.get("total_cost", 0))
    return total


@app.get("/dashboard/{venue_id}/overview")
async def dashboard_overview(venue_id: str):
    """
    GET /dashboard/{venue_id}/overview

    Returns the full dashboard overview for a venue: venue info, demand outlook,
    active signals, roster summary, week-ahead forecast, top signals, and costs.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    today = date.today()

    # Today's signals
    demo_signals = _generate_demo_signals(venue_id, today)

    # Demand outlook for today
    day_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id and f.date == today
    ]
    if day_forecasts:
        avg_covers = sum(f.predicted_covers for f in day_forecasts) / len(day_forecasts)
    else:
        avg_covers = 45  # fallback

    # Week ahead (next 7 days)
    week_forecast = []
    for i in range(7):
        d = today + timedelta(days=i)
        d_forecasts = [
            f for f in _store["forecasts"]
            if f.venue_id == venue_id and f.date == d
        ]
        if d_forecasts:
            pred_covers = sum(f.predicted_covers for f in d_forecasts) / len(d_forecasts)
        else:
            pred_covers = avg_covers + random.uniform(-10, 10)
        week_forecast.append({
            "date": d.isoformat(),
            "demand_level": _demand_classification(pred_covers, avg_covers),
            "predicted_covers": round(pred_covers, 1),
        })

    # Roster summary for today
    today_roster = None
    for r in _store["rosters"].values():
        if r.venue_id == venue_id:
            today_roster = r
            break

    today_shifts = []
    if today_roster:
        today_shifts = [s for s in today_roster.shifts if s.date == today]

    staff_cost_today = _get_today_costs(today_roster, _store["employees"])

    # Demand outlook summary
    demand_level = _demand_classification(avg_covers, avg_covers)
    bullish_pct = random.uniform(0.6, 0.95) if demand_level in ["busy", "very_busy", "extreme"] else random.uniform(0.2, 0.5)

    # Top 3 signals by strength
    top_signals = sorted(
        demo_signals,
        key=lambda s: STRENGTH_MULTIPLIERS.get(s["strength"], 1.0),
        reverse=True
    )[:3]

    return {
        "venue": {
            "id": venue.id,
            "name": venue.name,
            "state": venue.state.value,
            "timezone": "Australia/Melbourne",
        },
        "demand_outlook_today": {
            "classification": demand_level,
            "bullish_percentage": round(bullish_pct * 100, 1),
            "trend": "up" if bullish_pct > 0.5 else "down",
        },
        "active_signals": {
            "total": len(demo_signals),
            "by_category": defaultdict(int),
        },
        "roster_summary_today": {
            "shifts_scheduled": len(today_shifts),
            "staff_on_duty": len(set(s.employee_id for s in today_shifts if s.status in [ShiftStatus.in_progress, ShiftStatus.confirmed])),
            "total_scheduled": len(set(s.employee_id for s in today_shifts)),
            "labour_cost": round(staff_cost_today, 2),
        },
        "week_ahead_forecast": week_forecast,
        "top_impactful_signals": top_signals,
        "labour_cost_vs_budget": {
            "today_cost": round(staff_cost_today, 2),
            "budget": round(float(venue.budget) if venue.budget else 1000, 2),
            "remaining": round(float(venue.budget) - staff_cost_today if venue.budget else 1000 - staff_cost_today, 2),
        },
    }


@app.get("/dashboard/{venue_id}/signals")
async def dashboard_signals(
    venue_id: str,
    start_date: date = Query(None),
    end_date: Optional[date] = Query(None),
):
    """
    GET /dashboard/{venue_id}/signals?start_date=2026-04-04&end_date=2026-04-05

    Returns all active signals for the venue grouped by category.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    if start_date is None:
        start_date = date.today()
    if end_date is None:
        end_date = start_date

    # Collect signals across the date range
    all_signals = []
    for d in [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]:
        all_signals.extend(_generate_demo_signals(venue_id, d))

    # Group by category
    by_category = defaultdict(list)
    for sig in all_signals:
        by_category[sig["category"]].append(sig)

    # Summary stats
    return {
        "venue_id": venue_id,
        "period": {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
        },
        "summary": {
            "total_signals": len(all_signals),
            "dominant_category": max(by_category.keys(), key=lambda k: len(by_category[k])) if by_category else None,
            "overall_variance": round(random.uniform(0.05, 0.25), 3),
        },
        "signals_by_category": dict(by_category),
    }


@app.get("/dashboard/{venue_id}/demand-outlook")
async def dashboard_demand_outlook(
    venue_id: str,
    target_date: date = Query(None),
):
    """
    GET /dashboard/{venue_id}/demand-outlook?target_date=2026-04-04

    Returns hour-by-hour demand prediction for the day.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    if target_date is None:
        target_date = date.today()

    # Get forecasts for this day
    day_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id and f.date == target_date
    ]

    # Build hour-by-hour array
    hourly = []
    for hour in range(24):
        hour_forecasts = [f for f in day_forecasts if f.hour == hour]
        if hour_forecasts:
            pred_covers = sum(f.predicted_covers for f in hour_forecasts) / len(hour_forecasts)
            confidence = sum(f.confidence for f in hour_forecasts) / len(hour_forecasts)
        else:
            # Generate demo data
            pred_covers = 20 + (hour % 8) * 10 + random.uniform(-5, 5)
            confidence = random.uniform(0.65, 0.95)

        recommended_staff = max(1, int(pred_covers / DEFAULT_COVERS_PER_STAFF))

        hourly.append({
            "hour": hour,
            "predicted_covers": round(pred_covers, 1),
            "confidence": round(confidence, 2),
            "signals_contributing": random.randint(2, 5),
            "recommended_staff": recommended_staff,
        })

    # Day classification
    avg_covers = sum(h["predicted_covers"] for h in hourly) / 24
    day_classification = _demand_classification(avg_covers)

    # Comparison to last week
    last_week = target_date - timedelta(days=7)
    last_week_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id and f.date == last_week
    ]
    if last_week_forecasts:
        last_week_avg = sum(f.predicted_covers for f in last_week_forecasts) / len(last_week_forecasts)
        week_on_week_change = round((avg_covers - last_week_avg) / last_week_avg * 100, 1) if last_week_avg > 0 else 0
    else:
        last_week_avg = None
        week_on_week_change = None

    # Top 3 signals
    demo_signals = _generate_demo_signals(venue_id, target_date)
    top_signals = sorted(
        demo_signals,
        key=lambda s: STRENGTH_MULTIPLIERS.get(s["strength"], 1.0),
        reverse=True
    )[:3]

    return {
        "date": target_date.isoformat(),
        "hourly": hourly,
        "day_classification": day_classification,
        "average_covers_predicted": round(avg_covers, 1),
        "comparison_to_last_week": {
            "last_week_date": last_week.isoformat(),
            "last_week_average_covers": round(last_week_avg, 1) if last_week_avg else None,
            "week_on_week_change_percent": week_on_week_change,
        },
        "key_factors": top_signals,
    }


@app.get("/dashboard/{venue_id}/live-pulse")
async def dashboard_live_pulse(venue_id: str):
    """
    GET /dashboard/{venue_id}/live-pulse

    Real-time endpoint — designed to be polled every 60 seconds.
    Returns current hour metrics, variance, threshold breaches, and recommendations.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    now = datetime.now()
    today = now.date()
    current_hour = now.hour

    # Current hour forecast
    hour_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id and f.date == today and f.hour == current_hour
    ]
    if hour_forecasts:
        predicted_covers = sum(f.predicted_covers for f in hour_forecasts) / len(hour_forecasts)
    else:
        predicted_covers = 30 + random.uniform(-10, 10)

    # Actual (mock for now)
    actual_covers = predicted_covers + random.uniform(-8, 8)

    # Current roster
    today_roster = None
    for r in _store["rosters"].values():
        if r.venue_id == venue_id:
            today_roster = r
            break

    on_duty = 0
    if today_roster:
        for shift in today_roster.shifts:
            if (shift.date == today and
                shift.status in [ShiftStatus.in_progress, ShiftStatus.confirmed] and
                shift.start_time.hour <= current_hour < shift.end_time.hour):
                on_duty += 1

    recommended_staff = max(1, int(predicted_covers / DEFAULT_COVERS_PER_STAFF))

    # Variance and breach
    variance = abs(actual_covers - predicted_covers) / max(predicted_covers, 1) if predicted_covers > 0 else 0
    breach = variance > 0.15

    # Next hour prediction
    next_hour = (current_hour + 1) % 24
    next_hour_forecasts = [
        f for f in _store["forecasts"]
        if f.venue_id == venue_id and f.date == today and f.hour == next_hour
    ]
    if next_hour_forecasts:
        next_predicted = sum(f.predicted_covers for f in next_hour_forecasts) / len(next_hour_forecasts)
    else:
        next_predicted = predicted_covers + random.uniform(-5, 5)

    # Alerts
    alerts = []
    if breach:
        if actual_covers > recommended_staff * DEFAULT_COVERS_PER_STAFF * 1.2:
            alerts.append("understaffed_warning")
        elif actual_covers < recommended_staff * DEFAULT_COVERS_PER_STAFF * 0.5:
            alerts.append("overstaffed_warning")

    return {
        "timestamp": now.isoformat(),
        "current_hour": current_hour,
        "current_metrics": {
            "actual_covers": round(actual_covers, 1),
            "predicted_covers": round(predicted_covers, 1),
            "variance_score": round(variance, 3),
            "on_duty_staff": on_duty,
            "recommended_staff": recommended_staff,
        },
        "threshold_breach": breach,
        "threshold_breach_reason": "understaffed" if breach and actual_covers > predicted_covers else ("overstaffed" if breach else None),
        "active_recommendations": [
            {
                "type": "call_in" if on_duty < recommended_staff else "send_home",
                "description": f"{'Call in' if on_duty < recommended_staff else 'Send'} {abs(on_duty - recommended_staff)} staff",
                "confidence": 0.85,
            }
        ] if breach else [],
        "next_hour_prediction": {
            "hour": next_hour,
            "predicted_covers": round(next_predicted, 1),
            "recommended_staff": max(1, int(next_predicted / DEFAULT_COVERS_PER_STAFF)),
        },
        "active_alerts": alerts,
    }


@app.get("/dashboard/{venue_id}/week-ahead")
async def dashboard_week_ahead(venue_id: str):
    """
    GET /dashboard/{venue_id}/week-ahead

    Returns 7-day forward view with demand predictions and staffing recommendations.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    today = date.today()
    week_data = []

    for i in range(7):
        d = today + timedelta(days=i)
        d_forecasts = [
            f for f in _store["forecasts"]
            if f.venue_id == venue_id and f.date == d
        ]

        if d_forecasts:
            pred_covers = sum(f.predicted_covers for f in d_forecasts) / len(d_forecasts)
        else:
            pred_covers = 45 + random.uniform(-15, 15)

        demand_level = _demand_classification(pred_covers)
        day_type = get_day_type(d, State.vic)
        peak_covers = pred_covers * random.uniform(1.1, 1.3)

        # Estimate labour cost
        recommended_shifts = max(2, int(pred_covers / DEFAULT_COVERS_PER_STAFF / 4))  # 4-hour shifts avg
        estimated_cost = recommended_shifts * 25 * 4  # rough estimate

        # Top signals for the day
        demo_signals = _generate_demo_signals(venue_id, d)
        top_signals = sorted(
            demo_signals,
            key=lambda s: STRENGTH_MULTIPLIERS.get(s["strength"], 1.0),
            reverse=True
        )[:3]

        # Flag special days
        special = None
        if str(day_type).lower() in ["public_holiday", "weekend"]:
            special = f"weekend" if "weekend" in str(day_type).lower() else "public_holiday"

        week_data.append({
            "date": d.isoformat(),
            "day_type": str(day_type),
            "demand_level": demand_level,
            "predicted_peak_covers": round(peak_covers, 1),
            "predicted_average_covers": round(pred_covers, 1),
            "key_signals": top_signals,
            "recommended_total_shifts": recommended_shifts,
            "estimated_labour_cost": round(estimated_cost, 2),
            "special_flag": special,
        })

    # Week totals
    week_cost = sum(d["estimated_labour_cost"] for d in week_data)
    last_week = today - timedelta(days=7)
    last_week_cost = week_cost * random.uniform(0.85, 1.15)

    return {
        "week_start": today.isoformat(),
        "week_end": (today + timedelta(days=6)).isoformat(),
        "forecast_days": week_data,
        "week_summary": {
            "total_estimated_labour_cost": round(week_cost, 2),
            "last_week_cost": round(last_week_cost, 2),
            "week_on_week_change_percent": round((week_cost - last_week_cost) / last_week_cost * 100, 1) if last_week_cost > 0 else 0,
        },
    }


@app.get("/dashboard/{venue_id}/signals/history")
async def dashboard_signals_history(
    venue_id: str,
    days: int = Query(30),
    category: Optional[str] = Query(None),
):
    """
    GET /dashboard/{venue_id}/signals/history?days=30&category=weather

    Returns historical signal data for charts and trend analysis.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    today = date.today()
    start_date = today - timedelta(days=days)

    daily_aggregates = {}
    for i in range(days):
        d = start_date + timedelta(days=i)
        signals = _generate_demo_signals(venue_id, d)

        if category:
            signals = [s for s in signals if s["category"] == category]

        by_cat = defaultdict(list)
        for sig in signals:
            by_cat[sig["category"]].append(sig)

        daily_aggregates[d.isoformat()] = dict(by_cat)

    return {
        "venue_id": venue_id,
        "period_days": days,
        "filter_category": category,
        "daily_aggregates": daily_aggregates,
        "accuracy_tracking": {
            "predicted_vs_actual": "Not yet available — real POS data integration in progress",
        },
    }


@app.post("/dashboard/{venue_id}/configure-feeds")
async def configure_feeds(venue_id: str, config: DataFeedConfig):
    """
    POST /dashboard/{venue_id}/configure-feeds

    Saves which data feeds are enabled for this venue and their API keys.
    """
    venue = _store["venues"].get(venue_id)
    if not venue:
        raise HTTPException(404, f"Venue {venue_id} not found")

    # In production, store encrypted API keys in a separate feeds_config table
    # For now, just acknowledge
    enabled_feeds = [k for k, v in config.feeds_enabled.items() if v]

    return {
        "venue_id": venue_id,
        "status": "configured",
        "enabled_feeds": enabled_feeds,
        "message": "Feed configuration saved. Real data will progressively replace demo data as feeds activate.",
    }


# ============================================================================
# Run directly
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("rosteriq.api:app", host="0.0.0.0", port=8000, reload=True)
