"""
WebSocket support module for RosterIQ's real-time dashboard.

Enables live signal updates, variance changes, recommendations, and roster modifications
without requiring client-side polling. Manages persistent connections per venue and
broadcasts updates to all connected dashboards.
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any, Callable, Optional

from fastapi import APIRouter, FastAPI, WebSocket, WebSocketDisconnect, status
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# Message type definitions
class SignalUpdateMessage(BaseModel):
    """Broadcast when a new signal is received or an existing signal is updated."""

    type: str = "signal_update"
    category: str
    value: float
    description: str
    timestamp: str


class VarianceChangeMessage(BaseModel):
    """Broadcast when the overall variance score changes significantly."""

    type: str = "variance_change"
    old_variance: float
    new_variance: float
    change_percent: float
    timestamp: str


class RecommendationMessage(BaseModel):
    """Broadcast when the decision engine generates a new staffing recommendation."""

    type: str = "recommendation"
    recommendation_id: str
    venue_id: str
    description: str
    priority: str  # "high", "medium", "low"
    timestamp: str


class AlertMessage(BaseModel):
    """Broadcast when a threshold breach is detected."""

    type: str = "alert"
    alert_type: str
    severity: str  # "critical", "warning", "info"
    message: str
    timestamp: str


class RosterUpdateMessage(BaseModel):
    """Broadcast when the roster is modified."""

    type: str = "roster_update"
    roster_id: str
    change_type: str  # "created", "updated", "deleted"
    timestamp: str


class PulseMessage(BaseModel):
    """Periodic heartbeat with current state summary (sent every 60 seconds)."""

    type: str = "pulse"
    timestamp: str
    connected_dashboards: int
    active_signals: int
    current_variance: float
    pending_recommendations: int


class PingMessage(BaseModel):
    """Client keepalive ping message."""

    type: str = "ping"
    timestamp: str


class PongMessage(BaseModel):
    """Server keepalive pong response."""

    type: str = "pong"
    timestamp: str


class SubscribeMessage(BaseModel):
    """Client subscription request for specific signal categories."""

    type: str = "subscribe"
    categories: list[str]


class ConnectionManager:
    """
    Manages active WebSocket connections per venue.

    Tracks all connected dashboards for each venue and provides methods to
    broadcast messages to specific venues or all clients.
    """

    def __init__(self):
        """Initialize the connection manager."""
        # venue_id -> set of WebSocket connections
        self.active_connections: dict[str, set[WebSocket]] = {}
        # venue_id -> set of subscribed categories per connection
        self.subscriptions: dict[str, dict[WebSocket, set[str]]] = {}
        logger.info("ConnectionManager initialized")

    async def connect(self, websocket: WebSocket, venue_id: str) -> None:
        """
        Accept and register a new WebSocket connection for a venue.

        Args:
            websocket: The WebSocket connection to register.
            venue_id: The venue identifier for this connection.
        """
        await websocket.accept()
        if venue_id not in self.active_connections:
            self.active_connections[venue_id] = set()
            self.subscriptions[venue_id] = {}

        self.active_connections[venue_id].add(websocket)
        self.subscriptions[venue_id][websocket] = set()  # All categories by default
        logger.info(
            f"WebSocket connected for venue {venue_id}. "
            f"Active connections: {self.get_venue_connection_count(venue_id)}"
        )

    async def disconnect(self, websocket: WebSocket, venue_id: str) -> None:
        """
        Remove and clean up a WebSocket connection.

        Args:
            websocket: The WebSocket connection to remove.
            venue_id: The venue identifier for this connection.
        """
        if venue_id in self.active_connections:
            self.active_connections[venue_id].discard(websocket)
            if venue_id in self.subscriptions:
                self.subscriptions[venue_id].pop(websocket, None)

            # Clean up empty venue entries
            if not self.active_connections[venue_id]:
                del self.active_connections[venue_id]
                del self.subscriptions[venue_id]
                logger.info(f"Removed all connections for venue {venue_id}")
            else:
                logger.info(
                    f"WebSocket disconnected for venue {venue_id}. "
                    f"Remaining connections: {self.get_venue_connection_count(venue_id)}"
                )

    def get_venue_connection_count(self, venue_id: str) -> int:
        """
        Get the number of active connections for a venue.

        Args:
            venue_id: The venue identifier.

        Returns:
            Number of active WebSocket connections for this venue.
        """
        return len(self.active_connections.get(venue_id, set()))

    def get_total_connection_count(self) -> int:
        """
        Get the total number of active connections across all venues.

        Returns:
            Total number of active WebSocket connections.
        """
        return sum(
            len(connections) for connections in self.active_connections.values()
        )

    async def broadcast_to_venue(self, venue_id: str, message: dict[str, Any]) -> None:
        """
        Broadcast a message to all connections for a specific venue.

        Args:
            venue_id: The venue identifier.
            message: The message dictionary to broadcast.
        """
        if venue_id not in self.active_connections:
            return

        disconnected = []
        message_json = json.dumps(message, default=str)

        for websocket in self.active_connections[venue_id]:
            try:
                await websocket.send_text(message_json)
            except Exception as e:
                logger.warning(f"Failed to send message to client: {e}")
                disconnected.append(websocket)

        # Clean up disconnected clients
        for websocket in disconnected:
            await self.disconnect(websocket, venue_id)

    async def broadcast_all(self, message: dict[str, Any]) -> None:
        """
        Broadcast a message to all connected clients across all venues.

        Args:
            message: The message dictionary to broadcast.
        """
        all_venues = list(self.active_connections.keys())
        for venue_id in all_venues:
            await self.broadcast_to_venue(venue_id, message)

    async def set_subscription(
        self, websocket: WebSocket, venue_id: str, categories: list[str]
    ) -> None:
        """
        Update the subscription categories for a specific connection.

        Args:
            websocket: The WebSocket connection.
            venue_id: The venue identifier.
            categories: List of signal categories to subscribe to (empty = all).
        """
        if venue_id in self.subscriptions and websocket in self.subscriptions[venue_id]:
            if categories:
                self.subscriptions[venue_id][websocket] = set(categories)
            else:
                self.subscriptions[venue_id][websocket] = set()
            logger.info(
                f"Updated subscription for venue {venue_id}: {categories or 'all'}"
            )

    def should_deliver_to_connection(
        self, websocket: WebSocket, venue_id: str, message_category: Optional[str]
    ) -> bool:
        """
        Check if a message should be delivered to a specific connection.

        Args:
            websocket: The WebSocket connection.
            venue_id: The venue identifier.
            message_category: The signal category (None = send regardless).

        Returns:
            True if the message should be delivered, False otherwise.
        """
        if message_category is None:
            return True

        if venue_id not in self.subscriptions:
            return True

        subscribed = self.subscriptions[venue_id].get(websocket, set())
        if not subscribed:  # Empty set means subscribed to all
            return True

        return message_category in subscribed


class SignalWatcher:
    """
    Background task that periodically checks for signal changes.

    Monitors signal state and broadcasts updates when changes are detected.
    Runs as an asyncio background task with configurable check interval.
    """

    def __init__(
        self,
        manager: ConnectionManager,
        check_interval: int = 60,
        heartbeat_interval: int = 30,
    ):
        """
        Initialize the signal watcher.

        Args:
            manager: The ConnectionManager instance.
            check_interval: Seconds between signal state checks (default 60).
            heartbeat_interval: Seconds between heartbeat pulses (default 30).
        """
        self.manager = manager
        self.check_interval = check_interval
        self.heartbeat_interval = heartbeat_interval
        self.last_state: dict[str, Any] = {}
        self.is_running = False
        self.task: Optional[asyncio.Task] = None
        logger.info(
            f"SignalWatcher initialized: "
            f"check_interval={check_interval}s, heartbeat_interval={heartbeat_interval}s"
        )

    async def start(self) -> None:
        """Start the background watcher task."""
        if self.is_running:
            logger.warning("SignalWatcher is already running")
            return

        self.is_running = True
        self.task = asyncio.create_task(self._watch_loop())
        logger.info("SignalWatcher started")

    async def stop(self) -> None:
        """Stop the background watcher task."""
        if not self.is_running:
            return

        self.is_running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("SignalWatcher stopped")

    async def _watch_loop(self) -> None:
        """Main watcher loop that checks for changes and sends heartbeats."""
        heartbeat_counter = 0

        try:
            while self.is_running:
                await asyncio.sleep(self.check_interval)

                if not self.is_running:
                    break

                heartbeat_counter += self.check_interval

                # Send heartbeat pulse if interval elapsed
                if heartbeat_counter >= self.heartbeat_interval:
                    await self._send_heartbeat()
                    heartbeat_counter = 0

        except asyncio.CancelledError:
            logger.info("SignalWatcher loop cancelled")
        except Exception as e:
            logger.error(f"Error in SignalWatcher loop: {e}", exc_info=True)

    async def _send_heartbeat(self) -> None:
        """Send a pulse message to all connected venues."""
        try:
            for venue_id in list(self.manager.active_connections.keys()):
                message = {
                    "type": "pulse",
                    "timestamp": datetime.utcnow().isoformat(),
                    "connected_dashboards": self.manager.get_venue_connection_count(
                        venue_id
                    ),
                    "active_signals": 0,  # Would be populated from signal store
                    "current_variance": 0.0,  # Would be populated from metrics
                    "pending_recommendations": 0,  # Would be populated from DB
                }
                await self.manager.broadcast_to_venue(venue_id, message)
        except Exception as e:
            logger.error(f"Error sending heartbeat: {e}")

    async def check_and_broadcast_changes(
        self,
        venue_id: str,
        current_state: dict[str, Any],
        get_state_func: Callable[[], dict[str, Any]],
    ) -> None:
        """
        Compare current state to last-broadcast state and send updates.

        Args:
            venue_id: The venue identifier.
            current_state: The current state dictionary.
            get_state_func: Function to retrieve the latest state.
        """
        if venue_id not in self.last_state:
            self.last_state[venue_id] = {}

        latest_state = get_state_func()

        if latest_state != self.last_state[venue_id]:
            self.last_state[venue_id] = latest_state
            message = {
                "type": "state_update",
                "timestamp": datetime.utcnow().isoformat(),
                "state": latest_state,
            }
            await self.manager.broadcast_to_venue(venue_id, message)


# Global instances
_connection_manager = ConnectionManager()
_signal_watcher: Optional[SignalWatcher] = None


def get_connection_manager() -> ConnectionManager:
    """Get the global ConnectionManager instance."""
    return _connection_manager


def get_signal_watcher() -> SignalWatcher:
    """Get the global SignalWatcher instance."""
    global _signal_watcher
    if _signal_watcher is None:
        _signal_watcher = SignalWatcher(_connection_manager)
    return _signal_watcher


def create_websocket_router() -> APIRouter:
    """
    Create the WebSocket router with endpoints.

    Returns:
        FastAPI router configured with WebSocket endpoints.
    """
    router = APIRouter(prefix="/ws", tags=["websocket"])

    @router.websocket("/ws/{venue_id}")
    async def websocket_endpoint(websocket: WebSocket, venue_id: str) -> None:
        """
        WebSocket endpoint for a venue's dashboard.

        On connect: sends full current state as initial payload.
        On message: supports "subscribe" (specific categories), "ping" (keepalive).
        On disconnect: cleans up.

        Args:
            websocket: The WebSocket connection.
            venue_id: The venue identifier.
        """
        manager = get_connection_manager()
        await manager.connect(websocket, venue_id)

        try:
            # Send initial state
            initial_message = {
                "type": "initial_state",
                "timestamp": datetime.utcnow().isoformat(),
                "venue_id": venue_id,
                "connected_dashboards": manager.get_venue_connection_count(venue_id),
                "active_signals": 0,
                "current_variance": 0.0,
            }
            await websocket.send_json(initial_message)
            logger.info(f"Sent initial state to new connection for venue {venue_id}")

            # Main message loop
            while True:
                data = await websocket.receive_text()

                try:
                    message = json.loads(data)
                    message_type = message.get("type", "")

                    if message_type == "ping":
                        # Respond to keepalive ping
                        pong = {
                            "type": "pong",
                            "timestamp": datetime.utcnow().isoformat(),
                        }
                        await websocket.send_json(pong)
                        logger.debug(f"Pong sent to venue {venue_id}")

                    elif message_type == "subscribe":
                        # Update subscription categories
                        categories = message.get("categories", [])
                        await manager.set_subscription(websocket, venue_id, categories)
                        ack = {
                            "type": "subscribe_ack",
                            "timestamp": datetime.utcnow().isoformat(),
                            "categories": categories or "all",
                        }
                        await websocket.send_json(ack)
                        logger.info(
                            f"Subscription updated for venue {venue_id}: {categories}"
                        )

                    else:
                        logger.warning(f"Unknown message type: {message_type}")

                except json.JSONDecodeError as e:
                    logger.warning(f"Invalid JSON received: {e}")
                except Exception as e:
                    logger.error(f"Error processing message: {e}")

        except WebSocketDisconnect:
            await manager.disconnect(websocket, venue_id)
            logger.info(f"WebSocket disconnected for venue {venue_id}")

        except Exception as e:
            logger.error(f"WebSocket error for venue {venue_id}: {e}", exc_info=True)
            await manager.disconnect(websocket, venue_id)

    return router


def setup_websocket(app: FastAPI) -> None:
    """
    Mount WebSocket routes onto an existing FastAPI app.

    Call this from api.py like: setup_websocket(app)

    Args:
        app: The FastAPI application instance.
    """
    router = create_websocket_router()
    app.include_router(router)
    logger.info("WebSocket routes mounted on FastAPI app")


async def initialize_websocket_background_tasks() -> None:
    """
    Initialize and start background tasks for the WebSocket system.

    Call this during FastAPI startup.
    """
    watcher = get_signal_watcher()
    await watcher.start()
    logger.info("WebSocket background tasks initialized")


async def shutdown_websocket_background_tasks() -> None:
    """
    Shut down background tasks for the WebSocket system.

    Call this during FastAPI shutdown.
    """
    watcher = get_signal_watcher()
    await watcher.stop()
    logger.info("WebSocket background tasks shut down")
