"""
Live headcount pulse engine for RosterIQ.

Lets floor managers tap in an actual head count at any moment during service.
That count is treated as a ground-truth ``pos_trends`` signal — the highest
possible confidence (1.0) — and immediately recalculates the weighted variance
score alongside every other active signal (weather, events, bookings, history).

The updated variance feeds straight into ``make_decision()``, which either
confirms the roster is fine, recommends calling someone in, or names who to
send home — with a plain-English reason at each step.

Every entry is also stored as a ``ForecastRecord`` for the ``AccuracyTracker``,
closing the feedback loop: tonight's taps become tomorrow's training data,
which improves the model's hourly predictions for this venue over time.

Architecture
------------
LivePulseSession
    One session per trading day per venue. Holds the baseline forecast, all
    known context signals (weather, events, bookings), the sequence of headcount
    taps, and the growing list of staffing recommendations produced after each tap.

LiveHeadcount
    A single tap: timestamp, count, and the optional note the manager wrote.

PulseResult
    Everything a UI needs to render after a tap: updated variance, new forecast,
    staffing recommendations, and a plain-English status line.

LivePulseEngine
    Stateless processor. Takes a session + new headcount + current staff picture
    and returns a PulseResult. Designed to be called from the API layer on every
    POST /pulse/headcount request.

Usage
-----
    from rosteriq.live_pulse import LivePulseSession, LivePulseEngine

    session = LivePulseSession.start(
        venue_id="venue-1",
        forecast_covers=85.0,
        context_signals=[weather_signal, bookings_signal],
        trading_date=date.today(),
        hour=19,
    )

    engine = LivePulseEngine()
    result = engine.record(
        session=session,
        actual_count=112,
        note="AFL crowd spilling in from MCG",
        active_shifts=[(alice, shift_a), (bob, shift_b)],
        available_employees=[cara, jake],
        roster_shifts_this_week=weekly_shifts,
        state=State.vic,
    )

    print(result.status_line)      # "Running 32% above forecast — call someone in"
    print(result.recommendations)  # [StaffingRecommendation(action=call_in, ...)]
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, time
from decimal import Decimal
from typing import Optional

from rosteriq.models import (
    DemandForecast,
    Employee,
    Shift,
    SignalType,
    State,
    StaffingRecommendation,
    VarianceSignal,
)
from rosteriq.variance_engine import (
    calculate_weighted_variance,
    combine_forecasts,
    create_signal,
    detect_threshold_breach,
    DEFAULT_WEIGHTS,
)
from rosteriq.decision_engine import make_decision
from rosteriq.forecast_accuracy import AccuracyTracker, ForecastRecord


# ============================================================================
# Weight override — headcount is ground truth
# ============================================================================

# When a live headcount is available it gets the highest effective weight.
# We inject it as a pos_trends signal with confidence 1.0 and a boosted weight
# so it dominates the variance calculation.
HEADCOUNT_SIGNAL_WEIGHT = 0.55   # overrides default pos_trends weight of 0.20
HEADCOUNT_CONFIDENCE = 1.0       # it's what you actually counted — maximum trust

# Threshold for triggering action
VARIANCE_THRESHOLD = 0.15


# ============================================================================
# Core data structures
# ============================================================================

@dataclass
class LiveHeadcount:
    """
    A single live headcount tap from the floor.

    The manager counts bodies (or estimates from sections) and submits the
    number. The optional note captures any context they want to log.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = field(default_factory=datetime.now)
    actual_count: int = 0
    note: str = ""
    hour: int = 0                   # trading hour this count was taken in
    variance_at_time: float = 0.0   # variance score calculated from this count
    adjusted_forecast: float = 0.0  # combined forecast after this count


@dataclass
class PulseResult:
    """
    Everything the UI needs after a headcount tap.

    Produced by LivePulseEngine.record() and contains the updated variance,
    a plain-English status line, staffing recommendations, and a breakdown
    of every signal that contributed to the decision.
    """
    headcount: LiveHeadcount
    variance: float                         # -1.0 to +1.0
    adjusted_forecast: float                # covers expected for the rest of this hour
    status: str                             # "ok" | "understaffed" | "overstaffed"
    status_line: str                        # plain-English one-liner for the UI
    urgency: str                            # "low" | "medium" | "high"
    recommendations: list[StaffingRecommendation]
    signal_breakdown: list[dict]            # each signal's contribution
    forecast_delta_pct: float               # % above/below baseline forecast
    on_floor_now: int                       # staff currently on the floor
    suggested_floor: int                    # what the model thinks you need
    covers_per_staff: float                 # covers / staff (actual ratio)

    def as_dict(self) -> dict:
        return {
            "headcount_id": self.headcount.id,
            "timestamp": self.headcount.timestamp.isoformat(),
            "actual_count": self.headcount.actual_count,
            "note": self.headcount.note,
            "hour": self.headcount.hour,
            "variance": round(self.variance, 3),
            "adjusted_forecast": round(self.adjusted_forecast, 1),
            "status": self.status,
            "status_line": self.status_line,
            "urgency": self.urgency,
            "forecast_delta_pct": round(self.forecast_delta_pct, 1),
            "on_floor_now": self.on_floor_now,
            "suggested_floor": self.suggested_floor,
            "covers_per_staff": round(self.covers_per_staff, 1),
            "recommendations": [
                {
                    "action": r.action.value,
                    "employee_id": r.employee_id,
                    "shift_id": r.shift_id,
                    "reason": r.reason,
                    "priority": round(r.priority, 2),
                    "estimated_savings": float(r.estimated_savings) if r.estimated_savings else None,
                }
                for r in self.recommendations
            ],
            "signal_breakdown": self.signal_breakdown,
        }


@dataclass
class LivePulseSession:
    """
    One live session for a venue on a given trading day.

    A session is started at the beginning of service and accumulates taps
    throughout the night. Each tap extends the pulse_history list and
    produces a PulseResult.

    The session also feeds completed taps to the AccuracyTracker so every
    headcount eventually becomes training data.
    """
    session_id: str
    venue_id: str
    trading_date: date
    current_hour: int
    baseline_forecast: float                # AI-predicted covers for this hour
    context_signals: list[VarianceSignal]   # weather, events, bookings etc.
    pulse_history: list[LiveHeadcount] = field(default_factory=list)
    covers_per_staff_target: float = 15.0   # venue's covers-per-staff ratio
    accuracy_tracker: Optional[AccuracyTracker] = None

    @classmethod
    def start(
        cls,
        venue_id: str,
        forecast_covers: float,
        context_signals: list[VarianceSignal],
        trading_date: date,
        hour: int,
        covers_per_staff: float = 15.0,
        accuracy_tracker: Optional[AccuracyTracker] = None,
    ) -> "LivePulseSession":
        """
        Create a new live pulse session.

        Args:
            venue_id: The venue this session is for.
            forecast_covers: AI-predicted covers for the current hour.
            context_signals: Background signals already loaded (weather, events, etc.).
            trading_date: The date this session covers.
            hour: Current trading hour (0-23).
            covers_per_staff: How many covers one staff member handles.
            accuracy_tracker: Optional tracker to feed headcounts into.

        Returns:
            A fresh LivePulseSession ready to receive taps.
        """
        return cls(
            session_id=str(uuid.uuid4())[:8],
            venue_id=venue_id,
            trading_date=trading_date,
            current_hour=hour,
            baseline_forecast=forecast_covers,
            context_signals=context_signals,
            covers_per_staff_target=covers_per_staff,
            accuracy_tracker=accuracy_tracker,
        )

    @property
    def latest_count(self) -> Optional[int]:
        """Most recent headcount, or None if no taps yet."""
        return self.pulse_history[-1].actual_count if self.pulse_history else None

    @property
    def tap_count(self) -> int:
        return len(self.pulse_history)

    def update_hour(self, hour: int, new_forecast: float, new_signals: list[VarianceSignal]) -> None:
        """
        Advance the session to a new trading hour.

        Called when the clock ticks over so the baseline and context signals
        are refreshed without losing the session's tap history.
        """
        self.current_hour = hour
        self.baseline_forecast = new_forecast
        self.context_signals = new_signals


# ============================================================================
# Signal builder
# ============================================================================

def _build_headcount_signal(
    actual_count: int,
    baseline_forecast: float,
) -> VarianceSignal:
    """
    Convert a raw headcount into a VarianceSignal.

    The signal value is (actual - forecast) / forecast, clamped to [-1, 1].
    We use HEADCOUNT_SIGNAL_WEIGHT and HEADCOUNT_CONFIDENCE to give it
    maximum authority in the variance calculation.
    """
    return create_signal(
        signal_type=SignalType.pos_trends,
        actual=float(actual_count),
        expected=baseline_forecast,
        confidence=HEADCOUNT_CONFIDENCE,
        source="live_headcount",
        weight=HEADCOUNT_SIGNAL_WEIGHT,
    )


def _build_signal_breakdown(
    signals: list[VarianceSignal],
    headcount_signal: VarianceSignal,
) -> list[dict]:
    """
    Build a UI-friendly breakdown of every signal's contribution.

    Returns a list sorted by absolute contribution, highest first.
    """
    all_signals = list(signals) + [headcount_signal]
    total_weight = sum(s.weight * s.confidence for s in all_signals)

    rows = []
    for s in all_signals:
        eff_weight = s.weight * s.confidence
        contribution_pct = (eff_weight / total_weight * 100) if total_weight > 0 else 0
        direction = "above" if s.value > 0.01 else "below" if s.value < -0.01 else "on target"
        is_headcount = s.source == "live_headcount"
        rows.append({
            "signal": "Live headcount" if is_headcount else s.signal_type.value.replace("_", " ").title(),
            "source": s.source,
            "value_pct": round(s.value * 100, 1),
            "direction": direction,
            "confidence": round(s.confidence, 2),
            "weight": round(s.weight, 2),
            "contribution_pct": round(contribution_pct, 1),
            "is_live": is_headcount,
        })

    rows.sort(key=lambda r: abs(r["value_pct"]) * r["contribution_pct"], reverse=True)
    return rows


# ============================================================================
# Plain-English status generation
# ============================================================================

def _status_line(
    variance: float,
    delta_pct: float,
    status: str,
    urgency: str,
    on_floor: int,
    suggested: int,
    actual_count: int,
    baseline_forecast: float,
) -> str:
    """Generate a plain-English one-liner for the floor manager."""
    direction = "above" if delta_pct > 0 else "below"
    abs_delta = abs(round(delta_pct, 0))
    diff = abs(actual_count - round(baseline_forecast))

    if status == "ok":
        if abs_delta < 5:
            return f"Right on track — {actual_count} guests matches the forecast perfectly."
        return (
            f"Running {abs_delta:.0f}% {direction} forecast ({actual_count} guests vs "
            f"{baseline_forecast:.0f} predicted) — current staffing looks good."
        )

    if status == "understaffed":
        short = suggested - on_floor
        short_str = f"{short} more staff" if short > 1 else "1 more staff member"
        if urgency == "high":
            return (
                f"It's getting busy — {actual_count} guests, {abs_delta:.0f}% above forecast. "
                f"Consider calling in {short_str} now."
            )
        return (
            f"Slightly busier than expected ({actual_count} guests, up {abs_delta:.0f}%). "
            f"Watch closely — may need {short_str} if it keeps building."
        )

    if status == "overstaffed":
        extra = on_floor - suggested
        extra_str = f"{extra} staff" if extra > 1 else "1 staff member"
        if urgency == "high":
            return (
                f"Quieter than expected — {actual_count} guests, {abs_delta:.0f}% below forecast. "
                f"Safe to send {extra_str} home early."
            )
        return (
            f"A little quieter than forecast ({actual_count} guests, down {abs_delta:.0f}%). "
            f"Keep an eye on it — could send {extra_str} home if it stays slow."
        )

    return f"{actual_count} guests on floor."


def _urgency(variance: float, delta_pct: float) -> str:
    """Classify urgency from variance magnitude."""
    abs_v = abs(variance)
    if abs_v >= 0.40:
        return "high"
    if abs_v >= 0.20:
        return "medium"
    return "low"


# ============================================================================
# Core engine
# ============================================================================

class LivePulseEngine:
    """
    Stateless engine that processes a headcount tap against a LivePulseSession.

    Designed to be a singleton in the API layer — it holds no state itself;
    all state lives in the session object.
    """

    def record(
        self,
        session: LivePulseSession,
        actual_count: int,
        note: str = "",
        active_shifts: list[tuple[Employee, Shift]] = None,
        available_employees: list[Employee] = None,
        roster_shifts_this_week: dict[str, list[Shift]] = None,
        state: State = State.vic,
        covers_per_staff: float = None,
    ) -> PulseResult:
        """
        Record a live headcount and return an updated staffing recommendation.

        This is the main entry point. Call it every time a manager submits a
        headcount tap. It:

        1. Converts the headcount to a ground-truth pos_trends signal.
        2. Recalculates the weighted variance (headcount + all context signals).
        3. Adjusts the forecast using the combined variance.
        4. Runs the decision engine to get cut/call-in recommendations.
        5. Feeds the headcount into the AccuracyTracker (if one is attached).
        6. Appends the tap to the session's pulse_history.
        7. Returns a PulseResult with everything the UI needs.

        Args:
            session: The active LivePulseSession for this venue/hour.
            actual_count: Number of guests currently on the floor.
            note: Optional manager note (e.g. "AFL crowd from MCG").
            active_shifts: (Employee, Shift) tuples for staff currently working.
            available_employees: Staff who could be called in.
            roster_shifts_this_week: Weekly shifts by employee ID.
            state: Australian state for penalty rate calculations.
            covers_per_staff: Override the session's covers-per-staff target.

        Returns:
            PulseResult with variance, status, recommendations, and breakdown.
        """
        active_shifts = active_shifts or []
        available_employees = available_employees or []
        roster_shifts_this_week = roster_shifts_this_week or {}
        cps = covers_per_staff or session.covers_per_staff_target

        # --- Step 1: build headcount signal ---
        hc_signal = _build_headcount_signal(actual_count, session.baseline_forecast)

        # --- Step 2: recalculate variance ---
        all_signals = list(session.context_signals) + [hc_signal]
        variance = calculate_weighted_variance(all_signals)
        breach = detect_threshold_breach(variance, VARIANCE_THRESHOLD)

        # --- Step 3: adjust forecast ---
        adjusted_forecast = combine_forecasts(session.baseline_forecast, all_signals)

        # --- Step 4: staffing numbers ---
        on_floor = len(active_shifts)
        suggested_floor = max(1, round(adjusted_forecast / cps))
        delta_pct = (
            (actual_count - session.baseline_forecast) / session.baseline_forecast * 100
            if session.baseline_forecast > 0 else 0.0
        )
        covers_ratio = actual_count / on_floor if on_floor > 0 else actual_count

        # --- Step 5: run decision engine ---
        recommendations = make_decision(
            variance=variance,
            active_shifts=active_shifts,
            available_employees=available_employees,
            current_shifts_this_week=roster_shifts_this_week,
            state=state,
            target_date=session.trading_date,
            target_hour=session.current_hour,
            threshold=VARIANCE_THRESHOLD,
            min_staff=1,
        )

        status = breach if breach else "ok"
        urgency = _urgency(variance, delta_pct)

        status_line = _status_line(
            variance=variance,
            delta_pct=delta_pct,
            status=status,
            urgency=urgency,
            on_floor=on_floor,
            suggested=suggested_floor,
            actual_count=actual_count,
            baseline_forecast=session.baseline_forecast,
        )

        signal_breakdown = _build_signal_breakdown(session.context_signals, hc_signal)

        # --- Step 6: store headcount ---
        hc = LiveHeadcount(
            timestamp=datetime.now(),
            actual_count=actual_count,
            note=note,
            hour=session.current_hour,
            variance_at_time=variance,
            adjusted_forecast=adjusted_forecast,
        )
        session.pulse_history.append(hc)

        # --- Step 7: feed accuracy tracker ---
        if session.accuracy_tracker is not None:
            forecast_record = ForecastRecord(
                forecast_id=str(uuid.uuid4())[:8],
                venue_id=session.venue_id,
                forecast_date=session.trading_date,
                hour=session.current_hour,
                predicted_covers=session.baseline_forecast,
                actual_covers=float(actual_count),
                confidence=0.9,
                model_version="live_pulse_v1",
                signals_used=[SignalType.pos_trends, SignalType.historical],
            )
            session.accuracy_tracker._records.append(forecast_record)

        return PulseResult(
            headcount=hc,
            variance=variance,
            adjusted_forecast=adjusted_forecast,
            status=status,
            status_line=status_line,
            urgency=urgency,
            recommendations=recommendations,
            signal_breakdown=signal_breakdown,
            forecast_delta_pct=delta_pct,
            on_floor_now=on_floor,
            suggested_floor=suggested_floor,
            covers_per_staff=covers_ratio,
        )

    def session_summary(self, session: LivePulseSession) -> dict:
        """
        Return a summary of all taps in a session.

        Useful for the end-of-service review — how did actual counts compare
        to forecast across the whole night, and what variances were triggered?
        """
        if not session.pulse_history:
            return {
                "session_id": session.session_id,
                "venue_id": session.venue_id,
                "date": session.trading_date.isoformat(),
                "taps": 0,
                "message": "No headcounts recorded this session.",
            }

        counts = [h.actual_count for h in session.pulse_history]
        variances = [h.variance_at_time for h in session.pulse_history]
        peak_count = max(counts)
        avg_count = sum(counts) / len(counts)
        avg_variance = sum(variances) / len(variances)
        peak_hour = session.pulse_history[counts.index(peak_count)].hour

        over_threshold = [h for h in session.pulse_history if abs(h.variance_at_time) >= VARIANCE_THRESHOLD]

        return {
            "session_id": session.session_id,
            "venue_id": session.venue_id,
            "date": session.trading_date.isoformat(),
            "taps": len(session.pulse_history),
            "baseline_forecast": round(session.baseline_forecast, 1),
            "avg_actual": round(avg_count, 1),
            "peak_actual": peak_count,
            "peak_hour": peak_hour,
            "avg_variance": round(avg_variance, 3),
            "threshold_breaches": len(over_threshold),
            "tap_history": [
                {
                    "hour": h.hour,
                    "count": h.actual_count,
                    "variance": round(h.variance_at_time, 3),
                    "note": h.note,
                    "timestamp": h.timestamp.isoformat(),
                }
                for h in session.pulse_history
            ],
        }


# ============================================================================
# Convenience: build context signals from raw venue data
# ============================================================================

def build_context_signals(
    forecast_covers: float,
    weather_impact_pct: float = 0.0,
    booking_count: float = 0.0,
    booking_forecast: float = 0.0,
    event_impact_pct: float = 0.0,
    historical_avg: float = 0.0,
    weather_confidence: float = 0.7,
    bookings_confidence: float = 0.85,
    events_confidence: float = 0.65,
    historical_confidence: float = 0.9,
) -> list[VarianceSignal]:
    """
    Build a standard set of context signals for a LivePulseSession.

    This is a convenience helper that takes the kind of numbers a venue
    dashboard already has and converts them into VarianceSignal objects
    ready to pass to LivePulseSession.start().

    Args:
        forecast_covers: AI baseline forecast for this hour.
        weather_impact_pct: Expected weather impact as a fraction, e.g. 0.15
            means weather is expected to bring 15% more customers.
        booking_count: Current confirmed bookings for this hour.
        booking_forecast: Expected booking count for this hour.
        event_impact_pct: Local event impact fraction (e.g. 0.25 for AFL nearby).
        historical_avg: Average covers for this day/hour from past data.
        weather_confidence: Confidence in the weather signal (0-1).
        bookings_confidence: Confidence in the bookings signal (0-1).
        events_confidence: Confidence in the events signal (0-1).
        historical_confidence: Confidence in the historical signal (0-1).

    Returns:
        List of VarianceSignal objects for use as context_signals.
    """
    signals = []

    if historical_avg > 0:
        signals.append(create_signal(
            signal_type=SignalType.historical,
            actual=historical_avg,
            expected=forecast_covers,
            confidence=historical_confidence,
            source="historical_avg",
        ))

    if booking_forecast > 0:
        signals.append(create_signal(
            signal_type=SignalType.bookings,
            actual=booking_count,
            expected=booking_forecast,
            confidence=bookings_confidence,
            source="reservation_system",
        ))

    if abs(weather_impact_pct) > 0.01:
        # Weather signal: value is the expected fractional impact
        from rosteriq.models import VarianceSignal as VS
        from datetime import datetime as dt
        signals.append(VS(
            signal_type=SignalType.weather,
            value=max(-1.0, min(1.0, weather_impact_pct)),
            weight=DEFAULT_WEIGHTS.get(SignalType.weather, 0.15),
            confidence=weather_confidence,
            source="weather_feed",
            timestamp=dt.now(),
        ))

    if abs(event_impact_pct) > 0.01:
        from rosteriq.models import VarianceSignal as VS
        from datetime import datetime as dt
        signals.append(VS(
            signal_type=SignalType.events,
            value=max(-1.0, min(1.0, event_impact_pct)),
            weight=DEFAULT_WEIGHTS.get(SignalType.events, 0.10),
            confidence=events_confidence,
            source="events_feed",
            timestamp=dt.now(),
        ))

    return signals
